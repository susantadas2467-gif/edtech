
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

require_admin();

$error = '';
$projectRoot = dirname(__DIR__);
$uploadBase = $projectRoot . DIRECTORY_SEPARATOR
            . 'uploads' . DIRECTORY_SEPARATOR . 'sample_papers';

$maxSize = 20 * 1024 * 1024; // 20 MB

function sample_paper_absolute_path(string $relativePath): string
{
    $root = dirname(__DIR__);
    $relativePath = str_replace('\\', '/', $relativePath);
    $relativePath = ltrim($relativePath, '/');

    return $root . DIRECTORY_SEPARATOR
        . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['delete_id'])) {

    $id = (int) $_POST['delete_id'];

    if ($id > 0) {
        $stmt = $conn->prepare(
            "SELECT file_path FROM materials
             WHERE id = ? AND material_type = 'sample_paper'"
        );

        if ($stmt) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $paper = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($paper) {
                $relative = $paper['file_path'] ?? '';
                $baseReal = realpath($uploadBase);
                $fileReal = $relative !== ''
                    ? realpath(sample_paper_absolute_path($relative))
                    : false;

                if (
                    $baseReal !== false &&
                    $fileReal !== false &&
                    is_file($fileReal) &&
                    strpos(
                        $fileReal,
                        $baseReal . DIRECTORY_SEPARATOR
                    ) === 0
                ) {
                    @unlink($fileReal);
                }

                $delete = $conn->prepare(
                    "DELETE FROM materials
                     WHERE id = ? AND material_type = 'sample_paper'"
                );

                if ($delete) {
                    $delete->bind_param('i', $id);
                    if ($delete->execute()) {
                        set_flash('success', 'Sample paper deleted.');
                    } else {
                        $error = 'Could not delete the sample paper.';
                    }
                    $delete->close();
                }
            }
        }
    }

    header('Location: sample_papers.php');
    exit;
}

// Handle PDF upload
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['upload_paper'])) {

    $title = trim($_POST['title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $class = trim($_POST['class'] ?? '');

    if ($title === '' || $subject === '') {
        $error = 'Please enter the title and subject.';
    } elseif (!in_array($class, ['9', '10'], true)) {
        $error = 'Please select Class 9 or Class 10.';
    } elseif (
        !isset($_FILES['paper_file']) ||
        $_FILES['paper_file']['error'] !== UPLOAD_ERR_OK
    ) {
        $error = 'Please choose a PDF file to upload.';
    } else {
        $file = $_FILES['paper_file'];
        $extension = strtolower(
            pathinfo($file['name'], PATHINFO_EXTENSION)
        );

        $mime = '';
        if (is_uploaded_file($file['tmp_name'])) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']) ?: '';
        }

        if (
            !is_uploaded_file($file['tmp_name']) ||
            $file['size'] <= 0
        ) {
            $error = 'The uploaded file is invalid.';
        } elseif ($file['size'] > $maxSize) {
            $error = 'Maximum file size is 20 MB.';
        } elseif ($extension !== 'pdf' || $mime !== 'application/pdf') {
            $error = 'Only valid PDF files are allowed.';
        } else {
            $classFolder = 'class' . $class;
            $targetDir = $uploadBase . DIRECTORY_SEPARATOR . $classFolder;

            if (!is_dir($targetDir)
                && !mkdir($targetDir, 0775, true)
                && !is_dir($targetDir)) {
                $error = 'Cannot create the upload folder. Check permissions.';
            } elseif (!is_writable($targetDir)) {
                $error = 'The upload folder is not writable.';
            } else {
                $safeTitle = preg_replace(
                    '/[^a-zA-Z0-9_-]/',
                    '_',
                    pathinfo($file['name'], PATHINFO_FILENAME)
                );

                if (!$safeTitle) {
                    $safeTitle = 'sample_paper';
                }

                $uniqueName = $safeTitle . '_'
                    . date('Ymd_His') . '_'
                    . bin2hex(random_bytes(4)) . '.pdf';

                $targetPath = $targetDir . DIRECTORY_SEPARATOR . $uniqueName;
                $dbPath = 'uploads/sample_papers/'
                    . $classFolder . '/' . $uniqueName;

                if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $error = 'Could not save the uploaded file.';
                } else {
                    $uploadedBy = get_user_id();

                    $stmt = $conn->prepare(
                        "INSERT INTO materials
                         (title, subject, `class`, file_path,
                          pdf_path, uploaded_by, material_type)
                         VALUES (?, ?, ?, ?, NULL, ?, 'sample_paper')"
                    );

                    if (!$stmt) {
                        $error = 'Could not prepare the database query.';
                        error_log('Sample paper prepare error: ' . $conn->error);
                    } else {
                        $stmt->bind_param(
                            'ssssi',
                            $title,
                            $subject,
                            $class,
                            $dbPath,
                            $uploadedBy
                        );

                        if ($stmt->execute()) {
                            $stmt->close();
                            set_flash(
                                'success',
                                'Sample paper uploaded for Class ' . $class . '.'
                            );
                            header('Location: sample_papers.php');
                            exit;
                        }

                        error_log('Sample paper insert error: ' . $stmt->error);
                        $stmt->close();
                        $error = 'Could not save the sample paper in the database.';
                    }

                    if ($error !== '' && is_file($targetPath)) {
                        @unlink($targetPath);
                    }
                }
            }
        }
    }
}

// Load only sample papers, not regular study materials
$recent = $conn->query(
    "SELECT m.id, m.title, m.subject, m.class,
            m.file_path, m.uploaded_at,
            u.name AS uploader
     FROM materials m
     LEFT JOIN users u ON m.uploaded_by = u.id
     WHERE m.material_type = 'sample_paper'
     ORDER BY m.uploaded_at DESC
     LIMIT 100"
);

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Sample Papers | EdTech Admin</title>
<style>
* { box-sizing: border-box; }

body {
    margin: 0;
    background: #f5f0e7;
    color: #191a30;
    font-family: Arial, Helvetica, sans-serif;
}

header {
    background: #19182d;
    color: white;
    padding: 18px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
}

header a { color: white; text-decoration: none; }
.brand { font-family: Georgia, serif; font-size: 23px; }

main {
    width: min(100% - 32px, 1000px);
    margin: 42px auto;
}

h1, h2 { font-family: Georgia, serif; }
.subtitle { color: #73778b; margin-top: -8px; }

.notice, .message, .error {
    padding: 14px 16px;
    border-radius: 10px;
    margin: 22px 0;
    overflow-wrap: anywhere;
}

.notice { background: #f3ead8; border: 1px solid #e7d7b4; }
.message { background: #e7f7eb; color: #176534; }
.error { background: #fff0ef; color: #b42318; border: 1px solid #f4c7c3; }

.panel {
    background: #fffdfa;
    border: 1px solid #dedbd5;
    border-radius: 14px;
    padding: 26px;
    margin: 24px 0;
}

label {
    display: block;
    margin: 18px 0 8px;
    color: #626b80;
    font-size: 13px;
    font-weight: bold;
    text-transform: uppercase;
}

input, select {
    width: 100%;
    padding: 13px;
    border: 1px solid #d8dbe2;
    border-radius: 9px;
    background: white;
    font-size: 15px;
}

button, .action {
    display: inline-block;
    border: 0;
    border-radius: 8px;
    padding: 11px 16px;
    margin-top: 20px;
    background: #19182d;
    color: white;
    text-decoration: none;
    cursor: pointer;
    font-size: 14px;
}

.delete { color: #b42318; background: transparent; margin: 0; padding: 0; }
.table-wrap { overflow-x: auto; }

table { width: 100%; border-collapse: collapse; min-width: 600px; }
th, td { text-align: left; padding: 13px 10px; border-bottom: 1px solid #e8e5df; }
th { color: #626b80; font-size: 12px; }
.small { color: #777; font-size: 13px; }

@media (max-width: 600px) {
    header { padding: 16px; }
    .brand { font-size: 19px; }
    main { width: calc(100% - 22px); margin: 24px auto; }
    .panel { padding: 17px; }
}
</style>
</head>
<body>
<header>
    <div class="brand">📚 edtech admin</div>
    <a href="dashboard.php">← Back to Dashboard</a>
</header>

<main>
    <h1>Manage Sample Papers</h1>
    <p class="subtitle">Upload practice papers for Class 9 and Class 10 students.</p>

    <div class="notice">
        📄 Only PDF files are accepted. Maximum file size: 20 MB.
        Papers are listed separately from regular study materials.
    </div>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div class="message">
            <?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php elseif (is_string($flash) && $flash !== ''): ?>
        <div class="message">
            <?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <section class="panel">
        <h2>📤 Upload Sample Paper</h2>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="upload_paper" value="1">

            <label for="title">Paper title</label>
            <input id="title" name="title" type="text"
                   maxlength="150" required>

            <label for="subject">Subject</label>
            <input id="subject" name="subject" type="text"
                   maxlength="50" required>

            <label for="class">Class</label>
            <select id="class" name="class" required>
                <option value="">Select class</option>
                <option value="9">Class 9</option>
                <option value="10">Class 10</option>
            </select>

            <label for="paper_file">Choose PDF file</label>
            <input id="paper_file" name="paper_file"
                   type="file" accept=".pdf,application/pdf" required>

            <p class="small">Maximum size: 20 MB.</p>
            <button type="submit">Upload Sample Paper</button>
        </form>
    </section>

    <section class="panel">
        <h2>Recently Uploaded Sample Papers</h2>

        <?php if (!$recent): ?>
            <p>Unable to load papers. Check your database configuration.</p>
        <?php elseif ($recent->num_rows === 0): ?>
            <p>No sample papers have been uploaded yet.</p>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Subject</th>
                            <th>Class</th>
                            <th>Uploaded</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $recent->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($row['subject'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($row['class'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($row['uploaded_at'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <form method="POST"
                                      onsubmit="return confirm('Delete this sample paper?');">
                                    <input type="hidden" name="delete_id"
                                           value="<?= (int)$row['id'] ?>">
                                    <button class="delete" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
