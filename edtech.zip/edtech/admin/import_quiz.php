<?php
// admin/import_quiz.php — extract questions from a text PDF or DOCX, review, then save.
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_admin();

$error = '';
$parsed = [];
$sourceName = '';
$title = trim($_POST['quiz_title'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$class = (string)($_POST['class'] ?? '');

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function extractDocumentText(string $path, string $ext): string {
    if ($ext === 'pdf') {
        if (!class_exists(\Smalot\PdfParser\Parser::class)) {
            throw new RuntimeException('PDFParser is not installed. Run composer require smalot/pdfparser in your project folder.');
        }
        $parser = new \Smalot\PdfParser\Parser();
        $pdf = $parser->parseFile($path);
        return (string)$pdf->getText();
    }
    if ($ext === 'docx') {
        if (!class_exists(\PhpOffice\PhpWord\IOFactory::class)) {
            throw new RuntimeException('PHPWord is not installed. Run composer require phpoffice/phpword in your project folder.');
        }
        $doc = \PhpOffice\PhpWord\IOFactory::load($path, 'Word2007');
        $lines = [];
        $walk = function($elements) use (&$walk, &$lines) {
            foreach ($elements as $element) {
                if (method_exists($element, 'getText')) {
                    $text = $element->getText();
                    if (is_string($text) && trim($text) !== '') $lines[] = $text;
                } elseif (method_exists($element, 'getElements')) {
                    $walk($element->getElements());
                }
            }
        };
        foreach ($doc->getSections() as $section) $walk($section->getElements());
        return implode("\n", $lines);
    }
    throw new RuntimeException('Please upload a PDF or DOCX file.');
}

function parseQuestions(string $text): array {
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    $lines = array_map(static fn($line) => trim(preg_replace('/[\t ]+/', ' ', $line)), explode("\n", $text));
    $blocks = []; $current = [];
    foreach ($lines as $line) {
        if ($line === '') continue;
        if (preg_match('/^\s*(?:Q(?:uestion)?\s*)?\d{1,3}[.)\-:]\s+\S/i', $line)) {
            if ($current) $blocks[] = $current;
            $current = [$line];
        } elseif ($current) {
            $current[] = $line;
        }
    }
    if ($current) $blocks[] = $current;
    $out = [];
    foreach ($blocks as $block) {
        $q = ['question_text'=>'', 'option_a'=>'', 'option_b'=>'', 'option_c'=>'', 'option_d'=>'', 'correct_option'=>'', 'marks'=>1, 'needs_review'=>true];
        $questionLines = [];
        foreach ($block as $line) {
            if (preg_match('/^\s*(?:Q(?:uestion)?\s*)?\d{1,3}[.)\-:]\s*(.*)$/i', $line, $m)) {
                if (trim($m[1]) !== '') $questionLines[] = trim($m[1]);
            } elseif (preg_match('/^\s*([A-D])[.)\:]\s*(.+)$/i', $line, $m)) {
                $key = 'option_' . strtolower($m[1]); $q[$key] = trim($m[2]);
            } elseif (preg_match('/^\s*(?:Answer|Correct\s*Answer|Ans)\s*[:\-]\s*([A-D])\b/i', $line, $m)) {
                $q['correct_option'] = strtolower($m[1]);
            } elseif (preg_match('/^\s*Marks?\s*[:\-]\s*(\d{1,2})\b/i', $line, $m)) {
                $q['marks'] = max(1, min(20, (int)$m[1]));
            } else {
                $questionLines[] = $line;
            }
        }
        $q['question_text'] = trim(implode(' ', $questionLines));
        $hasOptions = $q['option_a'] !== '' && $q['option_b'] !== '' && $q['option_c'] !== '' && $q['option_d'] !== '';
        $q['needs_review'] = !($q['question_text'] !== '' && $hasOptions && in_array($q['correct_option'], ['a','b','c','d'], true));
        if ($q['question_text'] !== '') $out[] = $q;
    }
    return $out;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['extract_file'])) {
    $file = $_FILES['source_file'] ?? null;
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $error = 'Choose a PDF or DOCX file to upload.';
    } elseif (($file['size'] ?? 0) > 15 * 1024 * 1024) {
        $error = 'The file must be 15 MB or smaller.';
    } else {
        $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['pdf','docx'], true)) {
            $error = 'Only text-based PDF and Word (.docx) files are supported for extraction right now.';
        } elseif (!is_uploaded_file($file['tmp_name'] ?? '')) {
            $error = 'The uploaded file could not be verified.';
        } else {
            try {
                require_once __DIR__ . '/../vendor/autoload.php';
                $text = extractDocumentText($file['tmp_name'], $ext);
                $parsed = parseQuestions($text);
                $sourceName = (string)$file['name'];
                if (!$parsed) $error = 'No numbered questions were detected. Use numbered questions (1., 2.) with options like A. and an answer key like Answer: B. Scanned PDFs need OCR and are not supported yet.';
            } catch (Throwable $e) {
                error_log('Quiz extraction failed: ' . $e->getMessage());
                $error = 'Could not read this file. Check that it is a valid text-based PDF or DOCX, then try again.';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_reviewed_quiz'])) {
    $title = trim($_POST['quiz_title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $class = (string)($_POST['class'] ?? '');
    $texts = $_POST['question_text'] ?? [];
    $oa = $_POST['option_a'] ?? []; $ob = $_POST['option_b'] ?? []; $oc = $_POST['option_c'] ?? []; $od = $_POST['option_d'] ?? [];
    $answers = $_POST['correct_option'] ?? []; $marks = $_POST['marks'] ?? [];
    $clean = [];
    if ($title === '' || $subject === '' || !in_array($class, ['9','10'], true)) $error = 'Enter the quiz title, subject, and Class 9 or Class 10.';
    elseif (!is_array($texts) || count($texts) === 0) $error = 'No questions were submitted for review.';
    else {
        foreach ($texts as $i => $qt) {
            $qt = trim((string)$qt); if ($qt === '') continue;
            $a = trim((string)($oa[$i] ?? '')); $b = trim((string)($ob[$i] ?? '')); $c = trim((string)($oc[$i] ?? '')); $d = trim((string)($od[$i] ?? ''));
            $answer = strtolower((string)($answers[$i] ?? ''));
            if ($a === '' || $b === '' || $c === '' || $d === '' || !in_array($answer, ['a','b','c','d'], true)) { $error = 'Complete all four options and choose the correct answer for each question before saving.'; break; }
            $clean[] = ['text'=>$qt,'a'=>$a,'b'=>$b,'c'=>$c,'d'=>$d,'answer'=>$answer,'marks'=>max(1,min(20,(int)($marks[$i] ?? 1)))];
        }
        if ($error === '' && !$clean) $error = 'Add at least one complete question before saving.';
    }
    if ($error === '') {
        try {
            $conn->begin_transaction();
            $created_by = (int)($_SESSION['user_id'] ?? 0);
            $stmt = $conn->prepare('INSERT INTO quizzes (title, subject, `class`, created_by) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('sssi', $title, $subject, $class, $created_by); $stmt->execute(); $quizId = (int)$conn->insert_id; $stmt->close();
            $qs = $conn->prepare('INSERT INTO questions (quiz_id, question_text, question_type, option_a, option_b, option_c, option_d, correct_option, marks) VALUES (?, ?, \'mcq\', ?, ?, ?, ?, ?, ?)');
            foreach ($clean as $item) {
                $qs->bind_param('issssssi', $quizId, $item['text'], $item['a'], $item['b'], $item['c'], $item['d'], $item['answer'], $item['marks']);
                $qs->execute();
            }
            $qs->close(); $conn->commit();
            header('Location: add_quiz.php?imported=1'); exit;
        } catch (Throwable $e) {
            $conn->rollback(); error_log('Reviewed quiz save failed: '.$e->getMessage());
            $error = 'Could not save the quiz. Please check the database and try again.';
        }
    }
    // Rebuild editable rows from submitted form so validation errors do not lose edits.
    if (isset($texts) && is_array($texts)) {
        foreach ($texts as $i => $qt) $parsed[] = ['question_text'=>(string)$qt,'option_a'=>(string)($oa[$i]??''),'option_b'=>(string)($ob[$i]??''),'option_c'=>(string)($oc[$i]??''),'option_d'=>(string)($od[$i]??''),'correct_option'=>(string)($answers[$i]??''),'marks'=>(int)($marks[$i]??1),'needs_review'=>true];
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Import Quiz Questions</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box}body{margin:0;font-family:'DM Sans',sans-serif;background:#f5f0e8;color:#1a1a2e}.topbar{background:#1a1a2e;padding:18px 40px;display:flex;justify-content:space-between;align-items:center;color:#faf7f2}.topbar a{color:#e8c96a;text-decoration:none}.container{max-width:900px;margin:auto;padding:38px 20px 70px}h1,h2{font-family:'Playfair Display',serif}.muted{color:#7a7a8a;font-size:14px}.card{background:#faf7f2;border:1px solid rgba(26,26,46,.12);border-radius:14px;padding:24px;margin-bottom:20px}.row{display:grid;grid-template-columns:2fr 1fr 1fr;gap:12px}label{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#7a7a8a;margin:0 0 7px}input[type=text],input[type=number],input[type=file],select,textarea{width:100%;padding:10px 12px;border:1px solid rgba(26,26,46,.18);border-radius:8px;background:#fff;font:14px 'DM Sans',sans-serif;color:#1a1a2e}textarea{min-height:72px;resize:vertical}.field{margin-bottom:14px}.btn{border:0;border-radius:9px;background:#1a1a2e;color:#faf7f2;padding:12px 16px;font:500 14px 'DM Sans',sans-serif;cursor:pointer;text-decoration:none;display:inline-block}.btn.light{background:#e8c96a;color:#1a1a2e}.alert{padding:12px 15px;border-radius:8px;margin-bottom:18px;background:#fdf0ef;color:#c0392b}.question{background:#fff;border:1px solid rgba(26,26,46,.15);border-radius:10px;padding:18px;margin:16px 0}.question h3{margin:0 0 14px;font-family:'Playfair Display',serif}.options{display:grid;grid-template-columns:1fr 1fr;gap:12px}.flag{font-size:12px;color:#a65a00;background:#fff4dc;padding:5px 8px;border-radius:6px;display:inline-block;margin-bottom:10px}@media(max-width:650px){.row,.options{grid-template-columns:1fr}.topbar{padding:16px 20px}}
</style></head><body>
<div class="topbar"><strong>📚 edtech admin</strong><a href="add_quiz.php">← Back to Add Quiz</a></div><main class="container"><h1>Import Questions from a File</h1><p class="muted">Upload a text-based PDF or DOCX. Extracted questions are only saved after you review them.</p>
<?php if ($error !== ''): ?><div class="alert">⚠️ <?=h($error)?></div><?php endif; ?>
<?php if (!$parsed): ?>
<form method="post" enctype="multipart/form-data" class="card"><h2>Quiz details</h2><div class="row"><div class="field"><label for="quiz_title">Quiz title</label><input id="quiz_title" name="quiz_title" type="text" value="<?=h($title)?>" required></div><div class="field"><label for="subject">Subject</label><input id="subject" name="subject" type="text" value="<?=h($subject)?>" required></div><div class="field"><label for="class">Class</label><select id="class" name="class" required><option value="">Select</option><option value="9" <?=$class==='9'?'selected':''?>>Class 9</option><option value="10" <?=$class==='10'?'selected':''?>>Class 10</option></select></div></div><div class="field"><label for="source_file">Choose PDF or Word (.docx)</label><input type="file" id="source_file" name="source_file" accept=".pdf,.docx" required></div><p class="muted">Expected format: numbered questions, options on lines like “A. Earth”, and an answer line such as “Answer: B”. Marks are optional. Scanned/image-only PDFs and old .doc files are not supported yet.</p><button class="btn" type="submit" name="extract_file" value="1">Extract Questions for Review →</button></form>
<?php else: ?>
<form method="post" class="card"><h2>Review extracted questions</h2><p class="muted">File: <?=h($sourceName ?: 'Uploaded document')?> · <?=count($parsed)?> question(s) detected. Please check every question and correct answer.</p>
<input type="hidden" name="save_reviewed_quiz" value="1"><div class="row"><div class="field"><label>Quiz title</label><input type="text" name="quiz_title" value="<?=h($title)?>" required></div><div class="field"><label>Subject</label><input type="text" name="subject" value="<?=h($subject)?>" required></div><div class="field"><label>Class</label><select name="class" required><option value="9" <?=$class==='9'?'selected':''?>>Class 9</option><option value="10" <?=$class==='10'?'selected':''?>>Class 10</option></select></div></div>
<?php foreach ($parsed as $i=>$q): ?><section class="question"><h3>Question <?=($i+1)?></h3><?php if (!empty($q['needs_review'])): ?><span class="flag">Please review: some fields may not have been detected</span><?php endif; ?><div class="field"><label>Question text</label><textarea name="question_text[]" required><?=h($q['question_text'])?></textarea></div><div class="options"><div class="field"><label>Option A</label><input type="text" name="option_a[]" value="<?=h($q['option_a'])?>" required></div><div class="field"><label>Option B</label><input type="text" name="option_b[]" value="<?=h($q['option_b'])?>" required></div><div class="field"><label>Option C</label><input type="text" name="option_c[]" value="<?=h($q['option_c'])?>" required></div><div class="field"><label>Option D</label><input type="text" name="option_d[]" value="<?=h($q['option_d'])?>" required></div></div><div class="row"><div class="field"><label>Correct option</label><select name="correct_option[]" required><option value="">Select correct answer</option><?php foreach(['a'=>'A','b'=>'B','c'=>'C','d'=>'D'] as $v=>$label): ?><option value="<?=$v?>" <?=($q['correct_option']??'')===$v?'selected':''?>><?=$label?></option><?php endforeach; ?></select></div><div class="field"><label>Marks</label><input type="number" name="marks[]" min="1" max="20" value="<?=h($q['marks'])?>" required></div><div></div></div></section><?php endforeach; ?><button class="btn" type="submit">Save Reviewed Quiz →</button> <a class="btn light" href="import_quiz.php">Start over</a></form>
<?php endif; ?></main></body></html>
