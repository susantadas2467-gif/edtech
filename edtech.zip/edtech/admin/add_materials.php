<?php
// admin/add_materials.php
require_once '../includes/auth.php';
require_once '../includes/flash.php';
require_admin();

$error = "";

// LibreOffice path
$libreoffice = 'C:\Program Files\LibreOffice\program\soffice.exe';

// ── DELETE MATERIAL ──
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];

    $s = $conn->prepare("SELECT file_path, pdf_path FROM materials WHERE id = ?");
    $s->bind_param("i", $del_id);
    $s->execute();
    $del_row = $s->get_result()->fetch_assoc();
    $s->close();

    if ($del_row) {
        // Delete original file
        $orig = '../' . $del_row['file_path'];
        if (file_exists($orig)) unlink($orig);

        // Delete converted PDF if exists
        if (!empty($del_row['pdf_path'])) {
            $pdf = '../' . $del_row['pdf_path'];
            if (file_exists($pdf)) unlink($pdf);
        }

        $s = $conn->prepare("DELETE FROM materials WHERE id = ?");
        $s->bind_param("i", $del_id);
        $s->execute();
        $s->close();

        set_flash('success', "Material deleted successfully.");
    }
    header("Location: add_materials.php");
    exit();
}

// ── UPLOAD ──
$allowed_ext = ['pdf', 'doc', 'docx', 'ppt', 'pptx'];
$max_size_mb = 20;
$upload_base = '../uplods/materials';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = trim($_POST['title']   ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $class   = $_POST['class']        ?? '';

    if (empty($title) || empty($subject) || empty($class)) {
        $error = "Please fill in title, subject, and class.";
    } elseif (!isset($_FILES['material_file']) || $_FILES['material_file']['error'] !== UPLOAD_ERR_OK) {
        $error = "Please select a valid file to upload.";
    } else {
        $file         = $_FILES['material_file'];
        $file_ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $file_size_mb = $file['size'] / (1024 * 1024);

        if (!in_array($file_ext, $allowed_ext)) {
            $error = "Invalid file type. Allowed: " . implode(', ', $allowed_ext);
        } elseif ($file_size_mb > $max_size_mb) {
            $error = "File too large. Max size is {$max_size_mb}MB.";
        } else {
            // Build folder
            $class_folder = "class" . $class;
            $target_dir   = "$upload_base/$class_folder";
            if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

            // Safe unique filename
            $safe_name   = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
            $unique_name = $safe_name . '_' . time() . '.' . $file_ext;
            $target_path = "$target_dir/$unique_name";

            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                $db_path  = "uplods/materials/$class_folder/$unique_name";
                $pdf_path = null;

                // ── Auto-convert to PDF if not already PDF ──
                if ($file_ext !== 'pdf') {
                    $abs_target  = realpath($target_path);
                    $abs_out_dir = realpath($target_dir);

                    // Run LibreOffice conversion
                    $cmd = '"' . $libreoffice . '" --headless --convert-to pdf --outdir "' . $abs_out_dir . '" "' . $abs_target . '" 2>&1';
                    exec($cmd, $output, $return_code);

                    // LibreOffice names the output: originalname.pdf
                    $expected_pdf = $target_dir . '/' . pathinfo($unique_name, PATHINFO_FILENAME) . '.pdf';

                    if ($return_code === 0 && file_exists($expected_pdf)) {
                        $pdf_path = "uplods/materials/$class_folder/" . pathinfo($unique_name, PATHINFO_FILENAME) . '.pdf';
                    } else {
                        // Log conversion failure but don't block upload
                        error_log("LibreOffice conversion failed for: $unique_name. Output: " . implode("\n", $output));
                    }
                }

                // ── Save to DB ──
                $s = $conn->prepare("INSERT INTO materials (title, subject, `class`, file_path, pdf_path, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)");
                $s->bind_param("sssssi", $title, $subject, $class, $db_path, $pdf_path, $_SESSION['user_id']);

                if ($s->execute()) {
                    $msg = "\"$title\" uploaded successfully for Class $class.";
                    if ($pdf_path) $msg .= " PDF preview generated ✓";
                    else if ($file_ext !== 'pdf') $msg .= " (PDF conversion pending — view may not be available)";
                    set_flash('success', $msg);
                    header("Location: add_materials.php");
                    exit();
                } else {
                    $error = "File uploaded but failed to save to database.";
                    error_log("Material DB insert failed: " . $s->error);
                }
                $s->close();
            } else {
                $error = "Failed to upload file. Check folder permissions.";
            }
        }
    }
}

// ── Fetch recent materials ──
$recent = $conn->query("
    SELECT m.id, m.title, m.subject, m.class, m.file_path, m.pdf_path, m.uploaded_at, u.name AS uploader
    FROM materials m
    LEFT JOIN users u ON m.uploaded_by = u.id
    ORDER BY m.uploaded_at DESC
    LIMIT 15
");

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Add Materials</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --ink:#1a1a2e; --ink2:#2e2e4a; --cream:#f5f0e8; --paper:#faf7f2;
            --gold:#c9a84c; --gold2:#e8c96a; --muted:#7a7a8a;
            --red:#c0392b; --green:#1e7e4a; --blue:#2563eb;
            --border:rgba(26,26,46,0.12);
        }
        html,body { font-family:'DM Sans',sans-serif; background:var(--cream); color:var(--ink); min-height:100vh; }
        .topbar { background:var(--ink); padding:16px 32px; display:flex; align-items:center; justify-content:space-between; }
        .brand { display:flex; align-items:center; gap:10px; }
        .brand-icon { width:32px; height:32px; background:var(--gold); border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:16px; }
        .brand-name { font-family:'Playfair Display',serif; font-size:18px; color:var(--cream); }
        .topbar a { color:rgba(245,240,232,0.7); text-decoration:none; font-size:13.5px; }
        .topbar a:hover { color:var(--gold2); }
        .container { max-width:860px; margin:0 auto; padding:40px 24px 80px; }
        .page-header { margin-bottom:28px; }
        .page-header h1 { font-family:'Playfair Display',serif; font-size:30px; margin-bottom:6px; }
        .page-header p { color:var(--muted); font-size:14px; }
        .alert { border-radius:8px; padding:12px 16px; margin-bottom:22px; font-size:13.5px; display:flex; align-items:center; gap:8px; }
        .alert-error { background:#fdf0ef; border:1px solid rgba(192,57,43,.25); border-left:3px solid var(--red); color:var(--red); }
        .alert-success { background:#edfbf3; border:1px solid rgba(30,126,74,.25); border-left:3px solid var(--green); color:var(--green); }
        .card { background:var(--paper); border:1px solid var(--border); border-radius:14px; padding:28px; margin-bottom:32px; }
        .card h2 { font-family:'Playfair Display',serif; font-size:17px; margin-bottom:20px; }
        .form-row { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
        .form-group { margin-bottom:18px; }
        label { display:block; font-size:11.5px; font-weight:500; letter-spacing:.06em; text-transform:uppercase; color:var(--muted); margin-bottom:7px; }
        input[type=text],select { width:100%; padding:11px 13px; border:1px solid var(--border); border-radius:9px; background:#fff; font-family:'DM Sans',sans-serif; font-size:14.5px; color:var(--ink); outline:none; transition:border-color .2s,box-shadow .2s; }
        input:focus,select:focus { border-color:var(--gold); box-shadow:0 0 0 3px rgba(201,168,76,.12); }
        .file-drop { border:1.5px dashed var(--border); border-radius:12px; padding:28px; text-align:center; cursor:pointer; transition:border-color .2s,background .2s; position:relative; }
        .file-drop:hover,.file-drop.dragover { border-color:var(--gold); background:rgba(201,168,76,.04); }
        .file-drop input[type=file] { position:absolute; inset:0; opacity:0; cursor:pointer; width:100%; height:100%; }
        .drop-icon { font-size:28px; margin-bottom:8px; }
        .drop-text { font-size:13.5px; color:var(--muted); }
        .drop-text strong { color:var(--ink); }
        .drop-hint { font-size:11.5px; color:var(--muted); margin-top:4px; }
        .file-chosen { margin-top:10px; font-size:13px; color:var(--ink); font-weight:500; display:none; }
        .btn-submit { width:100%; padding:14px; background:var(--ink); color:var(--cream); border:none; border-radius:10px; font-size:15px; font-weight:500; cursor:pointer; margin-top:6px; transition:background .2s; }
        .btn-submit:hover { background:var(--ink2); }
        /* Info box */
        .info-box { background:rgba(201,168,76,0.08); border:1px solid rgba(201,168,76,0.25); border-radius:10px; padding:12px 16px; margin-bottom:20px; font-size:13px; color:var(--ink); display:flex; align-items:flex-start; gap:8px; }
        /* Table */
        .section-title { font-family:'Playfair Display',serif; font-size:20px; margin-bottom:16px; }
        .table-card { background:var(--paper); border:1px solid var(--border); border-radius:14px; overflow:hidden; }
        table { width:100%; border-collapse:collapse; }
        thead { background:var(--ink); }
        thead th { color:var(--cream); font-size:11px; text-transform:uppercase; letter-spacing:.06em; text-align:left; padding:13px 16px; font-weight:500; }
        tbody tr { border-bottom:1px solid var(--border); transition:background .15s; }
        tbody tr:last-child { border-bottom:none; }
        tbody tr:hover { background:rgba(201,168,76,.03); }
        tbody td { padding:13px 16px; font-size:13.5px; vertical-align:middle; }
        .file-icon-sm { width:32px; height:32px; border-radius:7px; display:inline-flex; align-items:center; justify-content:center; font-size:14px; flex-shrink:0; }
        .file-icon-sm.pdf  { background:rgba(220,38,38,.1); }
        .file-icon-sm.docx { background:rgba(37,99,235,.1); }
        .file-icon-sm.pptx { background:rgba(234,88,12,.1); }
        .file-icon-sm.other{ background:rgba(201,168,76,.1); }
        .mat-title { font-weight:500; font-size:13.5px; }
        .mat-meta  { font-size:11.5px; color:var(--muted); margin-top:2px; }
        .class-badge { display:inline-block; padding:2px 8px; border-radius:6px; font-size:11px; font-weight:600; background:rgba(201,168,76,.1); color:var(--gold); }
        .pdf-badge { display:inline-block; padding:2px 7px; border-radius:5px; font-size:10px; font-weight:600; background:rgba(34,197,94,.1); color:#16a34a; margin-left:5px; }
        .action-group { display:flex; gap:7px; align-items:center; flex-wrap:wrap; }
        .act-btn { display:inline-flex; align-items:center; gap:5px; padding:6px 11px; border-radius:7px; font-size:12px; font-weight:500; text-decoration:none; border:1px solid var(--border); background:#fff; color:var(--ink); cursor:pointer; transition:all .15s; white-space:nowrap; }
        .act-btn:hover { border-color:var(--gold); background:rgba(201,168,76,.05); }
        .act-btn.view  { color:var(--blue); border-color:rgba(37,99,235,.2); background:rgba(37,99,235,.05); }
        .act-btn.view:hover { background:rgba(37,99,235,.1); }
        .act-btn.dl    { color:var(--green); border-color:rgba(30,126,74,.2); background:rgba(30,126,74,.05); }
        .act-btn.dl:hover { background:rgba(30,126,74,.1); }
        .act-btn.del   { color:var(--red); border-color:rgba(192,57,43,.2); background:rgba(192,57,43,.05); }
        .act-btn.del:hover { background:rgba(192,57,43,.1); }
        .act-btn.disabled { opacity:0.4; cursor:not-allowed; pointer-events:none; }
        .empty-state { text-align:center; padding:40px; color:var(--muted); }
        @media(max-width:640px) { .form-row{grid-template-columns:1fr} .container{padding:28px 16px 60px} .topbar{padding:14px 16px} table{min-width:580px} .table-card{overflow-x:auto} }
    </style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech admin</span>
    </div>
    <a href="dashboard.php">← Back to Dashboard</a>
</div>

<div class="container">
    <div class="page-header">
        <h1>Add Study Material</h1>
        <p>Upload notes, worksheets, or resources for students.</p>
    </div>

    <div class="info-box">
        💡 <div>DOCX and PPTX files will be <strong>automatically converted to PDF</strong> using LibreOffice so students can preview them directly in the browser. Original file is kept for download.</div>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($flash): ?>
    <div class="alert alert-<?php echo $flash['type'] === 'success' ? 'success' : 'error'; ?>">
        <?php echo $flash['type'] === 'success' ? '✓' : '⚠️'; ?>
        <?php echo htmlspecialchars($flash['message']); ?>
    </div>
    <?php endif; ?>

    <!-- Upload Form -->
    <div class="card">
        <h2>📤 Upload New Material</h2>
        <form method="POST" action="add_materials.php" enctype="multipart/form-data">

            <div class="form-group">
                <label for="title">Material Title</label>
                <input type="text" id="title" name="title"
                    placeholder="e.g. Chapter 4 Notes — Light" required
                    value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject"
                        placeholder="e.g. Science" required
                        value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="class">Class</label>
                    <select id="class" name="class" required>
                        <option value="">Select class</option>
                        <option value="9"  <?php echo ($_POST['class'] ?? '') === '9'  ? 'selected' : ''; ?>>Class 9</option>
                        <option value="10" <?php echo ($_POST['class'] ?? '') === '10' ? 'selected' : ''; ?>>Class 10</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Upload File</label>
                <div class="file-drop" id="dropZone">
                    <input type="file" id="material_file" name="material_file"
                        accept=".pdf,.doc,.docx,.ppt,.pptx"
                        required onchange="showFile(this)">
                    <div class="drop-icon">📄</div>
                    <div class="drop-text"><strong>Click to upload</strong> or drag and drop</div>
                    <div class="drop-hint">PDF, DOC, DOCX, PPT, PPTX — max 20MB</div>
                    <div class="file-chosen" id="fileChosen"></div>
                </div>
            </div>

            <button type="submit" class="btn-submit">Upload Material →</button>
        </form>
    </div>

    <!-- Recently uploaded -->
    <div class="section-title">Recently Uploaded</div>

    <div class="table-card">
        <?php if ($recent && $recent->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>File</th>
                    <th>Class</th>
                    <th>Uploaded</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $recent->fetch_assoc()):
                $ext = strtolower(pathinfo($row['file_path'], PATHINFO_EXTENSION));
                $icon_class = match($ext) {
                    'pdf'        => 'pdf',
                    'doc','docx' => 'docx',
                    'ppt','pptx' => 'pptx',
                    default      => 'other'
                };
                $icon_emoji = match($ext) {
                    'pdf'        => '📄',
                    'doc','docx' => '📝',
                    'ppt','pptx' => '📊',
                    default      => '📁'
                };
                $orig_url = '../' . ltrim($row['file_path'], '/');

                // For view: use PDF version if available, else use original (for PDF files)
                $has_pdf     = !empty($row['pdf_path']);
                $view_url    = $has_pdf
                    ? '../' . ltrim($row['pdf_path'], '/')
                    : ($ext === 'pdf' ? $orig_url : null);
                $can_preview = ($view_url !== null);
            ?>
            <tr>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="file-icon-sm <?php echo $icon_class; ?>"><?php echo $icon_emoji; ?></div>
                        <div>
                            <div class="mat-title">
                                <?php echo htmlspecialchars($row['title']); ?>
                                <?php if ($has_pdf && $ext !== 'pdf'): ?>
                                <span class="pdf-badge">PDF ✓</span>
                                <?php endif; ?>
                            </div>
                            <div class="mat-meta"><?php echo htmlspecialchars($row['subject']); ?> · <?php echo strtoupper($ext); ?></div>
                        </div>
                    </div>
                </td>
                <td><span class="class-badge">Class <?php echo htmlspecialchars($row['class']); ?></span></td>
                <td style="color:var(--muted);font-size:12.5px;"><?php echo date('d M Y', strtotime($row['uploaded_at'])); ?></td>
                <td>
                    <div class="action-group">
                        <?php if ($can_preview): ?>
                        <a class="act-btn view"
                           href="<?php echo htmlspecialchars($view_url); ?>"
                           target="_blank">👁 View</a>
                        <?php else: ?>
                        <span class="act-btn view disabled" title="PDF conversion failed — re-upload">👁 No Preview</span>
                        <?php endif; ?>

                        <a class="act-btn dl"
                           href="<?php echo htmlspecialchars($orig_url); ?>"
                           download="<?php echo htmlspecialchars(basename($row['file_path'])); ?>">
                            ⬇ Download
                        </a>

                        <a class="act-btn del"
                           href="add_materials.php?delete=<?php echo $row['id']; ?>"
                           onclick="return confirm('Delete \'<?php echo htmlspecialchars(addslashes($row['title'])); ?>\'? This cannot be undone.')">
                            🗑 Delete
                        </a>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state">No materials uploaded yet.</div>
        <?php endif; ?>
    </div>
</div>

<script>
function showFile(input) {
    const el = document.getElementById('fileChosen');
    if (input.files && input.files[0]) {
        el.textContent = '📎 ' + input.files[0].name;
        el.style.display = 'block';
    }
}
const zone = document.getElementById('dropZone');
['dragenter','dragover'].forEach(e => zone.addEventListener(e, ev => { ev.preventDefault(); zone.classList.add('dragover'); }));
['dragleave','drop'].forEach(e => zone.addEventListener(e, ev => { ev.preventDefault(); zone.classList.remove('dragover'); }));
zone.addEventListener('drop', e => {
    const fi = document.getElementById('material_file');
    if (e.dataTransfer.files.length) { fi.files = e.dataTransfer.files; showFile(fi); }
});
</script>
</body>
</html>