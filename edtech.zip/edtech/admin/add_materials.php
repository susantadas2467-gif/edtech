
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

require_admin();

$error = '';
$success = '';

$projectRoot = dirname(__DIR__);
$uploadBase = $projectRoot . DIRECTORY_SEPARATOR
            . 'uploads' . DIRECTORY_SEPARATOR . 'materials';

$libreOffice = 'C:\\Program Files\\LibreOffice\\program\\soffice.exe';

$allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx'];
$maxSize = 20 * 1024 * 1024; // 20 MB

// Convert stored project-relative paths to absolute filesystem paths.
function material_absolute_path(string $relativePath): string
{
    $root = dirname(__DIR__);
    $relativePath = str_replace('\\', '/', $relativePath);
    $relativePath = ltrim($relativePath, '/');

    return $root . DIRECTORY_SEPARATOR
        . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
}

// DELETE MATERIAL
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    if ($id > 0) {
        $stmt = $conn->prepare(
            "SELECT file_path, pdf_path FROM materials WHERE id = ?"
        );

        if ($stmt) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $material = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($material) {
                // Only delete files inside the materials upload directory.
                $baseReal = realpath($uploadBase);

                foreach (['file_path', 'pdf_path'] as $column) {
                    $relative = $material[$column] ?? '';

                    if ($relative === '') {
                        continue;
                    }

                    $absolute = material_absolute_path($relative);
                    $fileReal = realpath($absolute);

                    if (
                        $baseReal !== false &&
                        $fileReal !== false &&
                        is_file($fileReal) &&
                        strpos(
                            $fileReal,
                            $baseReal . DIRECTORY_SEPARATOR
                        ) === 0
                    ) {
                        @unlink($fileReal);
                    }
                }

                $delete = $conn->prepare(
                    "DELETE FROM materials WHERE id = ?"
                );

                if ($delete) {
                    $delete->bind_param('i', $id);
                    $delete->execute();
                    $delete->close();

                    set_flash('success', 'Material deleted successfully.');
                }
            }
        }
    }

    header('Location: add_materials.php');
    exit;
}

// UPLOAD MATERIAL
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $class = trim($_POST['class'] ?? '');

    if ($title === '' || $subject === '') {
        $error = 'Please enter the material title and subject.';

    } elseif (!in_array($class, ['9', '10'], true)) {
        $error = 'Please select Class 9 or Class 10.';

    } elseif (
        !isset($_FILES['material_file']) ||
        !is_array($_FILES['material_file']) ||
        $_FILES['material_file']['error'] !== UPLOAD_ERR_OK
    ) {
        $uploadError = $_FILES['material_file']['error'] ?? null;

        $error = match ($uploadError) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE =>
                'The uploaded file exceeds the permitted size.',
            UPLOAD_ERR_NO_FILE =>
                'Please select a file to upload.',
            UPLOAD_ERR_PARTIAL =>
                'The file was only partially uploaded. Try again.',
            default =>
                'File upload failed. Check your PHP upload settings.'
        };

    } else {
        $file = $_FILES['material_file'];
        $extension = strtolower(
            pathinfo($file['name'], PATHINFO_EXTENSION)
        );

        if (
            !is_uploaded_file($file['tmp_name']) ||
            !isset($file['size']) ||
            $file['size'] <= 0
        ) {
            $error = 'The uploaded file is invalid.';

        } elseif ($file['size'] > $maxSize) {
            $error = 'Maximum file size is 20 MB.';

        } elseif (!in_array($extension, $allowedExtensions, true)) {
            $error = 'Allowed file types: PDF, DOC, DOCX, PPT and PPTX.';

        } else {
            $classFolder = 'class' . $class;
            $targetDir = $uploadBase . DIRECTORY_SEPARATOR . $classFolder;

            // Create folders safely. Existing directories are acceptable.
            if (
                !is_dir($uploadBase) &&
                !@mkdir($uploadBase, 0775, true) &&
                !is_dir($uploadBase)
            ) {
                $error = 'Cannot create uploads/materials. Check permissions.';

            } elseif (
                !is_dir($targetDir) &&
                !@mkdir($targetDir, 0775, true) &&
                !is_dir($targetDir)
            ) {
                $error = 'Cannot create the class folder. Check permissions.';

            } elseif (!is_writable($targetDir)) {
                $error = 'The class folder is not writable by PHP.';
            }

            if ($error === '') {
                $originalBase = preg_replace(
                    '/[^a-zA-Z0-9_-]/',
                    '_',
                    pathinfo($file['name'], PATHINFO_FILENAME)
                );

                if ($originalBase === '') {
                    $originalBase = 'material';
                }

                $uniqueName = $originalBase . '_'
                    . date('Ymd_His') . '_'
                    . bin2hex(random_bytes(4)) . '.'
                    . $extension;

                $targetPath = $targetDir . DIRECTORY_SEPARATOR . $uniqueName;

                if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $error = 'Could not save the uploaded file. Check folder permissions.';
                } else {
                    $dbPath = 'uploads/materials/'
                        . $classFolder . '/' . $uniqueName;

                    $pdfPath = null;
                    $conversionFailed = false;

                    // Generate a PDF preview for Word and PowerPoint files.
                    if ($extension !== 'pdf') {
                        if (is_file($libreOffice)) {
                            // Use a unique LibreOffice profile to avoid
                            // conflicts between simultaneous conversions.
                            $profileDir = sys_get_temp_dir()
                                . DIRECTORY_SEPARATOR
                                . 'lo_profile_' . bin2hex(random_bytes(6));

                            $profileUrl = 'file:///'
                                . str_replace(
                                    '\\',
                                    '/',
                                    $profileDir
                                );

                            $pdfName = pathinfo(
                                $uniqueName,
                                PATHINFO_FILENAME
                            ) . '.pdf';

                            $expectedPdf = $targetDir
                                . DIRECTORY_SEPARATOR . $pdfName;

                            $command = '"' . $libreOffice . '"'
                                . ' -env:UserInstallation='
                                . escapeshellarg($profileUrl)
                                . ' --headless --convert-to pdf'
                                . ' --outdir '
                                . escapeshellarg($targetDir)
                                . ' ' . escapeshellarg($targetPath)
                                . ' 2>&1';

                            $output = [];
                            $returnCode = 1;

                            exec($command, $output, $returnCode);

                            if (
                                $returnCode === 0 &&
                                is_file($expectedPdf) &&
                                filesize($expectedPdf) > 0
                            ) {
                                $pdfPath = 'uploads/materials/'
                                    . $classFolder . '/' . $pdfName;
                            } else {
                                $conversionFailed = true;
                                error_log(
                                    'LibreOffice conversion failed: '
                                    . implode("\n", $output)
                                );
                            }

                            // Remove the temporary profile if possible.
                            if (is_dir($profileDir)) {
                                foreach (
                                    glob($profileDir . DIRECTORY_SEPARATOR . '*')
                                    ?: [] as $profileFile
                                ) {
                                    if (is_file($profileFile)) {
                                        @unlink($profileFile);
                                    }
                                }
                                @rmdir($profileDir);
                            }
                        } else {
                            $conversionFailed = true;
                            error_log(
                                'LibreOffice not found at: ' . $libreOffice
                            );
                        }
                    }

                    $uploadedBy = (int) ($_SESSION['user_id'] ?? 0);

                    $stmt = $conn->prepare(
                        "INSERT INTO materials
                        (title, subject, `class`, file_path, pdf_path, uploaded_by)
                        VALUES (?, ?, ?, ?, ?, ?)"
                    );

                    if (!$stmt) {
                        $error = 'Could not prepare the database query.';
                        error_log('Material prepare failed: ' . $conn->error);
                    } else {
                        $stmt->bind_param(
                            'sssssi',
                            $title,
                            $subject,
                            $class,
                            $dbPath,
                            $pdfPath,
                            $uploadedBy
                        );

                        if ($stmt->execute()) {
                            $message = 'Material uploaded successfully for Class '
                                . $class . '.';

                            if ($conversionFailed) {
                                $message .=
                                    ' The original file is saved, but PDF preview conversion failed.';
                            } elseif ($pdfPath !== null) {
                                $message .= ' PDF preview is ready.';
                            }

                            $stmt->close();
                            set_flash('success', $message);
                            header('Location: add_materials.php');
                            exit;
                        }

                        error_log('Material insert failed: ' . $stmt->error);
                        $stmt->close();
                        $error = 'Could not save the material in the database.';
                    }

                    // Do not leave an unregistered upload behind.
                    if ($error !== '') {
                        if (is_file($targetPath)) {
                            @unlink($targetPath);
                        }

                        if ($pdfPath !== null) {
                            $generatedPdf = material_absolute_path($pdfPath);
                            if (is_file($generatedPdf)) {
                                @unlink($generatedPdf);
                            }
                        }
                    }
                }
            }
        }
    }
}

// RECENT MATERIALS
$recent = $conn->query(
    "SELECT m.id, m.title, m.subject, m.class,
            m.file_path, m.pdf_path, m.uploaded_at,
            u.name AS uploader
     FROM materials m
     LEFT JOIN users u ON m.uploaded_by = u.id
     ORDER BY m.uploaded_at DESC
     LIMIT 30"
);

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Study Materials | EdTech Admin</title>
<style>
* { box-sizing: border-box; }

body {
    margin: 0;
    background: #f5f0e7;
    color: #191a30;
    font-family: Arial, Helvetica, sans-serif;
}

header {
    background: #19182d;
    color: white;
    padding: 18px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
}

header a { color: white; text-decoration: none; }

.brand { font-family: Georgia, serif; font-size: 23px; }

main {
    width: min(100% - 32px, 1000px);
    margin: 42px auto;
}

h1, h2 { font-family: Georgia, serif; }

.subtitle { color: #73778b; margin-top: -8px; }

.notice, .message, .error {
    padding: 14px 16px;
    border-radius: 10px;
    margin: 22px 0;
    overflow-wrap: anywhere;
}

.notice { background: #f3ead8; border: 1px solid #e7d7b4; }
.message { background: #e7f7eb; color: #176534; }
.error { background: #fff0ef; color: #b42318; border: 1px solid #f4c7c3; }

.panel {
    background: #fffdfa;
    border: 1px solid #dedbd5;
    border-radius: 14px;
    padding: 26px;
    margin: 24px 0;
}

label {
    display: block;
    margin: 18px 0 8px;
    color: #626b80;
    font-size: 13px;
    font-weight: bold;
    text-transform: uppercase;
}

input, select {
    width: 100%;
    padding: 13px;
    border: 1px solid #d8dbe2;
    border-radius: 9px;
    background: white;
    font-size: 15px;
}

button, .action {
    display: inline-block;
    border: 0;
    border-radius: 8px;
    padding: 11px 16px;
    margin-top: 20px;
    background: #19182d;
    color: white;
    text-decoration: none;
    cursor: pointer;
    font-size: 14px;
}

button:hover, .action:hover { opacity: .88; }

.table-wrap { overflow-x: auto; }

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 650px;
}

th, td {
    text-align: left;
    padding: 13px 10px;
    border-bottom: 1px solid #e8e5df;
    overflow-wrap: anywhere;
}

th { color: #626b80; font-size: 12px; }

.delete { color: #b42318; }

.small { color: #777; font-size: 13px; }

@media (max-width: 600px) {
    header { padding: 16px; }
    .brand { font-size: 19px; }
    main { width: calc(100% - 22px); margin: 24px auto; }
    .panel { padding: 17px; }
}
</style>
</head>
<body>

<header>
    <div class="brand">📚 edtech admin</div>
    <a href="dashboard.php">← Back to Dashboard</a>
</header>

<main>
    <h1>Add Study Material</h1>
    <p class="subtitle">Upload notes, worksheets, and resources for students.</p>

    <div class="notice">
        💡 PDF, DOC, DOCX, PPT and PPTX are accepted.
        Word and PowerPoint files are converted to PDF using LibreOffice
        when available. The original file is kept for download.
    </div>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div class="message">
            <?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php elseif (is_string($flash) && $flash !== ''): ?>
        <div class="message">
            <?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <section class="panel">
        <h2>📤 Upload New Material</h2>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="MAX_FILE_SIZE" value="20971520">

            <label for="title">Material title</label>
            <input id="title" name="title" type="text"
                   maxlength="200" required>

            <label for="subject">Subject</label>
            <input id="subject" name="subject" type="text"
                   maxlength="100" required>

            <label for="class">Class</label>
            <select id="class" name="class" required>
                <option value="">Select class</option>
                <option value="9">Class 9</option>
                <option value="10">Class 10</option>
            </select>

            <label for="material_file">Choose file</label>
            <input id="material_file" name="material_file"
                   type="file"
                   accept=".pdf,.doc,.docx,.ppt,.pptx"
                   required>

            <p class="small">Maximum size: 20 MB.</p>
            <button type="submit">Upload Material</button>
        </form>
    </section>

    <section class="panel">
        <h2>Recently Uploaded Materials</h2>

        <?php if (!$recent): ?>
            <p>Unable to load materials. Check your database configuration.</p>

        <?php elseif ($recent->num_rows === 0): ?>
            <p>No materials have been uploaded yet.</p>

        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Subject</th>
                            <th>Class</th>
                            <th>Preview</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $recent->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <?= htmlspecialchars($row['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($row['subject'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($row['class'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                            </td>
                            <td>
                                <?php if (!empty($row['pdf_path'])): ?>
                                    <a href="../<?= htmlspecialchars(
                                        $row['pdf_path'], ENT_QUOTES, 'UTF-8'
                                    ) ?>" target="_blank" rel="noopener">
                                        View PDF
                                    </a>
                                <?php elseif (!empty($row['file_path'])): ?>
                                    <a href="../<?= htmlspecialchars(
                                        $row['file_path'], ENT_QUOTES, 'UTF-8'
                                    ) ?>" target="_blank" rel="noopener">
                                        Open original
                                    </a>
                                <?php else: ?>
                                    Not available
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="delete"
                                   href="add_materials.php?delete=<?= (int)$row['id'] ?>"
                                   onclick="return confirm('Delete this material and its saved files?');">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
