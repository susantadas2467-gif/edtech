<?php
require_once "../includes/auth.php";

echo "Before require_admin()<br>";

require_admin();

echo "After require_admin()<br>";