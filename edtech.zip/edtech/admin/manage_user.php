<?php
// admin/manage_user.php
require_once '../includes/auth.php';
require_once "../includes/flash.php";


require_admin();

$error   = "";
$success = "";

// ── DELETE USER ──
if (isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];

    // Prevent admin from deleting themselves
    if ($delete_id === (int)$_SESSION['user_id']) {
        set_flash('error', "You can't delete your own account.");
    } else {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $delete_id);
        if ($stmt->execute()) {
            set_flash('success', "User deleted successfully.");
        } else {
            set_flash('error', "Failed to delete user.");
        }
        $stmt->close();
    }
    header("Location: manage_user.php");
    exit();
}

// ── UPDATE USER (role / class) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $user_id   = (int)$_POST['user_id'];
    $new_role  = $_POST['role'];
    $new_class = $_POST['class'] !== '' ? $_POST['class'] : null;

    if (!in_array($new_role, ['admin', 'student', 'teacher'])) {
        $error = "Invalid role selected.";
    } else {
        $stmt = $conn->prepare("UPDATE users SET role = ?, `class` = ? WHERE id = ?");
        $stmt->bind_param("ssi", $new_role, $new_class, $user_id);
        if ($stmt->execute()) {
            set_flash('success', "User updated successfully.");
        } else {
            set_flash('error', "Failed to update user.");
        }
        $stmt->close();
        header("Location: manage_user.php");
        exit();
    }
}

// ── SEARCH / FILTER ──
$search       = trim($_GET['search'] ?? '');
$filter_role  = $_GET['role']  ?? '';
$filter_class = $_GET['class'] ?? '';

$sql = "SELECT id, name, email, role, `class`, created_at FROM users WHERE 1=1";
$params = [];
$types  = "";

if ($search !== '') {
    $sql .= " AND (name LIKE ? OR email LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $types .= "ss";
}
if ($filter_role !== '') {
    $sql .= " AND role = ?";
    $params[] = $filter_role;
    $types .= "s";
}
if ($filter_class !== '') {
    $sql .= " AND `class` = ?";
    $params[] = $filter_class;
    $types .= "s";
}
$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$users = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Manage Users</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #1a1a2e;
            --ink2:   #2e2e4a;
            --cream:  #f5f0e8;
            --paper:  #faf7f2;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --red:    #c0392b;
            --green:  #1e7e4a;
            --blue:   #2563eb;
            --border: rgba(26,26,46,0.12);
        }

        html, body {
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
            min-height: 100vh;
        }

        .topbar {
            background: var(--ink);
            padding: 18px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .brand { display: flex; align-items: center; gap: 10px; }
        .brand-icon {
            width: 32px; height: 32px;
            background: var(--gold);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
        }
        .brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 18px; color: var(--cream);
        }
        .topbar a {
            color: rgba(245,240,232,0.7);
            text-decoration: none;
            font-size: 13.5px;
        }
        .topbar a:hover { color: var(--gold2); }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 48px 24px 80px;
        }

        .page-header { margin-bottom: 28px; }
        .page-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 30px;
            margin-bottom: 6px;
        }
        .page-header p { color: var(--muted); font-size: 14px; }

        /* ── Alerts ── */
        .alert {
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 20px;
            font-size: 13.5px;
            display: flex; align-items: center; gap: 8px;
        }
        .alert-error {
            background: #fdf0ef;
            border: 1px solid rgba(192,57,43,0.25);
            border-left: 3px solid var(--red);
            color: var(--red);
        }
        .alert-success {
            background: #edfbf3;
            border: 1px solid rgba(30,126,74,0.25);
            border-left: 3px solid var(--green);
            color: var(--green);
        }

        /* ── Filter bar ── */
        .filter-bar {
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px 18px;
            margin-bottom: 24px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .filter-bar input, .filter-bar select {
            padding: 9px 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-size: 13.5px;
            background: #fff;
            outline: none;
        }
        .filter-bar input:focus, .filter-bar select:focus {
            border-color: var(--gold);
        }
        .filter-bar input[type="text"] { flex: 1; min-width: 180px; }
        .filter-btn {
            padding: 9px 18px;
            background: var(--ink);
            color: var(--cream);
            border: none;
            border-radius: 8px;
            font-size: 13.5px;
            cursor: pointer;
        }
        .filter-btn:hover { background: var(--ink2); }
        .clear-link {
            display: flex; align-items: center;
            font-size: 13px; color: var(--muted);
            text-decoration: none;
        }
        .clear-link:hover { color: var(--red); }

        /* ── Table ── */
        .table-card {
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 14px;
            overflow: hidden;
        }
        table { width: 100%; border-collapse: collapse; }
        thead { background: var(--ink); }
        thead th {
            color: var(--cream);
            font-size: 11.5px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            text-align: left;
            padding: 14px 16px;
            font-weight: 500;
        }
        tbody tr {
            border-bottom: 1px solid var(--border);
            transition: background 0.15s;
        }
        tbody tr:last-child { border-bottom: none; }
        tbody tr:hover { background: rgba(201,168,76,0.04); }
        tbody td {
            padding: 14px 16px;
            font-size: 13.5px;
        }

        .user-name { font-weight: 500; }
        .user-email { color: var(--muted); font-size: 12.5px; }

        .badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 500;
            text-transform: capitalize;
        }
        .badge-admin   { background: rgba(192,57,43,0.1);  color: var(--red); }
        .badge-teacher { background: rgba(37,99,235,0.1);  color: var(--blue); }
        .badge-student { background: rgba(30,126,74,0.1);  color: var(--green); }

        .actions { display: flex; gap: 8px; }
        .action-btn {
            padding: 6px 12px;
            border-radius: 7px;
            font-size: 12px;
            text-decoration: none;
            border: 1px solid var(--border);
            cursor: pointer;
            background: #fff;
            transition: all 0.15s;
        }
        .edit-btn { color: var(--ink); }
        .edit-btn:hover { border-color: var(--gold); background: rgba(201,168,76,0.06); }
        .delete-btn { color: var(--red); }
        .delete-btn:hover { background: #fdf0ef; border-color: rgba(192,57,43,0.3); }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted);
        }

        /* ── Modal ── */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(26,26,46,0.55);
            z-index: 100;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay.show { display: flex; }
        .modal {
            background: var(--paper);
            border-radius: 14px;
            padding: 28px;
            width: 100%;
            max-width: 380px;
        }
        .modal h3 {
            font-family: 'Playfair Display', serif;
            font-size: 19px;
            margin-bottom: 18px;
        }
        .modal .form-group { margin-bottom: 16px; }
        .modal label {
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--muted);
            margin-bottom: 6px;
        }
        .modal select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-size: 14px;
        }
        .modal-actions {
            display: flex; gap: 10px;
            margin-top: 20px;
        }
        .modal-actions button {
            flex: 1;
            padding: 11px;
            border-radius: 8px;
            border: none;
            font-size: 14px;
            cursor: pointer;
        }
        .btn-save { background: var(--ink); color: var(--cream); }
        .btn-save:hover { background: var(--ink2); }
        .btn-cancel { background: #fff; border: 1px solid var(--border) !important; color: var(--muted); }

        @media (max-width: 720px) {
            .table-card { overflow-x: auto; }
            table { min-width: 640px; }
        }
    </style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech admin</span>
    </div>
    <a href="dashboard.php">← Back to Dashboard</a>
</div>

<div class="container">
    <div class="page-header">
        <h1>Manage Users</h1>
        <p>View, edit roles/classes, and remove user accounts.</p>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($flash): ?>
    <div class="alert alert-<?php echo $flash['type'] === 'success' ? 'success' : 'error'; ?>">
        <?php echo $flash['type'] === 'success' ? '✓' : '⚠️'; ?> <?php echo htmlspecialchars($flash['message']); ?>
    </div>
    <?php endif; ?>

    <!-- Filter bar -->
    <form method="GET" action="manage_user.php" class="filter-bar">
        <input type="text" name="search" placeholder="Search by name or email..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="role">
            <option value="">All Roles</option>
            <option value="admin"   <?php echo $filter_role === 'admin' ? 'selected' : ''; ?>>Admin</option>
            <option value="teacher" <?php echo $filter_role === 'teacher' ? 'selected' : ''; ?>>Teacher</option>
            <option value="student" <?php echo $filter_role === 'student' ? 'selected' : ''; ?>>Student</option>
        </select>
        <select name="class">
            <option value="">All Classes</option>
            <option value="9"  <?php echo $filter_class === '9' ? 'selected' : ''; ?>>Class 9</option>
            <option value="10" <?php echo $filter_class === '10' ? 'selected' : ''; ?>>Class 10</option>
        </select>
        <button type="submit" class="filter-btn">Filter</button>
        <?php if ($search || $filter_role || $filter_class): ?>
        <a href="manage_user.php" class="clear-link">Clear filters ✕</a>
        <?php endif; ?>
    </form>

    <!-- Users table -->
    <div class="table-card">
        <?php if (empty($users)): ?>
        <div class="empty-state">No users found.</div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Class</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td>
                        <div class="user-name"><?php echo htmlspecialchars($u['name']); ?></div>
                        <div class="user-email"><?php echo htmlspecialchars($u['email']); ?></div>
                    </td>
                    <td><span class="badge badge-<?php echo htmlspecialchars($u['role']); ?>"><?php echo htmlspecialchars($u['role']); ?></span></td>
                    <td><?php echo $u['class'] ? 'Class ' . htmlspecialchars($u['class']) : '—'; ?></td>
                    <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                    <td>
                        <div class="actions">
                            <button type="button" class="action-btn edit-btn"
                                onclick="openEdit(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['role'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($u['class'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($u['name'], ENT_QUOTES); ?>')">
                                Edit
                            </button>
                            <a href="manage_user.php?delete=<?php echo $u['id']; ?>"
                               class="action-btn delete-btn"
                               onclick="return confirm('Delete <?php echo htmlspecialchars($u['name'], ENT_QUOTES); ?>? This cannot be undone.');">
                                Delete
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <h3 id="modalTitle">Edit User</h3>
        <form method="POST" action="manage_user.php">
            <input type="hidden" name="user_id" id="edit_user_id">
            <input type="hidden" name="update_user" value="1">

            <div class="form-group">
                <label>Role</label>
                <select name="role" id="edit_role" onchange="toggleClassField()">
                    <option value="admin">Admin</option>
                    <option value="teacher">Teacher</option>
                    <option value="student">Student</option>
                </select>
            </div>

            <div class="form-group" id="classFieldWrap">
                <label>Class</label>
                <select name="class" id="edit_class">
                    <option value="">— None —</option>
                    <option value="9">Class 9</option>
                    <option value="10">Class 10</option>
                </select>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeEdit()">Cancel</button>
                <button type="submit" class="btn-save">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(id, role, userClass, name) {
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_class').value = userClass;
    document.getElementById('modalTitle').textContent = 'Edit ' + name;
    toggleClassField();
    document.getElementById('editModal').classList.add('show');
}
function closeEdit() {
    document.getElementById('editModal').classList.remove('show');
}
function toggleClassField() {
    const role = document.getElementById('edit_role').value;
    document.getElementById('classFieldWrap').style.display = role === 'student' ? 'block' : 'none';
}
// Close modal on outside click
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeEdit();
});
</script>

</body>
</html>