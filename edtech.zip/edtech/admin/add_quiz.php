<?php
// admin/add_quiz.php
require_once '../includes/auth.php';
require_once "../includes/flash.php";

require_admin();

$error   = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quiz_title = trim($_POST['quiz_title'] ?? '');
    $subject    = trim($_POST['subject'] ?? '');
    $class      = $_POST['class'] ?? '';

    $q_text     = $_POST['question_text']   ?? [];
    $q_type     = $_POST['question_type']   ?? [];
    $opt_a      = $_POST['option_a']        ?? [];
    $opt_b      = $_POST['option_b']        ?? [];
    $opt_c      = $_POST['option_c']        ?? [];
    $opt_d      = $_POST['option_d']        ?? [];
    $correct_opt = $_POST['correct_option'] ?? [];
    $correct_txt = $_POST['correct_answer_text'] ?? [];
    $marks       = $_POST['marks']          ?? [];

    // ── Validation ──
    if (empty($quiz_title) || empty($subject) || empty($class)) {
        $error = "Please fill in quiz title, subject, and class.";
    } elseif (empty($q_text) || count(array_filter($q_text)) === 0) {
        $error = "Please add at least one question.";
    } else {
        // Validate each question has required fields based on type
        $valid = true;
        foreach ($q_text as $i => $text) {
            if (empty(trim($text))) { $valid = false; break; }

            if ($q_type[$i] === 'mcq') {
                if (empty($opt_a[$i]) || empty($opt_b[$i]) || empty($opt_c[$i]) || empty($opt_d[$i]) || empty($correct_opt[$i])) {
                    $valid = false; break;
                }
            } else { // short_answer
                if (empty(trim($correct_txt[$i] ?? ''))) {
                    $valid = false; break;
                }
            }
        }

        if (!$valid) {
            $error = "Please complete all fields for every question.";
        } else {
            // ── Insert quiz ──
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("INSERT INTO quizzes (title, subject, `class`, created_by) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("sssi", $quiz_title, $subject, $class, $_SESSION['user_id']);
                $stmt->execute();
                $quiz_id = $conn->insert_id;
                $stmt->close();

                // ── Insert each question ──
                $qStmt = $conn->prepare(
                    "INSERT INTO questions
                        (quiz_id, question_text, question_type, option_a, option_b, option_c, option_d, correct_option, correct_answer_text, marks)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );

                foreach ($q_text as $i => $text) {
                    $type = $q_type[$i] === 'mcq' ? 'mcq' : 'short_answer';
                    $a = $type === 'mcq' ? $opt_a[$i] : null;
                    $b = $type === 'mcq' ? $opt_b[$i] : null;
                    $c = $type === 'mcq' ? $opt_c[$i] : null;
                    $d = $type === 'mcq' ? $opt_d[$i] : null;
                    $correct = $type === 'mcq' ? $correct_opt[$i] : null;
                    $shortAns = $type === 'short_answer' ? trim($correct_txt[$i]) : null;
                    $mark = (int)($marks[$i] ?? 1);
                    if ($mark < 1) $mark = 1;

                    $qStmt->bind_param(
                        "ississsssi",
                        $quiz_id, $text, $type, $a, $b, $c, $d, $correct, $shortAns, $mark
                    );
                    $qStmt->execute();
                }
                $qStmt->close();

                $conn->commit();
                set_flash('success', "Quiz \"$quiz_title\" added with " . count($q_text) . " question(s).");
                header("Location: add_quiz.php");
                exit();

            } catch (Exception $e) {
                $conn->rollback();
                $error = "Failed to save quiz. Please try again.";
                error_log("Quiz insert failed: " . $e->getMessage());
            }
        }
    }
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Add Quiz</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #1a1a2e;
            --ink2:   #2e2e4a;
            --cream:  #f5f0e8;
            --paper:  #faf7f2;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --red:    #c0392b;
            --green:  #1e7e4a;
            --border: rgba(26,26,46,0.12);
        }

        html, body {
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
            min-height: 100vh;
        }

        .topbar {
            background: var(--ink);
            padding: 18px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .brand {
            display: flex; align-items: center; gap: 10px;
        }
        .brand-icon {
            width: 32px; height: 32px;
            background: var(--gold);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
        }
        .brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 18px; color: var(--cream);
        }
        .topbar a {
            color: rgba(245,240,232,0.7);
            text-decoration: none;
            font-size: 13.5px;
        }
        .topbar a:hover { color: var(--gold2); }

        .container {
            max-width: 760px;
            margin: 0 auto;
            padding: 48px 24px 80px;
        }

        .page-header { margin-bottom: 32px; }
        .page-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            margin-bottom: 6px;
        }
        .page-header p { color: var(--muted); font-size: 14px; }

        /* ── Alerts ── */
        .alert {
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 24px;
            font-size: 13.5px;
            display: flex; align-items: center; gap: 8px;
        }
        .alert-error {
            background: #fdf0ef;
            border: 1px solid rgba(192,57,43,0.25);
            border-left: 3px solid var(--red);
            color: var(--red);
        }
        .alert-success {
            background: #edfbf3;
            border: 1px solid rgba(30,126,74,0.25);
            border-left: 3px solid var(--green);
            color: var(--green);
        }

        /* ── Card sections ── */
        .card {
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 28px;
            margin-bottom: 24px;
        }
        .card h2 {
            font-family: 'Playfair Display', serif;
            font-size: 18px;
            margin-bottom: 18px;
            display: flex; align-items: center; gap: 8px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 14px;
        }
        .form-group { margin-bottom: 16px; }

        label {
            display: block;
            font-size: 12px; font-weight: 500;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 7px;
        }

        input[type="text"], input[type="number"], select, textarea {
            width: 100%;
            padding: 11px 13px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 14.5px;
            color: var(--ink);
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        textarea { resize: vertical; min-height: 60px; }
        input:focus, select:focus, textarea:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(201,168,76,0.12);
        }

        /* ── Question block ── */
        .question-block {
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 18px;
            background: #fff;
            position: relative;
        }
        .question-block-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }
        .question-num {
            font-family: 'Playfair Display', serif;
            font-size: 15px;
            color: var(--gold);
        }
        .remove-btn {
            background: none;
            border: none;
            color: var(--red);
            cursor: pointer;
            font-size: 12.5px;
            display: flex; align-items: center; gap: 4px;
        }
        .remove-btn:hover { text-decoration: underline; }

        .type-toggle {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
        }
        .type-btn {
            flex: 1;
            text-align: center;
            padding: 9px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 13px;
            color: var(--muted);
            cursor: pointer;
            background: var(--paper);
            transition: all 0.15s;
        }
        .type-btn.active {
            border-color: var(--gold);
            background: rgba(201,168,76,0.08);
            color: var(--ink);
            font-weight: 500;
        }

        .options-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 14px;
        }
        .option-input { position: relative; }
        .option-letter {
            position: absolute;
            left: 12px; top: 50%;
            transform: translateY(-50%);
            font-size: 12px;
            font-weight: 600;
            color: var(--gold);
        }
        .option-input input { padding-left: 32px; }

        .correct-select-wrap {
            margin-bottom: 4px;
        }

        .marks-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-top: 14px;
        }

        .short-answer-section { display: none; }
        .mcq-section { display: block; }

        /* ── Buttons ── */
        .btn-add-question {
            width: 100%;
            padding: 13px;
            background: transparent;
            border: 1.5px dashed var(--gold);
            border-radius: 10px;
            color: var(--ink);
            font-size: 14px; font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-add-question:hover { background: rgba(201,168,76,0.06); }

        .btn-submit {
            width: 100%; padding: 15px;
            background: var(--ink); color: var(--cream);
            border: none; border-radius: 10px;
            font-size: 15px; font-weight: 500;
            cursor: pointer; letter-spacing: 0.02em;
            margin-top: 8px;
            transition: background 0.2s;
        }
        .btn-submit:hover { background: var(--ink2); }

        @media (max-width: 640px) {
            .form-row { grid-template-columns: 1fr; }
            .options-grid { grid-template-columns: 1fr; }
            .marks-row { grid-template-columns: 1fr; }
            .container { padding: 32px 16px 60px; }
        }
    </style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech admin</span>
    </div>
    <a href="dashboard.php">← Back to Dashboard</a>
</div>

<div class="container">
    <div class="page-header">
        <h1>Add New Quiz</h1>
        <p>Create a quiz with multiple-choice and short-answer questions.</p>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($flash): ?>
    <div class="alert alert-<?php echo $flash['type'] === 'success' ? 'success' : 'error'; ?>">
        ✓ <?php echo htmlspecialchars($flash['message']); ?>
    </div>
    <?php endif; ?>

    <form method="POST"  enctype="multipart/form-data"></form>="add_quiz.php" id="quizForm">

        <!-- Quiz Info -->
        <div class="card">
            <h2>📝 Quiz Details</h2>
            <div class="form-group">
                <label for="quiz_title">Quiz Title</label>
                <input type="text" id="quiz_title" name="quiz_title" placeholder="e.g. Chapter 3 — Light and Reflection" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="e.g. Science" required>
                </div>
                <div class="form-group">
                    <label for="class">Class</label>
                    <select id="class" name="class" required>
                        <option value="">Select</option>
                        <option value="9">Class 9</option>
                        <option value="10">Class 10</option>
                    </select>
                    <div class="form-group">
    <label for="quiz_pdf">Quiz PDF</label>
    <input
        type="file"
        id="quiz_pdf"
        name="quiz_pdf"
        accept=".pdf"
        required>

                </div>
                <div class="form-group">
                    <!-- spacer for grid alignment -->
                </div>
            </div>
        </div>

        <!-- Questions Container -->
        <div id="questionsContainer"></div>

        <button type="button" class="btn-add-question" onclick="addQuestion()">+ Add Question</button>

        <button type="submit" class="btn-submit">Save Quiz →</button>
    </form>
</div>

<template id="questionTemplate">
    <div class="question-block">
        <div class="question-block-header">
            <span class="question-num">Question __NUM__</span>
            <button type="button" class="remove-btn" onclick="removeQuestion(this)">✕ Remove</button>
        </div>

        <div class="type-toggle">
            <div class="type-btn active" data-type="mcq" onclick="setType(this, 'mcq')">Multiple Choice</div>
            <div class="type-btn" data-type="short_answer" onclick="setType(this, 'short_answer')">Short Answer</div>
        </div>

        <input type="hidden" name="question_type[]" class="type-input" value="mcq">

        <div class="form-group">
            <label>Question Text</label>
            <textarea name="question_text[]" placeholder="Enter the question..." required></textarea>
        </div>

        <div class="mcq-section">
            <div class="options-grid">
                <div class="option-input">
                    <span class="option-letter">A</span>
                    <input type="text" name="option_a[]" placeholder="Option A">
                </div>
                <div class="option-input">
                    <span class="option-letter">B</span>
                    <input type="text" name="option_b[]" placeholder="Option B">
                </div>
                <div class="option-input">
                    <span class="option-letter">C</span>
                    <input type="text" name="option_c[]" placeholder="Option C">
                </div>
                <div class="option-input">
                    <span class="option-letter">D</span>
                    <input type="text" name="option_d[]" placeholder="Option D">
                </div>
            </div>
            <div class="form-group correct-select-wrap">
                <label>Correct Option</label>
                <select name="correct_option[]">
                    <option value="">Select correct option</option>
                    <option value="a">A</option>
                    <option value="b">B</option>
                    <option value="c">C</option>
                    <option value="d">D</option>
                </select>
            </div>
        </div>

        <div class="short-answer-section">
            <div class="form-group">
                <label>Correct Answer</label>
                <input type="text" name="correct_answer_text[]" placeholder="Expected correct answer">
            </div>
        </div>

        <div class="marks-row">
            <div class="form-group">
                <label>Marks</label>
                <input type="number" name="marks[]" value="1" min="1" max="20">
            </div>
        </div>
    </div>
</template>

<script>
let questionCount = 0;

function addQuestion() {
    questionCount++;
    const template = document.getElementById('questionTemplate');
    const clone = template.content.cloneNode(true);
    clone.querySelector('.question-num').textContent = 'Question ' + questionCount;
    document.getElementById('questionsContainer').appendChild(clone);
    renumber();
}

function removeQuestion(btn) {
    btn.closest('.question-block').remove();
    renumber();
}

function renumber() {
    const blocks = document.querySelectorAll('.question-block');
    blocks.forEach((block, i) => {
        block.querySelector('.question-num').textContent = 'Question ' + (i + 1);
    });
    questionCount = blocks.length;
}

function setType(btn, type) {
    const block = btn.closest('.question-block');
    block.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    block.querySelector('.type-input').value = type;

    const mcqSection = block.querySelector('.mcq-section');
    const shortSection = block.querySelector('.short-answer-section');

    if (type === 'mcq') {
        mcqSection.style.display = 'block';
        shortSection.style.display = 'none';
    } else {
        mcqSection.style.display = 'none';
        shortSection.style.display = 'block';
    }
}

// Add one question block by default on page load
window.addEventListener('DOMContentLoaded', () => addQuestion());

// Prevent submitting with zero questions
document.getElementById('quizForm').addEventListener('submit', function(e) {
    const blocks = document.querySelectorAll('.question-block');
    if (blocks.length === 0) {
        e.preventDefault();
        alert('Please add at least one question.');
    }
});
</script>

</body>
</html>