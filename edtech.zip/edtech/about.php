
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | EdTech</title>
    <style>
        body {
            margin: 0;
            padding: 40px 20px;
            background: #3d8551;
            color: #f4f4f5;
            font-family: Arial, sans-serif;
            line-height: 1.7;
        }
        .container {
            max-width: 850px;
            margin: auto;
            padding: 30px;
            background: #a9b9ad;
            border: 1px solid #6c726b;
            border-radius: 16px;
        }
        h1, h2 { color: #ffffff; }
        a { color: #6289a3; }
        .back {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 16px;
            background: #3b82f6;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>About Us</h1>
    <p>Welcome to our EdTech Platform!</p>

    <p>Our platform is designed to support students and teachers
    by making learning resources and online quizzes easier to
    access and manage.</p>

    <h2>Our Mission</h2>
    <p>Our mission is to provide a simple, accessible learning
    environment where students can practise, test their knowledge,
    and review their quiz performance.</p>

    <h2>What We Offer</h2>
    <ul>
        <li>Online quizzes and assessments</li>
        <li>Free Study materials organized by subject</li>
        <li>Quiz scores and performance history</li>
        <li>Tools for teachers and administrators to manage quizzes</li>
        <li>Anyone can sign up as teacher in teacher's tab and can host a real-time competitions for their own students</li>
    
    </ul>

    <p>We aim to make learning more organized and convenient for
    students and educators.</p>

    <a class="back" href="index.php">Back to Home</a>
</div>
</body>
</html>
