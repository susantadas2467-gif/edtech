<?php

// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check if user is logged in.
 * Returns true or false.
 */
function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

/**
 * Redirect user if not logged in.
 * Usage: require_login();
 */


/**
 * Get logged-in user's name.
 */
function get_name(): string {
    return $_SESSION['name'] ?? 'User';
}

/**
 * Get logged-in user's class.
 * Returns: '9' or '10'
 */
function get_user_class(): string {
    return $_SESSION['class'] ?? '';
}

/**
 * Get logged-in user's ID.
 */
function get_user_id(): int {
    return $_SESSION['user_id'] ?? 0;
}


/**
 * Get logged-in user's role.
 * Returns: 'admin' or 'student'
 */
function get_role(): string {
    return $_SESSION['role'] ?? '';
}
/**
 * Logout user completely.
 */
function logout(): void {

    // Clear session variables
    $_SESSION = [];

    // Destroy session cookie
    if (ini_get("session.use_cookies")) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }

    // Destroy session
    session_destroy();

    // Redirect to login page
    header("Location: ../login.php");
    exit();
}
?>