<?php

$host = "localhost";
$email = "root";
$password = "";
$database = "edtech_platform";

// Create connection
$conn = new mysqli($host, $email, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Set charset
$conn->set_charset("utf8mb4");

?>