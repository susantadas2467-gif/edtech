<?php
// includes/auth.php
// Route protection — include this at the top of any protected page
// Connects with: session.php (session helpers) and db.php (database connection)

require_once __DIR__ . '/session.php'; // Provides: is_logged_in(), get_role(), get_class(), get_name(), get_user_id()
require_once __DIR__ . '/db.php';      // Provides: $conn (mysqli connection to edtech_platform)

function require_login(): void {

    if (!is_logged_in()) {

        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header("Location: ../index.php");
        exit();

    }

}function require_admin(): void {
    require_login();

    if (get_role() !== 'admin') {
        header("Location: ../student/dashboard.php");
        exit();
    }
}

function require_student(): void {
    require_login();

    if (get_role() !== 'student') {
        header("Location: ../admin/dashboard.php");
        exit();
    }
}
/**
 * Require student to belong to a specific class.
 * Prevents Class 9 students from accessing Class 10 content and vice versa.
 *
 * Usage:
 *   require_class('10');
 */
function require_class(string $required_class): void {
    require_student();
    if (get_class() !== $required_class) {
        header("Location: dashboard.php?error=access_denied");
        exit();
    }
}