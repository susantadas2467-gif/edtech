<?php
session_start();

// ── Redirect if already logged in ─────────────────────────
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } elseif ($_SESSION['role'] === 'teacher') {
        header("Location: teacher/dashboard.php");
    } else {
        header("Location: student/dashboard.php");
    }
    exit();
}

$error        = "";
$active_tab   = $_GET['tab'] ?? 'login'; // login | teacher | join

// ── Handle POST login (student/admin AND teacher) ──────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'includes/db.php';
    require_once 'includes/session.php';

    $login_type = $_POST['login_type'] ?? 'student'; // 'student' or 'teacher'
    $email      = trim($_POST['email']    ?? '');
    $password   = trim($_POST['password'] ?? '');
    $active_tab = $login_type === 'teacher' ? 'teacher' : 'login';

    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $stmt = $conn->prepare("SELECT id, name, password, role, `class` FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            // For teacher tab — only allow teacher role
            if ($login_type === 'teacher' && $row['role'] !== 'teacher') {
                $error = "This account is not a teacher account.";
            }
            // For student tab — only allow student or admin
            elseif ($login_type === 'student' && $row['role'] === 'teacher') {
                $error = "Teachers must use the Teacher tab to sign in.";
            }
            elseif (password_verify($password, $row['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['name']    = $row['name'];
                $_SESSION['role']    = $row['role'];
                $_SESSION['class']   = $row['class'];

                // Update last_login
                $u = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $u->bind_param("i", $row['id']);
                $u->execute();
                $u->close();

                if ($row['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } elseif ($row['role'] === 'teacher') {
                    header("Location: teacher/dashboard.php");
                } else {
                    header("Location: student/dashboard.php");
                }
                exit();
            } else {
                $error = "Incorrect email or password.";
            }
        } else {
            $error = "No account found with that email.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduPortal — Sign In</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;1,500&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #12131a;
            --ink2:   #1e2030;
            --cream:  #f4efe6;
            --paper:  #faf8f4;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --border: rgba(18,19,26,0.1);
            --red:    #c0392b;
            --blue:   #2563eb;
            --green:  #16a34a;
            --ms:     #0078d4;
        }

        html, body {
            height: 100%;
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed; inset: 0;
            background:
                radial-gradient(ellipse 80% 60% at 15% 50%, rgba(201,168,76,0.08), transparent 60%),
                radial-gradient(ellipse 60% 80% at 85% 20%, rgba(37,99,235,0.05), transparent 60%);
            pointer-events: none; z-index: 0;
        }

        .page {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 1fr 1fr;
            position: relative; z-index: 1;
        }

        /* ── LEFT PANEL ── */
        .left {
            background: var(--ink);
            display: flex; flex-direction: column;
            justify-content: space-between;
            padding: 52px 60px;
            position: relative; overflow: hidden;
        }
        .left::before {
            content: ''; position: absolute;
            width: 500px; height: 500px; border-radius: 50%;
            border: 1px solid rgba(201,168,76,0.1);
            top: -160px; right: -160px;
        }
        .left::after {
            content: ''; position: absolute;
            width: 300px; height: 300px; border-radius: 50%;
            border: 1px solid rgba(201,168,76,0.07);
            bottom: -80px; left: -80px;
        }
        .orb {
            position: absolute; width: 180px; height: 180px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(201,168,76,0.15), transparent 70%);
            top: 30%; right: 10%;
            animation: float 6s ease-in-out infinite;
            pointer-events: none;
        }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-20px)} }

        .brand { display: flex; align-items: center; gap: 12px; z-index: 1; animation: fadeUp 0.6s ease both; }
        .brand-icon {
            width: 42px; height: 42px;
            background: linear-gradient(135deg, var(--gold), var(--gold2));
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
            box-shadow: 0 4px 20px rgba(201,168,76,0.3);
        }
        .brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 22px; font-weight: 700;
            color: var(--cream); letter-spacing: 0.01em;
        }

        .left-body { z-index: 1; animation: fadeUp 0.6s ease 0.1s both; }
        .left-body h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(32px, 4vw, 50px); font-weight: 700;
            color: var(--cream); line-height: 1.15; margin-bottom: 18px;
        }
        .left-body h1 em { font-style: italic; color: var(--gold2); }
        .left-body p {
            font-size: 14.5px; color: rgba(244,239,230,0.5);
            line-height: 1.75; max-width: 340px; margin-bottom: 30px;
        }

        .feature-list { display: flex; flex-direction: column; gap: 14px; }
        .feature-item { display: flex; align-items: center; gap: 12px; }
        .feature-icon {
            width: 34px; height: 34px; border-radius: 8px;
            background: rgba(201,168,76,0.12);
            display: flex; align-items: center; justify-content: center;
            font-size: 15px; flex-shrink: 0;
        }
        .feature-text { font-size: 13.5px; color: rgba(244,239,230,0.6); line-height: 1.4; }
        .feature-text strong { color: rgba(244,239,230,0.9); display: block; margin-bottom: 1px; }

        .left-footer { z-index: 1; display: flex; gap: 32px; }
        .stat { display: flex; flex-direction: column; gap: 4px; }
        .stat-num { font-family: 'Playfair Display', serif; font-size: 26px; color: var(--gold2); }
        .stat-label { font-size: 11px; color: rgba(244,239,230,0.35); letter-spacing: 0.08em; text-transform: uppercase; }

        /* ── RIGHT PANEL ── */
        .right {
            display: flex; align-items: center; justify-content: center;
            padding: 40px 32px;
            background: var(--paper);
            overflow-y: auto;
        }

        .card { width: 100%; max-width: 420px; animation: fadeUp 0.5s ease both; }

        @keyframes fadeUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }

        /* ── Tabs ── */
        .tabs {
            display: flex; gap: 4px;
            background: rgba(18,19,26,0.06);
            border-radius: 12px; padding: 4px;
            margin-bottom: 28px;
        }
        .tab {
            flex: 1; padding: 9px 6px;
            border: none; background: transparent;
            border-radius: 9px; cursor: pointer;
            font-family: 'DM Sans', sans-serif;
            font-size: 12.5px; font-weight: 500;
            color: var(--muted);
            display: flex; align-items: center; justify-content: center;
            gap: 5px; transition: all 0.2s;
        }
        .tab.active { background: #fff; color: var(--ink); box-shadow: 0 2px 8px rgba(18,19,26,0.08); }

        /* ── Tab panels ── */
        .tab-panel { display: none; }
        .tab-panel.active { display: block; }

        .panel-header { margin-bottom: 24px; }
        .panel-header h2 { font-family: 'Playfair Display', serif; font-size: 26px; font-weight: 700; margin-bottom: 5px; }
        .panel-header p { font-size: 13.5px; color: var(--muted); }

        /* ── Error ── */
        .error-box {
            background: #fdf0ef;
            border: 1px solid rgba(192,57,43,0.2);
            border-left: 3px solid var(--red);
            border-radius: 8px; padding: 11px 15px;
            margin-bottom: 20px;
            font-size: 13px; color: var(--red);
            display: flex; align-items: center; gap: 8px;
            animation: slideIn 0.25s ease;
        }
        @keyframes slideIn { from{opacity:0;transform:translateY(-5px)} to{opacity:1;transform:translateY(0)} }

        /* ── Form ── */
        .form-group { margin-bottom: 18px; }
        .form-label {
            display: block; font-size: 11px; font-weight: 600;
            letter-spacing: 0.07em; text-transform: uppercase;
            color: var(--muted); margin-bottom: 8px;
        }
        .input-wrap { position: relative; }
        .input-wrap svg {
            position: absolute; left: 13px; top: 50%;
            transform: translateY(-50%); opacity: 0.3; pointer-events: none;
        }
        input[type="email"], input[type="text"], input[type="password"] {
            width: 100%; padding: 12px 13px 12px 40px;
            border: 1.5px solid var(--border); border-radius: 10px;
            background: #fff;
            font-family: 'DM Sans', sans-serif; font-size: 14.5px; color: var(--ink);
            outline: none; transition: border-color 0.2s, box-shadow 0.2s;
        }
        input:focus { border-color: var(--gold); box-shadow: 0 0 0 3px rgba(201,168,76,0.12); }

        .eye-btn {
            position: absolute; right: 12px; top: 50%;
            transform: translateY(-50%);
            background: none; border: none; cursor: pointer;
            color: var(--muted); display: flex; align-items: center; padding: 2px;
        }
        .eye-btn:hover { color: var(--ink); }

        /* ── Buttons ── */
        .btn-signin {
            width: 100%; padding: 13px;
            background: var(--ink); color: var(--cream);
            border: none; border-radius: 10px;
            font-family: 'DM Sans', sans-serif; font-size: 15px; font-weight: 500;
            cursor: pointer; letter-spacing: 0.02em;
            transition: background 0.2s, transform 0.1s;
            position: relative; overflow: hidden;
        }
        .btn-signin::after {
            content: ''; position: absolute; inset: 0;
            background: linear-gradient(135deg, transparent 40%, rgba(201,168,76,0.15));
            pointer-events: none;
        }
        .btn-signin:hover { background: var(--ink2); }
        .btn-signin:active { transform: scale(0.99); }

        /* Teacher sign in button */
        .btn-teacher-signin {
            width: 100%; padding: 13px;
            background: linear-gradient(135deg, var(--gold), var(--gold2));
            color: var(--ink);
            border: none; border-radius: 10px;
            font-family: 'DM Sans', sans-serif; font-size: 15px; font-weight: 600;
            cursor: pointer; letter-spacing: 0.02em;
            transition: opacity 0.2s, transform 0.1s;
            margin-top: 4px;
        }
        .btn-teacher-signin:hover { opacity: 0.9; }
        .btn-teacher-signin:active { transform: scale(0.99); }

        /* ── OAuth buttons ── */
        .oauth-btn {
            width: 100%; padding: 11px 16px;
            border: 1.5px solid var(--border); border-radius: 10px;
            background: #fff; cursor: pointer;
            display: flex; align-items: center; gap: 12px;
            font-size: 13.5px; font-weight: 500; color: var(--ink);
            text-decoration: none; margin-bottom: 10px;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .oauth-btn:hover { border-color: rgba(18,19,26,0.25); box-shadow: 0 2px 8px rgba(18,19,26,0.06); }
        .g-logo, .ms-logo { width: 18px; height: 18px; flex-shrink: 0; }
        .obadge {
            margin-left: auto; font-size: 10px; font-weight: 700;
            letter-spacing: 0.06em; text-transform: uppercase;
            color: var(--gold); padding: 2px 8px;
            background: rgba(201,168,76,0.1); border-radius: 20px;
        }

        /* ── Divider ── */
        .divider {
            display: flex; align-items: center; gap: 10px;
            margin: 18px 0; color: var(--muted); font-size: 11.5px;
        }
        .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: var(--border); }

        .gold-line { width: 36px; height: 2px; background: var(--gold); margin: 20px auto 14px; border-radius: 2px; opacity: 0.45; }
        .bottom-note { text-align: center; font-size: 12px; color: var(--muted); line-height: 1.6; }

        /* ── Signup link ── */
        .signup-link { display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 14px; }
        .signup-link p { font-size: 13px; color: var(--muted); }
        .btn-signup {
            font-size: 13px; font-weight: 500; color: var(--gold);
            text-decoration: none; border-bottom: 1px solid rgba(201,168,76,0.3);
            transition: border-color 0.2s;
        }
        .btn-signup:hover { border-color: var(--gold); }

        /* ── Info cards (teacher features) ── */
        .info-card {
            display: flex; align-items: flex-start; gap: 12px;
            padding: 13px 14px; border-radius: 10px;
            background: rgba(18,19,26,0.04);
            border: 1px solid var(--border);
            margin-bottom: 10px;
        }
        .info-card-text { display: flex; flex-direction: column; gap: 2px; }
        .info-card-text strong { font-size: 13.5px; font-weight: 600; }
        .info-card-text span { font-size: 12px; color: var(--muted); }

        /* ── Join box ── */
        .join-box {
            background: rgba(18,19,26,0.04); border: 1.5px solid var(--border);
            border-radius: 14px; padding: 22px; margin-bottom: 18px;
        }
        .join-box-title { font-size: 15px; font-weight: 600; margin-bottom: 4px; }
        .join-box-sub { font-size: 12.5px; color: var(--muted); margin-bottom: 16px; }
        .join-row { display: flex; gap: 8px; }
        .join-code-input {
            flex: 1; padding: 12px 14px;
            border: 1.5px solid var(--border); border-radius: 10px;
            font-family: 'Playfair Display', serif;
            font-size: 20px; letter-spacing: 0.15em;
            text-align: center; text-transform: uppercase;
            color: var(--ink); background: #fff; outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .join-code-input:focus { border-color: var(--gold); box-shadow: 0 0 0 3px rgba(201,168,76,0.12); }
        .btn-join {
            padding: 12px 20px; background: var(--ink); color: var(--cream);
            border: none; border-radius: 10px; font-size: 14px;
            font-weight: 600; cursor: pointer; white-space: nowrap;
            transition: background 0.2s;
        }
        .btn-join:hover { background: var(--ink2); }
        .join-who { display: flex; gap: 10px; margin-top: 14px; }
        .who-card {
            flex: 1; padding: 10px 12px; border-radius: 9px;
            background: #fff; border: 1px solid var(--border); text-align: center;
        }
        .wi { font-size: 18px; margin-bottom: 4px; }
        .wt { font-size: 12px; font-weight: 600; }
        .ws { font-size: 11px; color: var(--muted); margin-top: 2px; }

        /* ── Teacher divider ── */
        .or-divider { display: flex; align-items: center; gap: 10px; margin: 16px 0; color: var(--muted); font-size: 11.5px; }
        .or-divider::before, .or-divider::after { content: ''; flex: 1; height: 1px; background: var(--border); }

        /* ── Responsive ── */
        @media (max-width: 768px) {
            .page { grid-template-columns: 1fr; }
            .left { display: none; }
            .right { padding: 40px 20px; min-height: 100vh; }
        }
    </style>
</head>
<body>
<div class="page">

    <!-- LEFT PANEL -->
    <div class="left">
        <div class="orb"></div>
        <div class="brand">
            <div class="brand-icon">📚</div>
            <span class="brand-name">EduPortal</span>
        </div>

        <div class="left-body">
            <h1>Learn without<br><em>limits.</em></h1>
            <p>Access study materials, take quizzes, and compete live — all in one place for Class 9 &amp; 10 students.</p>
            <div class="feature-list">
                <div class="feature-item">
                    <div class="feature-icon">📚</div>
                    <div class="feature-text"><strong>Study Materials</strong>View and download notes for every subject</div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">✏️</div>
                    <div class="feature-text"><strong>Practice Quizzes</strong>Test your knowledge at your own pace</div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">🏆</div>
                    <div class="feature-text"><strong>Live Competitions</strong>Join Kahoot-style battles hosted by teachers</div>
                </div>
            </div>
        </div>

        <div class="left-footer">
            <div class="stat"><span class="stat-num">2</span><span class="stat-label">Classes</span></div>
            <div class="stat"><span class="stat-num">6+</span><span class="stat-label">Subjects</span></div>
            <div class="stat"><span class="stat-num">∞</span><span class="stat-label">Quizzes</span></div>
        </div>
    </div>

    <!-- RIGHT PANEL -->
    <div class="right">
        <div class="card">

            <!-- Tabs -->
            <div class="tabs">
                <button class="tab active" id="tab-btn-login" onclick="switchTab('login')">🎒 Sign In</button>
                <button class="tab" id="tab-btn-teacher" onclick="switchTab('teacher')">🧑‍🏫 Teacher</button>
                <button class="tab" id="tab-btn-join" onclick="switchTab('join')">🎮 Join Quiz</button>
            </div>

            <!-- Error box (shown on whichever tab had the error) -->
            <?php if (!empty($error)): ?>
            <div class="error-box">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <!-- ══ TAB 1: Student / Admin Sign In ══ -->
            <div class="tab-panel active" id="tab-login">
                <div class="panel-header">
                    <h2>Welcome back</h2>
                    <p>Sign in with your email and password</p>
                </div>

                <form method="POST" action="index.php" novalidate>
                    <input type="hidden" name="login_type" value="student">

                    <div class="form-group">
                        <label class="form-label" for="email">Email Address</label>
                        <div class="input-wrap">
                            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                            <input type="email" id="email" name="email"
                                placeholder="your@email.com"
                                value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                autocomplete="email" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="input-wrap">
                            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input type="password" id="password" name="password"
                                placeholder="Enter your password"
                                autocomplete="current-password" required>
                            <button type="button" class="eye-btn" onclick="togglePassword('password','eye-icon')" aria-label="Toggle password">
                                <svg id="eye-icon" width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <button type="submit" class="btn-signin">Sign in →</button>

                    <div class="signup-link">
                        <p>Don't have an account?</p>
                        <a href="register.php" class="btn-signup">Create Account</a>
                    </div>
                </form>

                <div class="divider"><span>students — sign in with parent's account</span></div>

                <a href="auth/student_google.php" class="oauth-btn">
                    <svg class="g-logo" viewBox="0 0 48 48">
                        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.08 17.74 9.5 24 9.5z"/>
                        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-3.59-13.46-8.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                    </svg>
                    Continue with Google
                    <span class="obadge">Student</span>
                </a>

                <a href="auth/student_microsoft.php" class="oauth-btn">
                    <svg class="ms-logo" viewBox="0 0 21 21">
                        <rect x="1"  y="1"  width="9" height="9" fill="#f25022"/>
                        <rect x="11" y="1"  width="9" height="9" fill="#7fba00"/>
                        <rect x="1"  y="11" width="9" height="9" fill="#00a4ef"/>
                        <rect x="11" y="11" width="9" height="9" fill="#ffb900"/>
                    </svg>
                    Continue with Microsoft
                    <span class="obadge">Student</span>
                </a>

                <div class="gold-line"></div>
                <p class="bottom-note">Admin? Use your email &amp; password above. Contact your administrator if you've lost access.</p>
            </div>

            <!-- ══ TAB 2: Teacher Login ══ -->
            <div class="tab-panel" id="tab-teacher">
                <div class="panel-header">
                    <h2>Teacher Portal</h2>
                    <p>Sign in to create and host live quiz competitions</p>
                </div>

                <!-- Teacher email/password login form -->
                <form method="POST" action="index.php?tab=teacher" novalidate>
                    <input type="hidden" name="login_type" value="teacher">

                    <div class="form-group">
                        <label class="form-label" for="teacher_email">Email Address</label>
                        <div class="input-wrap">
                            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                            <input type="email" id="teacher_email" name="email"
                                placeholder="your@email.com"
                                value="<?php echo $active_tab === 'teacher' ? htmlspecialchars($_POST['email'] ?? '') : ''; ?>"
                                autocomplete="email" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="teacher_password">Password</label>
                        <div class="input-wrap">
                            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input type="password" id="teacher_password" name="password"
                                placeholder="Enter your password"
                                autocomplete="current-password" required>
                            <button type="button" class="eye-btn" onclick="togglePassword('teacher_password','eye-icon-teacher')" aria-label="Toggle password">
                                <svg id="eye-icon-teacher" width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <button type="submit" class="btn-teacher-signin">Sign in as Teacher →</button>
                </form>

                <div class="or-divider"><span>or sign in with Google</span></div>

                <a href="auth/google_login.php" class="oauth-btn">
                    <svg class="g-logo" viewBox="0 0 48 48">
                        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.08 17.74 9.5 24 9.5z"/>
                        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-3.59-13.46-8.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                    </svg>
                    Sign in with Google
                    <span class="obadge">Teacher</span>
                </a>

                <div class="divider"><span>what you can do as a teacher</span></div>

                <div class="info-card">
                    <span style="font-size:20px;">🏆</span>
                    <div class="info-card-text">
                        <strong>Host Live Quiz Competitions</strong>
                        <span>Real-time Kahoot-style battles for your students</span>
                    </div>
                </div>
                <div class="info-card">
                    <span style="font-size:20px;">🔗</span>
                    <div class="info-card-text">
                        <strong>Share via Code or Link</strong>
                        <span>Students join with a 6-digit code or shareable link</span>
                    </div>
                </div>
                <div class="info-card">
                    <span style="font-size:20px;">📊</span>
                    <div class="info-card-text">
                        <strong>Live Leaderboard</strong>
                        <span>Real-time rankings after every question</span>
                    </div>
                </div>

                <div class="gold-line"></div>
                <p class="bottom-note">No separate account needed — any Gmail works.</p>
            </div>

            <!-- ══ TAB 3: Join Quiz ══ -->
            <div class="tab-panel" id="tab-join">
                <div class="panel-header">
                    <h2>Join a Live Quiz</h2>
                    <p>Enter the code or open the link your teacher shared</p>
                </div>

                <div class="join-box">
                    <div class="join-box-title">🎮 Enter Join Code</div>
                    <div class="join-box-sub">Ask your teacher for the 6-character code</div>
                    <form action="join.php" method="GET" class="join-row">
                        <input type="text" name="code" class="join-code-input"
                            placeholder="000000" maxlength="6"
                            autocomplete="off"
                            oninput="this.value=this.value.replace(/\D/g,'')">
                        <button type="submit" class="btn-join">Join →</button>
                    </form>
                    <div class="join-who">
                        <div class="who-card">
                            <div class="wi">🎓</div>
                            <div class="wt">Registered</div>
                            <div class="ws">Name auto-filled</div>
                        </div>
                        <div class="who-card">
                            <div class="wi">👤</div>
                            <div class="wt">Guest / Anyone</div>
                            <div class="ws">Just enter a name</div>
                        </div>
                    </div>
                </div>

                <div class="divider"><span>or open the link from your teacher</span></div>

                <div style="background:rgba(18,19,26,0.03);border:1.5px dashed var(--border);border-radius:10px;padding:18px;text-align:center;">
                    <div style="font-size:24px;margin-bottom:8px;">🔗</div>
                    <div style="font-size:13px;font-weight:600;margin-bottom:4px;">Got a link from your teacher?</div>
                    <div style="font-size:12px;color:var(--muted);line-height:1.6;">Just tap the link — it will bring you<br>straight into the quiz waiting room.</div>
                </div>

                <div class="gold-line"></div>
                <p class="bottom-note">No account needed to join a competition.</p>
            </div>

        </div>
    </div>
</div>

<script>
function switchTab(tab) {
    ['login','teacher','join'].forEach(t => {
        document.getElementById('tab-btn-' + t).classList.toggle('active', t === tab);
        document.getElementById('tab-' + t).classList.toggle('active', t === tab);
    });
}

function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.innerHTML = `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>`;
    } else {
        input.type = 'password';
        icon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
    }
}

// Auto-open correct tab
const urlTab = new URLSearchParams(window.location.search).get('tab');
if (urlTab === 'join') switchTab('join');
if (urlTab === 'teacher') switchTab('teacher');

// If there was a teacher login error, keep teacher tab open
<?php if (!empty($error) && $active_tab === 'teacher'): ?>
switchTab('teacher');
<?php endif; ?>
</script>
</body>
</html>