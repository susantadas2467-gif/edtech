
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | EdTech</title>
    <style>
        body {
            margin: 0;
            padding: 40px 20px;
            background: #b8c4ee;
            color: #040409;
            font-family: Arial, sans-serif;
            line-height: 1.7;
        }
        .container {
            max-width: 850px;
            margin: auto;
            padding: 30px;
            background: #98a8d0;
            border: 1px solid #bbcaec;
            border-radius: 16px;
        }
        h1, h2 { color: #ffffff; }
        a { color: #78aaff; }
        .back {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 16px;
            background: #3b82f6;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Privacy Policy</h1>
    <p><strong>Last updated:</strong> 17 October 2026</p>

    <p>This Privacy Policy explains how our EdTech Platform
    handles information when you use the website.</p>

    <h2>1. Information We Handle</h2>
    <p>The platform may handle account information, such as a
    email and class, along with quiz answers, scores, and
    quiz history, depending on the features you use.</p>

    <h2>2. How Information Is Used</h2>
    <p>Information is used to provide access to the platform,
    display learning materials, conduct quizzes, calculate
    scores, and show student performance history.</p>

    <h2>3. Storage and Security</h2>
    <p>Information may be stored in the platform's database.
    Reasonable security measures should be used to protect
    accounts and records. No online system can be guaranteed
    completely secure.</p>

    <h2>4. Sharing of Information</h2>
    <p>Access to student information should be limited to
    authorized people who need it to operate the learning
    platform. Update this section to reflect any actual sharing
    with hosting providers or other services.</p>

    <h2>5. Data Retention and Deletion</h2>
    <p>Explain how long account information and quiz results are
    retained, and how users or guardians can request corrections
    or deletion where applicable.</p>

    <h2>6. Children's Privacy</h2>
    <p>Because students may be minors they have to use their parent's email for creating an account, the platform should handle
    their information carefully and follow applicable privacy
    requirements. Add the actual process for parent or guardian
    involvement where required.</p>

    <h2>7. Changes to This Policy</h2>
    <p>This policy may be updated when the platform's features
    or data practices change. The latest version should be
    published on this page.</p>

    <h2>8. Contact Us</h2>
    <p>For privacy questions or requests, contact the website
    administrator using the contact details provided by the
    platform owner.</p>

    <a class="back" href="index.php">Back to Home</a>
</div>
</body>
</html>
