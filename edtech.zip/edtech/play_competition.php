<?php
// play_competition.php (root level)
require_once 'includes/session.php';
require_once 'includes/db.php';

$participant_id = (int)($_SESSION['participant_id'] ?? 0);
$comp_id        = (int)($_GET['id'] ?? 0);

if (!$participant_id || !$comp_id) {
    header("Location: join.php"); exit();
}

// Validate participant belongs to this competition
$s = $conn->prepare("
    SELECT cp.*, c.status, c.quiz_id, qz.title AS quiz_title, qz.subject, qz.duration,
           (SELECT COUNT(*) FROM questions WHERE quiz_id = c.quiz_id) AS total_q
    FROM competition_participants cp
    JOIN competitions c ON cp.competition_id = c.id
    JOIN quizzes qz ON c.quiz_id = qz.id
    WHERE cp.id = ? AND cp.competition_id = ?
");
$s->bind_param("ii", $participant_id, $comp_id);
$s->execute();
$participant = $s->get_result()->fetch_assoc();
$s->close();

if (!$participant) { header("Location: join.php"); exit(); }
if ($participant['status'] === 'waiting') {
    // Show waiting screen
    ?><!DOCTYPE html>
    <html><head><meta charset="UTF-8"><meta http-equiv="refresh" content="5">
    <title>Waiting...</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'DM Sans',sans-serif;background:#1a1a2e;color:#f5f0e8;min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center}
        .box{padding:40px}
        .spinner{width:48px;height:48px;border:3px solid rgba(201,168,76,.2);border-top-color:#c9a84c;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 24px}
        @keyframes spin{to{transform:rotate(360deg)}}
        h1{font-family:'Playfair Display',serif;font-size:28px;margin-bottom:8px}
        p{color:rgba(245,240,232,.6);font-size:14px}
        .name{color:#e8c96a;font-weight:600}
    </style></head>
    <body><div class="box">
        <div class="spinner"></div>
        <h1>Waiting for teacher...</h1>
        <p>Welcome, <span class="name"><?php echo htmlspecialchars($participant['guest_name'] ?? get_name()); ?></span></p>
        <p style="margin-top:8px">The competition will start soon. This page refreshes automatically.</p>
    </div></body></html>
    <?php exit();
}

if ($participant['status'] === 'ended' || $participant['finished_at']) {
    // Already finished — show results
    $s = $conn->prepare("
        SELECT ca.answer_given, ca.is_correct, q.question_text, q.question_type,
               q.correct_option, q.correct_answer_text, q.marks,
               q.option_a, q.option_b, q.option_c, q.option_d
        FROM competition_answers ca
        JOIN questions q ON ca.question_id = q.id
        WHERE ca.participant_id = ?
        ORDER BY q.id ASC
    ");
    $s->bind_param("i", $participant_id);
    $s->execute();
    $answers = $s->get_result()->fetch_all(MYSQLI_ASSOC);
    $s->close();
    ?><!DOCTYPE html>
    <html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Results</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--cream:#f5f0e8;--paper:#faf7f2;--gold:#c9a84c;--gold2:#e8c96a;--green:#1e7e4a;--red:#c0392b;--border:rgba(26,26,46,.12)}
        body{font-family:'DM Sans',sans-serif;background:var(--ink);color:var(--cream);min-height:100vh}
        .hero{text-align:center;padding:60px 20px 40px;background:linear-gradient(180deg,#1a1a2e 0%,#2e2e4a 100%)}
        .score-ring{width:120px;height:120px;border-radius:50%;border:4px solid var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;flex-direction:column}
        .score-num{font-family:'Playfair Display',serif;font-size:32px;color:var(--gold2);line-height:1}
        .score-total{font-size:12px;color:rgba(245,240,232,.5)}
        h1{font-family:'Playfair Display',serif;font-size:28px;margin-bottom:6px}
        .subtitle{color:rgba(245,240,232,.6);font-size:14px}
        .container{max-width:640px;margin:0 auto;padding:32px 20px 60px}
        .review-card{background:var(--paper);border-radius:12px;padding:20px;margin-bottom:14px;border-left:4px solid var(--border)}
        .review-card.correct{border-left-color:var(--green)}
        .review-card.incorrect{border-left-color:var(--red)}
        .q-text{font-size:14px;color:var(--ink);font-weight:500;margin-bottom:10px}
        .answer-row{font-size:13px;color:var(--muted);margin-top:4px}
        .answer-row strong{color:var(--ink)}
        .correct-label{font-size:11px;color:var(--green);font-weight:600;text-transform:uppercase;margin-bottom:6px}
        .incorrect-label{font-size:11px;color:var(--red);font-weight:600;text-transform:uppercase;margin-bottom:6px}
        .btn-back{display:block;text-align:center;margin:0 auto;padding:13px 32px;background:var(--gold);color:var(--ink);border-radius:10px;font-weight:600;text-decoration:none;font-size:14px;width:fit-content}
    </style></head>
    <body>
    <div class="hero">
        <div class="score-ring">
            <div class="score-num"><?php echo $participant['score']; ?></div>
            <div class="score-total">/ <?php echo $participant['total_marks']; ?></div>
        </div>
        <h1>Quiz Complete!</h1>
        <p class="subtitle">Well done, <?php echo htmlspecialchars($participant['guest_name'] ?? get_name()); ?>!</p>
    </div>
    <div class="container">
        <h2 style="font-family:'Playfair Display',serif;font-size:18px;color:var(--ink);margin-bottom:16px">Answer Review</h2>
        <?php foreach ($answers as $i => $a): ?>
        <div class="review-card <?php echo $a['is_correct'] ? 'correct' : 'incorrect'; ?>">
            <div class="<?php echo $a['is_correct'] ? 'correct-label' : 'incorrect-label'; ?>">
                <?php echo $a['is_correct'] ? '✓ Correct' : '✗ Incorrect'; ?>
            </div>
            <div class="q-text">Q<?php echo $i+1; ?>. <?php echo htmlspecialchars($a['question_text']); ?></div>
            <div class="answer-row">Your answer: <strong><?php echo htmlspecialchars($a['answer_given'] ?? '—'); ?></strong></div>
            <?php if (!$a['is_correct']): ?>
            <div class="answer-row">Correct answer: <strong>
                <?php echo htmlspecialchars($a['question_type'] === 'mcq'
                    ? strtoupper($a['correct_option']) . '. ' . $a['option_' . $a['correct_option']]
                    : $a['correct_answer_text']); ?>
            </strong></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <a href="join.php" class="btn-back">Back to Join Page</a>
    </div>
    </body></html>
    <?php exit();
}

// ── Active quiz: load next unanswered question ──
$s = $conn->prepare("
    SELECT q.* FROM questions q
    WHERE q.quiz_id = ?
    AND q.id NOT IN (
        SELECT question_id FROM competition_answers WHERE participant_id = ?
    )
    ORDER BY q.id ASC LIMIT 1
");
$s->bind_param("ii", $participant['quiz_id'], $participant_id);
$s->execute();
$question = $s->get_result()->fetch_assoc();
$s->close();

// Count answered
$s = $conn->prepare("SELECT COUNT(*) AS c FROM competition_answers WHERE participant_id = ?");
$s->bind_param("i", $participant_id);
$s->execute();
$answered = $s->get_result()->fetch_assoc()['c'];
$s->close();

// Handle answer submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['question_id'])) {
    $q_id  = (int)$_POST['question_id'];
    $ans   = trim($_POST['answer'] ?? '');
    $q_type = $_POST['q_type'] ?? 'mcq';

    // Fetch correct answer
    $s = $conn->prepare("SELECT correct_option, correct_answer_text, marks, question_type FROM questions WHERE id = ?");
    $s->bind_param("i", $q_id);
    $s->execute();
    $q_data = $s->get_result()->fetch_assoc();
    $s->close();

    $is_correct = false;
    if ($q_data['question_type'] === 'mcq') {
        $is_correct = strtolower($ans) === strtolower($q_data['correct_option']);
    } else {
        $is_correct = strtolower(trim($ans)) === strtolower(trim($q_data['correct_answer_text']));
    }
    $marks_earned = $is_correct ? $q_data['marks'] : 0;

    // Save answer
    $s = $conn->prepare("INSERT INTO competition_answers (participant_id, question_id, answer_given, is_correct) VALUES (?,?,?,?)");
    $s->bind_param("iisi", $participant_id, $q_id, $ans, $is_correct);
    $s->execute(); $s->close();

    // Update score
    $s = $conn->prepare("UPDATE competition_participants SET score = score + ?, total_marks = total_marks + ? WHERE id = ?");
    $s->bind_param("iii", $marks_earned, $q_data['marks'], $participant_id);
    $s->execute(); $s->close();

    // Check if all questions answered
    $s = $conn->prepare("SELECT COUNT(*) AS c FROM competition_answers WHERE participant_id = ?");
    $s->bind_param("i", $participant_id);
    $s->execute();
    $new_answered = $s->get_result()->fetch_assoc()['c'];
    $s->close();

    if ($new_answered >= $participant['total_q']) {
        $conn->prepare("UPDATE competition_participants SET finished_at = NOW() WHERE id = $participant_id")->execute();
    }

    header("Location: play_competition.php?id=$comp_id");
    exit();
}

// No more questions — mark as finished
if (!$question) {
    $s = $conn->prepare("UPDATE competition_participants SET finished_at = NOW() WHERE id = ? AND finished_at IS NULL");
    $s->bind_param("i", $participant_id);
    $s->execute(); $s->close();
    header("Location: play_competition.php?id=$comp_id");
    exit();
}

$progress = $participant['total_q'] > 0 ? round(($answered / $participant['total_q']) * 100) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — <?php echo htmlspecialchars($participant['quiz_title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--cream:#f5f0e8;--paper:#faf7f2;--gold:#c9a84c;--gold2:#e8c96a;--muted:#7a7a8a;--red:#c0392b;--green:#1e7e4a;--border:rgba(26,26,46,.12)}
        body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);min-height:100vh}
        .top{background:var(--ink);padding:14px 24px;display:flex;align-items:center;justify-content:space-between}
        .top-name{font-size:13px;color:rgba(245,240,232,.7)}
        .top-progress{font-size:13px;color:var(--gold2)}
        .progress-bar{height:4px;background:rgba(255,255,255,.1)}
        .progress-fill{height:100%;background:var(--gold);transition:width .4s ease;width:<?php echo $progress; ?>%}
        .container{max-width:640px;margin:0 auto;padding:40px 20px 60px}
        .q-counter{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:6px}
        .q-text{font-family:'Playfair Display',serif;font-size:22px;line-height:1.4;margin-bottom:28px}
        /* MCQ options */
        .options{display:flex;flex-direction:column;gap:12px;margin-bottom:24px}
        .option-btn{display:flex;align-items:center;gap:14px;padding:16px 18px;border:1.5px solid var(--border);border-radius:12px;background:#fff;cursor:pointer;text-align:left;font-family:'DM Sans',sans-serif;font-size:15px;color:var(--ink);transition:border-color .15s,background .15s,transform .1s;width:100%}
        .option-btn:hover{border-color:var(--gold);background:rgba(201,168,76,.05);transform:translateX(3px)}
        .option-btn:active{transform:scale(.99)}
        .option-letter{width:32px;height:32px;border-radius:50%;background:rgba(26,26,46,.07);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0;color:var(--gold)}
        /* Short answer */
        .short-form textarea{width:100%;padding:14px;border:1.5px solid var(--border);border-radius:12px;background:#fff;font-family:'DM Sans',sans-serif;font-size:15px;color:var(--ink);outline:none;resize:vertical;min-height:100px;margin-bottom:16px;transition:border-color .2s,box-shadow .2s}
        .short-form textarea:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.12)}
        .btn-submit{width:100%;padding:15px;background:var(--ink);color:var(--cream);border:none;border-radius:12px;font-size:15px;font-weight:500;cursor:pointer;transition:background .2s}
        .btn-submit:hover{background:#2e2e4a}
        .score-bar{background:var(--paper);border:1px solid var(--border);border-radius:10px;padding:14px 18px;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
        .score-label{font-size:12px;color:var(--muted)}
        .score-value{font-family:'Playfair Display',serif;font-size:20px;color:var(--gold)}
    </style>
</head>
<body>

<div class="top">
    <div class="top-name">👤 <?php echo htmlspecialchars($participant['guest_name'] ?? get_name()); ?></div>
    <div class="top-progress"><?php echo $answered; ?> / <?php echo $participant['total_q']; ?> answered</div>
</div>
<div class="progress-bar"><div class="progress-fill"></div></div>

<div class="container">
    <div class="score-bar">
        <div class="score-label">Current Score</div>
        <div class="score-value"><?php echo $participant['score']; ?> pts</div>
    </div>

    <div class="q-counter">Question <?php echo $answered + 1; ?> of <?php echo $participant['total_q']; ?></div>
    <div class="q-text"><?php echo htmlspecialchars($question['question_text']); ?></div>

    <?php if ($question['question_type'] === 'mcq'): ?>
    <!-- MCQ -->
    <div class="options">
        <?php
        $opts = ['a' => $question['option_a'], 'b' => $question['option_b'], 'c' => $question['option_c'], 'd' => $question['option_d']];
        foreach ($opts as $key => $val):
            if (!$val) continue;
        ?>
        <form method="POST" action="play_competition.php?id=<?php echo $comp_id; ?>">
            <input type="hidden" name="question_id" value="<?php echo $question['id']; ?>">
            <input type="hidden" name="q_type" value="mcq">
            <input type="hidden" name="answer" value="<?php echo $key; ?>">
            <button type="submit" class="option-btn">
                <div class="option-letter"><?php echo strtoupper($key); ?></div>
                <?php echo htmlspecialchars($val); ?>
            </button>
        </form>
        <?php endforeach; ?>
    </div>

    <?php else: ?>
    <!-- Short Answer -->
    <form method="POST" action="play_competition.php?id=<?php echo $comp_id; ?>" class="short-form">
        <input type="hidden" name="question_id" value="<?php echo $question['id']; ?>">
        <input type="hidden" name="q_type" value="short_answer">
        <textarea name="answer" placeholder="Type your answer here..." required></textarea>
        <button type="submit" class="btn-submit">Submit Answer →</button>
    </form>
    <?php endif; ?>
</div>
</body>
</html>