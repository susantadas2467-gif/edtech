<?php
// admin/add_materials.php
require_once '../includes/auth.php';
require_once "../includes/flash.php";

require_admin();

$error   = "";
$success = "";

// Allowed file types and max size
$allowed_ext  = ['pdf', 'doc', 'docx', 'ppt', 'pptx'];
$max_size_mb  = 20;
$upload_base  = '../uplods/materials'; // matches your existing folder name (note: "uplods" not "uploads")

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = trim($_POST['title'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $class   = $_POST['class'] ?? '';

    if (empty($title) || empty($subject) || empty($class)) {
        $error = "Please fill in title, subject, and class.";
    } elseif (!isset($_FILES['material_file']) || $_FILES['material_file']['error'] !== UPLOAD_ERR_OK) {
        $error = "Please select a valid file to upload.";
    } else {
        $file = $_FILES['material_file'];
        $file_ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $file_size_mb = $file['size'] / (1024 * 1024);

        if (!in_array($file_ext, $allowed_ext)) {
            $error = "Invalid file type. Allowed: " . implode(', ', $allowed_ext);
        } elseif ($file_size_mb > $max_size_mb) {
            $error = "File too large. Max size is {$max_size_mb}MB.";
        } else {
            // Build target folder: uplods/materials/class9 or class10
            $class_folder = "class" . $class;
            $target_dir = "$upload_base/$class_folder";

            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true);
            }

            // Generate a safe, unique filename
            $safe_title = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
            $unique_name = $safe_title . '_' . time() . '.' . $file_ext;
            $target_path = "$target_dir/$unique_name";

            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                // Store relative path in DB (relative to project root)
                $db_path = "uplods/materials/$class_folder/$unique_name";

                $stmt = $conn->prepare(
                    "INSERT INTO materials (title, subject, `class`, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?)"
                );
                // Bind order: title(s), subject(s), class(s), file_path(s), uploaded_by(i)
                $stmt->bind_param("ssssi", $title, $subject, $class, $db_path, $_SESSION['user_id']);

                if ($stmt->execute()) {
                    set_flash('success', "\"$title\" uploaded successfully for Class $class.");
                    header("Location: add_materials.php");
                    exit();
                } else {
                    $error = "File uploaded but failed to save record. Please contact support.";
                    error_log("Material DB insert failed: " . $stmt->error);
                }
                $stmt->close();
            } else {
                $error = "Failed to upload file. Please try again.";
            }
        }
    }
}

// ── Fetch recently uploaded materials ──
$recent = $conn->query("SELECT title, subject, `class`, file_path, uploaded_at FROM materials ORDER BY uploaded_at DESC LIMIT 10");

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Add Materials</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #1a1a2e;
            --ink2:   #2e2e4a;
            --cream:  #f5f0e8;
            --paper:  #faf7f2;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --red:    #c0392b;
            --green:  #1e7e4a;
            --border: rgba(26,26,46,0.12);
        }

        html, body {
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
            min-height: 100vh;
        }

        .topbar {
            background: var(--ink);
            padding: 18px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .brand { display: flex; align-items: center; gap: 10px; }
        .brand-icon {
            width: 32px; height: 32px;
            background: var(--gold);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
        }
        .brand-name { font-family: 'Playfair Display', serif; font-size: 18px; color: var(--cream); }
        .topbar a { color: rgba(245,240,232,0.7); text-decoration: none; font-size: 13.5px; }
        .topbar a:hover { color: var(--gold2); }

        .container {
            max-width: 720px;
            margin: 0 auto;
            padding: 48px 24px 80px;
        }

        .page-header { margin-bottom: 28px; }
        .page-header h1 { font-family: 'Playfair Display', serif; font-size: 30px; margin-bottom: 6px; }
        .page-header p { color: var(--muted); font-size: 14px; }

        /* ── Alerts ── */
        .alert {
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 22px;
            font-size: 13.5px;
            display: flex; align-items: center; gap: 8px;
        }
        .alert-error {
            background: #fdf0ef;
            border: 1px solid rgba(192,57,43,0.25);
            border-left: 3px solid var(--red);
            color: var(--red);
        }
        .alert-success {
            background: #edfbf3;
            border: 1px solid rgba(30,126,74,0.25);
            border-left: 3px solid var(--green);
            color: var(--green);
        }

        /* ── Form card ── */
        .card {
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 28px;
            margin-bottom: 28px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }
        .form-group { margin-bottom: 18px; }
        label {
            display: block;
            font-size: 12px; font-weight: 500;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 7px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 11px 13px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 14.5px;
            color: var(--ink);
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        input:focus, select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(201,168,76,0.12);
        }

        /* ── File drop zone ── */
        .file-drop {
            border: 1.5px dashed var(--border);
            border-radius: 12px;
            padding: 28px;
            text-align: center;
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
            position: relative;
        }
        .file-drop:hover, .file-drop.dragover {
            border-color: var(--gold);
            background: rgba(201,168,76,0.04);
        }
        .file-drop input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
        }
        .file-drop-icon { font-size: 28px; margin-bottom: 8px; }
        .file-drop-text { font-size: 13.5px; color: var(--muted); }
        .file-drop-text strong { color: var(--ink); }
        .file-drop-hint { font-size: 11.5px; color: var(--muted); margin-top: 4px; }
        .file-name-display {
            margin-top: 10px;
            font-size: 13px;
            color: var(--ink);
            font-weight: 500;
            display: none;
        }

        .btn-submit {
            width: 100%; padding: 14px;
            background: var(--ink); color: var(--cream);
            border: none; border-radius: 10px;
            font-size: 15px; font-weight: 500;
            cursor: pointer; letter-spacing: 0.02em;
            margin-top: 6px;
            transition: background 0.2s;
        }
        .btn-submit:hover { background: var(--ink2); }

        /* ── Recent materials list ── */
        .section-title {
            font-family: 'Playfair Display', serif;
            font-size: 18px;
            margin-bottom: 14px;
        }
        .material-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 13px 16px;
            margin-bottom: 10px;
        }
        .material-info { display: flex; align-items: center; gap: 12px; }
        .material-icon {
            width: 36px; height: 36px;
            background: rgba(201,168,76,0.12);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }
        .material-title { font-size: 13.5px; font-weight: 500; }
        .material-meta { font-size: 11.5px; color: var(--muted); margin-top: 2px; }
        .material-link {
            font-size: 12px;
            color: var(--gold);
            text-decoration: none;
            font-weight: 500;
            white-space: nowrap;
        }
        .material-link:hover { text-decoration: underline; }

        .empty-state { text-align: center; padding: 30px; color: var(--muted); font-size: 13.5px; }

        @media (max-width: 600px) {
            .form-row { grid-template-columns: 1fr; }
            .container { padding: 32px 16px 60px; }
        }
    </style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech admin</span>
    </div>
    <a href="dashboard.php">← Back to Dashboard</a>
</div>

<div class="container">
    <div class="page-header">
        <h1>Add Study Material</h1>
        <p>Upload notes, worksheets, or resources for students.</p>
    </div>

    <?php if (!empty($error)): ?>
    <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($flash): ?>
    <div class="alert alert-<?php echo $flash['type'] === 'success' ? 'success' : 'error'; ?>">
        ✓ <?php echo htmlspecialchars($flash['message']); ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="add_materials.php" enctype="multipart/form-data">

            <div class="form-group">
                <label for="title">Material Title</label>
                <input type="text" id="title" name="title" placeholder="e.g. Chapter 4 Notes — Light" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="e.g. Physics" required>
                </div>
                <div class="form-group">
                    <label for="class">Class</label>
                    <select id="class" name="class" required>
                        <option value="">Select</option>
                        <option value="9">Class 9</option>
                        <option value="10">Class 10</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Upload File</label>
                <div class="file-drop" id="fileDropZone">
                    <input type="file" id="material_file" name="material_file" accept=".pdf,.doc,.docx,.ppt,.pptx" required onchange="showFileName(this)">
                    <div class="file-drop-icon">📄</div>
                    <div class="file-drop-text"><strong>Click to upload</strong> or drag and drop</div>
                    <div class="file-drop-hint">PDF, DOC, DOCX, PPT, PPTX — max 20MB</div>
                    <div class="file-name-display" id="fileNameDisplay"></div>
                </div>
            </div>

            <button type="submit" class="btn-submit">Upload Material →</button>
        </form>
    </div>

    <div class="section-title">Recently Uploaded</div>

    <?php if ($recent && $recent->num_rows > 0): ?>
        <?php while ($row = $recent->fetch_assoc()): ?>
        <div class="material-item">
            <div class="material-info">
                <div class="material-icon">📄</div>
                <div>
                    <div class="material-title"><?php echo htmlspecialchars($row['title']); ?></div>
                    <div class="material-meta">
                        <?php echo htmlspecialchars($row['subject']); ?> · Class <?php echo htmlspecialchars($row['class']); ?> ·
                        <?php echo date('d M Y', strtotime($row['uploaded_at'])); ?>
                    </div>
                </div>
            </div>
            <a href="../<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank" class="material-link">View →</a>
        </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="empty-state">No materials uploaded yet.</div>
    <?php endif; ?>

</div>

<script>
function showFileName(input) {
    const display = document.getElementById('fileNameDisplay');
    if (input.files && input.files[0]) {
        display.textContent = '📎 ' + input.files[0].name;
        display.style.display = 'block';
    }
}

// Drag and drop visual feedback
const dropZone = document.getElementById('fileDropZone');
['dragenter', 'dragover'].forEach(evt => {
    dropZone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
});
['dragleave', 'drop'].forEach(evt => {
    dropZone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
    });
});
dropZone.addEventListener('drop', (e) => {
    const fileInput = document.getElementById('material_file');
    if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        showFileName(fileInput);
    }
});
</script>

</body>
</html>