<?php
session_start();

// Auth guard — admin only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

require_once '../includes/db.php';
require_once '../includes/session.php';

// ── Stat queries ───────────────────────────────────────────
$r = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role = 'student'");
$total_students = $r->fetch_assoc()['c'];

$r = $conn->query("SELECT COUNT(*) AS c FROM materials");
$total_materials = $r->fetch_assoc()['c'];

$r = $conn->query("SELECT COUNT(*) AS c FROM quizzes");
$total_quizzes = $r->fetch_assoc()['c'];

$r = $conn->query("SELECT COUNT(*) AS c FROM results");
$total_attempts = $r->fetch_assoc()['c'];

$r = $conn->query("SELECT ROUND(AVG(score), 1) AS avg FROM results");
$avg_score = $r->fetch_assoc()['avg'] ?? 0;

// Students per class
$r = $conn->query("SELECT class, COUNT(*) AS cnt FROM users WHERE role='student' GROUP BY class ORDER BY class");
$class_counts = [];
while ($row = $r->fetch_assoc()) $class_counts[$row['class']] = $row['cnt'];

// Recent quiz results (last 8)
$recent_results = [];
$r = $conn->query("
    SELECT u.name AS student, u.class, q.title AS quiz, q.subject, res.score, res.taken_at
    FROM results res
    JOIN users    u ON res.user_id = u.id
    JOIN quizzes  q ON res.quiz_id = q.id
    ORDER BY res.taken_at DESC
    LIMIT 8
");
while ($row = $r->fetch_assoc()) $recent_results[] = $row;

// Recently uploaded materials (last 6)
$recent_materials = [];
$r = $conn->query("
    SELECT title, class, subject, file_path, uploaded_at
    FROM materials
    ORDER BY uploaded_at DESC
    LIMIT 6
");
while ($row = $r->fetch_assoc()) $recent_materials[] = $row;

$conn->close();

$admin_name = htmlspecialchars($_SESSION['name']);
$today      = date('l, d M Y');

$c9_count   = $class_counts['9']  ?? 0;
$c10_count  = $class_counts['10'] ?? 0;
$max_count  = max($c9_count, $c10_count, 1);

// Ring calc for avg score
$circumference = 2 * M_PI * 44;
$dash_offset   = $circumference * (1 - min(100, $avg_score) / 100);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard — EduPortal</title>
    <link rel="stylesheet" href="../assets/ed.css">
    <style>
        /* ── Page-specific styles only ── */

        /* Stats grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }

        /* Quick actions */
        .quick-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .action-tile {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            background: var(--surface2);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            color: var(--muted2);
            font-weight: 500;
            font-size: 13px;
            transition: border-color 0.15s, background 0.15s, transform 0.15s, color 0.15s;
            cursor: pointer;
        }

        .action-tile:hover {
            border-color: var(--accent);
            background: rgba(79, 142, 247, 0.06);
            color: var(--text);
            transform: translateY(-1px);
        }

        .action-icon {
            width: 36px; height: 36px;
            border-radius: var(--radius-sm);
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        /* Two column */
        .two-col   { display: grid; grid-template-columns: 1fr 1fr;       gap: 20px; margin-bottom: 20px; }
        .col-3-1   { display: grid; grid-template-columns: 1.6fr 1fr;     gap: 20px; margin-bottom: 20px; }

        /* Class bar rows */
        .class-row {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 13px 0;
            border-bottom: 1px solid var(--border);
        }
        .class-row:last-of-type { border-bottom: none; }

        .class-label-badge {
            font-family: var(--font-display);
            font-size: 12px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: var(--radius-sm);
            min-width: 68px;
            text-align: center;
        }
        .class-label-badge.c9  { background: var(--math-bg);    color: var(--math-color); }
        .class-label-badge.c10 { background: var(--violet-bg);  color: var(--violet); }

        .bar-wrap {
            flex: 1;
            height: 6px;
            background: var(--surface2);
            border-radius: 4px;
            overflow: hidden;
        }
        .bar-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 1s cubic-bezier(.25,.8,.25,1);
        }
        .bar-fill.c9  { background: var(--accent); }
        .bar-fill.c10 { background: var(--violet); }

        .bar-count {
            font-family: var(--font-display);
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            min-width: 28px;
            text-align: right;
        }

        /* Avg score ring */
        .avg-ring {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px 0 8px;
        }
        .ring-wrap { position: relative; width: 110px; height: 110px; }
        .ring-svg  { transform: rotate(-90deg); }
        .ring-label {
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .ring-num {
            font-family: var(--font-display);
            font-size: 26px;
            font-weight: 800;
            color: var(--green);
            line-height: 1;
        }
        .ring-sub {
            font-size: 9px;
            color: var(--muted);
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
        }
        .avg-caption { font-size: 12px; color: var(--muted2); text-align: center; margin-top: 10px; }

        /* Recent materials list */
        .material-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 0;
            border-bottom: 1px solid var(--border);
        }
        .material-row:last-child { border-bottom: none; }
        .material-icon {
            width: 34px; height: 34px;
            border-radius: var(--radius-sm);
            background: rgba(79,142,247,0.1);
            display: flex; align-items: center; justify-content: center;
            font-size: 15px; flex-shrink: 0;
        }
        .material-info { flex: 1; min-width: 0; }
        .material-title {
            font-size: 13px; font-weight: 600; color: var(--text);
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .material-meta { font-size: 11.5px; color: var(--muted); margin-top: 2px; }

        /* Del btn */
        .del-btn {
            background: none; border: none; cursor: pointer;
            color: var(--muted); padding: 5px; border-radius: var(--radius-sm);
            display: flex; transition: color 0.15s, background 0.15s;
        }
        .del-btn:hover { color: var(--red); background: var(--red-bg); }

        /* Responsive */
        @media (max-width: 1100px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .col-3-1    { grid-template-columns: 1fr; }
        }
        @media (max-width: 860px) {
            .two-col    { grid-template-columns: 1fr; }
        }
        @media (max-width: 520px) {
            .stats-grid     { grid-template-columns: 1fr 1fr; }
            .quick-actions  { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="layout">

    <!-- ══════════ SIDEBAR ══════════ -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-logo">
            <div class="logo-mark">📚</div>
            <span class="logo-text">Edu<span>Portal</span></span>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Main</div>

            <a href="dashboard.php" class="nav-item active">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                    <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
                </svg>
                Dashboard
            </a>

            <a href="manage_user.php" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
                Manage Users
                <span class="nav-badge"><?php echo $total_students; ?></span>
            </a>

            <a href="add_material.php" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="12" y1="18" x2="12" y2="12"/>
                    <line x1="9" y1="15" x2="15" y2="15"/>
                </svg>
                Add Material
            </a>

            <a href="add_quiz.php" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                Add Quiz
            </a>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Classes</div>
            <a href="#" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
                </svg>
                Class 9
                <span class="nav-badge" style="background:var(--surface3);color:var(--muted2);"><?php echo $c9_count; ?></span>
            </a>
            <a href="#" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
                </svg>
                Class 10
                <span class="nav-badge" style="background:var(--surface3);color:var(--muted2);"><?php echo $c10_count; ?></span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?></div>
                <div class="user-info">
                    <div class="u-name"><?php echo $admin_name; ?></div>
                    <div class="u-role">Administrator</div>
                </div>
                <a href="../logout.php" class="icon-btn" title="Logout">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                        <polyline points="16 17 21 12 16 7"/>
                        <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                </a>
            </div>
        </div>
    </aside>

    <!-- Mobile overlay -->
    <div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>

    <!-- ══════════ MAIN ══════════ -->
    <div class="main">

        <!-- Topbar -->
        <div class="topbar">
            <button class="hamburger" id="hamburger" onclick="toggleSidebar()">
                <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <line x1="3" y1="6"  x2="21" y2="6"/>
                    <line x1="3" y1="12" x2="21" y2="12"/>
                    <line x1="3" y1="18" x2="21" y2="18"/>
                </svg>
            </button>
            <div class="topbar-title">Dashboard</div>
            <div class="breadcrumb" style="margin-right:auto;">
                <span><?php echo $today; ?></span>
            </div>
            <div style="display:flex;gap:8px;">
                <a href="add_material.php" class="btn btn-ghost btn-sm">
                    <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="17 8 12 3 7 8"/>
                        <line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    Upload
                </a>
                <a href="add_quiz.php" class="btn btn-primary btn-sm">
                    <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="5" x2="12" y2="19"/>
                        <line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                    New Quiz
                </a>
            </div>
        </div>

        <!-- Content -->
        <div class="content">

            <!-- ── Stat Cards ── -->
            <div class="stats-grid">
                <div class="stat-card c-blue anim-fade-up anim-delay-1">
                    <div class="stat-icon">👨‍🎓</div>
                    <div class="stat-value"><?php echo $total_students; ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
                <div class="stat-card c-green anim-fade-up anim-delay-2">
                    <div class="stat-icon">📄</div>
                    <div class="stat-value"><?php echo $total_materials; ?></div>
                    <div class="stat-label">Study Materials</div>
                </div>
                <div class="stat-card c-amber anim-fade-up anim-delay-3">
                    <div class="stat-icon">📝</div>
                    <div class="stat-value"><?php echo $total_quizzes; ?></div>
                    <div class="stat-label">Quizzes Created</div>
                </div>
                <div class="stat-card c-violet anim-fade-up anim-delay-4">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value"><?php echo $total_attempts; ?></div>
                    <div class="stat-label">Quiz Attempts</div>
                </div>
            </div>

            <!-- ── Quick Actions + Class Overview ── -->
            <div class="two-col">

                <!-- Quick Actions -->
                <div class="panel anim-fade-up">
                    <div class="panel-head">
                        <div class="panel-title">
                            <span class="dot" style="background:var(--accent)"></span>
                            Quick Actions
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="quick-actions">
                            <a href="add_material.php" class="action-tile">
                                <div class="action-icon" style="background:rgba(79,142,247,.12)">📤</div>
                                Upload Material
                            </a>
                            <a href="add_quiz.php" class="action-tile">
                                <div class="action-icon" style="background:rgba(167,139,250,.12)">➕</div>
                                Create Quiz
                            </a>
                            <a href="manage_users.php" class="action-tile">
                                <div class="action-icon" style="background:rgba(52,201,138,.12)">👤</div>
                                Add Student
                            </a>
                            <a href="manage_users.php" class="action-tile">
                                <div class="action-icon" style="background:rgba(245,166,35,.12)">📊</div>
                                View Results
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Class Overview -->
                <div class="panel anim-fade-up" style="animation-delay:.08s;">
                    <div class="panel-head">
                        <div class="panel-title">
                            <span class="dot" style="background:var(--violet)"></span>
                            Class Overview
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="class-row">
                            <span class="class-label-badge c9">Class 9</span>
                            <div class="bar-wrap">
                                <div class="bar-fill c9" id="bar-c9" style="width:0%"></div>
                            </div>
                            <span class="bar-count"><?php echo $c9_count; ?></span>
                        </div>
                        <div class="class-row">
                            <span class="class-label-badge c10">Class 10</span>
                            <div class="bar-wrap">
                                <div class="bar-fill c10" id="bar-c10" style="width:0%"></div>
                            </div>
                            <span class="bar-count"><?php echo $c10_count; ?></span>
                        </div>

                        <!-- Avg score ring -->
                        <div class="avg-ring">
                            <div class="ring-wrap">
                                <svg class="ring-svg" width="110" height="110" viewBox="0 0 110 110">
                                    <circle cx="55" cy="55" r="44" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="8"/>
                                    <circle id="ring-arc" cx="55" cy="55" r="44" fill="none"
                                        stroke="var(--green)" stroke-width="8"
                                        stroke-linecap="round"
                                        stroke-dasharray="<?php echo round($circumference, 2); ?>"
                                        stroke-dashoffset="<?php echo round($circumference, 2); ?>"
                                        style="transition: stroke-dashoffset 1.2s cubic-bezier(.25,.8,.25,1)"/>
                                </svg>
                                <div class="ring-label">
                                    <div class="ring-num"><?php echo $avg_score; ?></div>
                                    <div class="ring-sub">Avg Score</div>
                                </div>
                            </div>
                            <div class="avg-caption">Average across all quiz attempts</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ── Recent Results + Recent Uploads ── -->
            <div class="col-3-1">

                <!-- Results table -->
                <div class="panel anim-fade-up" style="animation-delay:.12s;">
                    <div class="panel-head">
                        <div class="panel-title">
                            <span class="dot" style="background:var(--amber)"></span>
                            Recent Quiz Results
                        </div>
                        <a href="manage_users.php" class="panel-link">View all →</a>
                    </div>
                    <?php if (empty($recent_results)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">📊</div>
                        <div class="empty-title">No results yet</div>
                        <div class="empty-sub">Quiz attempts will appear here once students start taking quizzes.</div>
                    </div>
                    <?php else: ?>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Class</th>
                                    <th>Quiz</th>
                                    <th>Score</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($recent_results as $res):
                                $score      = (int)$res['score'];
                                $pill_class = $score >= 75 ? 'high' : ($score >= 50 ? 'mid' : 'low');
                                $cc         = ($res['class'] == '9') ? 'c9' : 'c10';
                                $date       = date('d M, H:i', strtotime($res['taken_at']));
                            ?>
                            <tr>
                                <td class="td-primary"><?php echo htmlspecialchars($res['student']); ?></td>
                                <td><span class="chip chip-<?php echo $cc; ?>">Class <?php echo htmlspecialchars($res['class']); ?></span></td>
                                <td class="truncate" style="max-width:160px;"><?php echo htmlspecialchars($res['quiz']); ?></td>
                                <td><span class="score-pill <?php echo $pill_class; ?>"><?php echo $score; ?>%</span></td>
                                <td><?php echo $date; ?></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Recent uploads -->
                <div class="panel anim-fade-up" style="animation-delay:.16s;">
                    <div class="panel-head">
                        <div class="panel-title">
                            <span class="dot" style="background:var(--green)"></span>
                            Recent Uploads
                        </div>
                        <a href="add_material.php" class="panel-link">Add →</a>
                    </div>
                    <div class="panel-body" style="padding-top:8px;padding-bottom:8px;">
                        <?php if (empty($recent_materials)): ?>
                        <div class="empty-state" style="padding:28px 0;">
                            <div class="empty-icon">📂</div>
                            <div class="empty-title">No materials yet</div>
                            <div class="empty-sub">Upload study materials to get started.</div>
                        </div>
                        <?php else: ?>
                        <?php foreach ($recent_materials as $mat):
                            $ext  = strtolower(pathinfo($mat['file_path'], PATHINFO_EXTENSION));
                            $icon = match($ext) {
                                'pdf'         => '📄',
                                'ppt','pptx'  => '📊',
                                'doc','docx'  => '📝',
                                default       => '📁'
                            };
                            $date = date('d M Y', strtotime($mat['uploaded_at']));
                        ?>
                        <div class="material-row">
                            <div class="material-icon"><?php echo $icon; ?></div>
                            <div class="material-info">
                                <div class="material-title"><?php echo htmlspecialchars($mat['title']); ?></div>
                                <div class="material-meta">
                                    Class <?php echo htmlspecialchars($mat['class']); ?>
                                    &nbsp;·&nbsp;
                                    <span class="chip chip-<?php echo htmlspecialchars($mat['subject']); ?>" style="padding:1px 6px;font-size:10px;"><?php echo ucfirst(htmlspecialchars($mat['subject'])); ?></span>
                                    &nbsp;·&nbsp; <?php echo $date; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div><!-- /content -->
    </div><!-- /main -->
</div><!-- /layout -->

<script>
window.addEventListener('load', () => {
    // Animate class bars
    setTimeout(() => {
        const max = <?php echo $max_count; ?>;
        document.getElementById('bar-c9').style.width  = (<?php echo $c9_count;  ?> / max * 100) + '%';
        document.getElementById('bar-c10').style.width = (<?php echo $c10_count; ?> / max * 100) + '%';

        // Animate avg score ring
        document.getElementById('ring-arc').style.strokeDashoffset = '<?php echo round($dash_offset, 2); ?>';
    }, 300);
});

// Mobile sidebar
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('active');
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebar-overlay').classList.remove('active');
}
</script>

</body>
</html>