<?php
session_start();
require_once 'includes/db.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: student/dashboard.php");
    }
    exit();
}

$error   = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $class    = $_POST['class'] ?? '';

    // Basic validation
    if (empty($name) || empty($email) || empty($password) || empty($confirm) || empty($class)) {
        $error = "All fields are required.";
    } 
    elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } elseif (!in_array($class, ['9', '10'])) {
        $error = "Please select a valid class.";
    } else {
        // Check if username already exists
        $check = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "That Email is already taken. Please choose another.";
        } else {
            // Hash password and insert
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $role   = 'student'; // Students self-register; admins are added manually

            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, class) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $email, $hashed, $role, $class);

            if ($stmt->execute()) {
                $success = "Account created! You can now sign in.";
            } else {
                $error = "Something went wrong. Please try again.";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Register</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #1a1a2e;
            --ink2:   #2e2e4a;
            --cream:  #f5f0e8;
            --paper:  #faf7f2;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --red:    #c0392b;
            --green:  #1e7e4a;
            --border: rgba(26,26,46,0.12);
        }

        html, body {
            height: 100%;
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
        }

        .page {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 1fr 1fr;
        }

        /* ── Left Panel ── */
        .left {
            background: var(--ink);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 56px 60px;
            position: relative;
            overflow: hidden;
        }
        .left::before, .left::after {
            content: '';
            position: absolute;
            border-radius: 50%;
            border: 1px solid rgba(201,168,76,0.18);
        }
        .left::before { width: 420px; height: 420px; top: -120px; right: -140px; }
        .left::after  { width: 260px; height: 260px; bottom: -60px; left: -80px; border-color: rgba(201,168,76,0.10); }

        .brand { display: flex; align-items: center; gap: 12px; z-index: 1; }
        .brand-icon {
            width: 40px; height: 40px;
            background: var(--gold); border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
        }
        .brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 22px; color: var(--cream);
            letter-spacing: 0.02em;
        }

        .left-body { z-index: 1; }
        .left-body h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 3.5vw, 44px);
            font-weight: 700; color: var(--cream);
            line-height: 1.2; margin-bottom: 20px;
        }
        .left-body h1 em { font-style: italic; color: var(--gold2); }
        .left-body p {
            font-size: 15px;
            color: rgba(245,240,232,0.6);
            line-height: 1.7; max-width: 340px;
        }

        /* Steps list on left */
        .steps { z-index: 1; margin-top: 0; }
        .step {
            display: flex; align-items: flex-start;
            gap: 14px; margin-bottom: 20px;
        }
        .step-num {
            width: 28px; height: 28px; flex-shrink: 0;
            border: 1px solid var(--gold);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 12px; color: var(--gold2);
            font-family: 'Playfair Display', serif;
        }
        .step-text {
            font-size: 14px;
            color: rgba(245,240,232,0.55);
            line-height: 1.5;
            padding-top: 4px;
        }
        .step-text strong {
            display: block;
            color: rgba(245,240,232,0.85);
            font-weight: 500;
            margin-bottom: 2px;
        }

        /* ── Right Panel ── */
        .right {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 32px;
            background: var(--paper);
            overflow-y: auto;
        }

        .card {
            width: 100%; max-width: 420px;
            animation: fadeUp 0.4s ease both;
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(16px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .card-header { margin-bottom: 28px; }
        .card-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 28px; font-weight: 700;
            color: var(--ink); margin-bottom: 6px;
        }
        .card-header p { font-size: 14px; color: var(--muted); }

        /* ── Alerts ── */
        .alert {
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 24px;
            font-size: 13.5px;
            display: flex; align-items: center; gap: 8px;
            animation: slideIn 0.25s ease;
        }
        .alert-error {
            background: #fdf0ef;
            border: 1px solid rgba(192,57,43,0.25);
            border-left: 3px solid var(--red);
            color: var(--red);
        }
        .alert-success {
            background: #edfbf3;
            border: 1px solid rgba(30,126,74,0.25);
            border-left: 3px solid var(--green);
            color: var(--green);
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ── Form ── */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        .form-group { margin-bottom: 18px; }

        label {
            display: block;
            font-size: 12px; font-weight: 500;
            letter-spacing: 0.07em;
            text-transform: uppercase;
            color: var(--muted); margin-bottom: 8px;
        }

        .input-wrap { position: relative; }
        .input-wrap svg {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%);
            opacity: 0.35; pointer-events: none;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 12px 14px 12px 42px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 15px; color: var(--ink);
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
            appearance: none;
        }
        input[type="text"]:focus,
        input[type="password"]:focus,
        select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(201,168,76,0.12);
        }

        /* Select arrow */
        .select-wrap { position: relative; }
        .select-wrap::after {
            content: '▾';
            position: absolute; right: 14px; top: 50%;
            transform: translateY(-50%);
            color: var(--muted); pointer-events: none;
            font-size: 13px;
        }

        .eye-btn {
            position: absolute; right: 14px; top: 50%;
            transform: translateY(-50%);
            background: none; border: none; cursor: pointer;
            padding: 2px; color: var(--muted);
            display: flex; align-items: center;
        }
        .eye-btn:hover { color: var(--ink); }

        /* Password strength */
        .strength-bar {
            height: 3px;
            background: var(--border);
            border-radius: 2px;
            margin-top: 8px;
            overflow: hidden;
        }
        .strength-fill {
            height: 100%;
            border-radius: 2px;
            width: 0%;
            transition: width 0.3s, background 0.3s;
        }
        .strength-label {
            font-size: 11px; color: var(--muted);
            margin-top: 4px; text-align: right;
        }

        /* ── Class Pills ── */
        .class-select {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        .class-option input { display: none; }
        .class-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            padding: 14px 10px;
            border: 1px solid var(--border);
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px; color: var(--muted);
            background: #fff;
            transition: border-color 0.2s, background 0.2s, color 0.2s;
            user-select: none;
        }
        .class-label .class-icon { font-size: 20px; }
        .class-option input:checked + .class-label {
            border-color: var(--gold);
            background: rgba(201,168,76,0.07);
            color: var(--ink);
        }

        /* ── Submit ── */
        .btn-submit {
            width: 100%; padding: 14px;
            background: var(--ink); color: var(--cream);
            border: none; border-radius: 10px;
            font-family: 'DM Sans', sans-serif;
            font-size: 15px; font-weight: 500;
            cursor: pointer; letter-spacing: 0.03em;
            transition: background 0.2s, transform 0.1s;
            position: relative; overflow: hidden;
            margin-top: 6px;
        }
        .btn-submit::after {
            content: '';
            position: absolute; inset: 0;
            background: linear-gradient(135deg, transparent 40%, rgba(201,168,76,0.18));
            pointer-events: none;
        }
        .btn-submit:hover  { background: var(--ink2); }
        .btn-submit:active { transform: scale(0.99); }

        .divider {
            display: flex; align-items: center; gap: 12px;
            margin: 20px 0; color: var(--muted); font-size: 12px;
        }
        .divider::before, .divider::after {
            content: ''; flex: 1;
            height: 1px; background: var(--border);
        }

        .btn-login {
            width: 100%; padding: 13px;
            background: transparent;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-family: 'DM Sans', sans-serif;
            font-size: 14px; color: var(--ink);
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
            text-align: center; text-decoration: none;
            display: block;
        }
        .btn-login:hover {
            border-color: var(--gold);
            background: rgba(201,168,76,0.05);
        }

        .gold-line {
            width: 40px; height: 2px;
            background: var(--gold);
            margin: 20px auto 0;
            border-radius: 2px; opacity: 0.5;
        }

        @media (max-width: 720px) {
            .page { grid-template-columns: 1fr; }
            .left  { display: none; }
            .right { padding: 40px 24px; min-height: 100vh; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="page">

    <!-- Left Panel -->
    <div class="left">
        <div class="brand">
            <div class="brand-icon">📚</div>
            <span class="brand-name">edtech</span>
        </div>

        <div class="left-body">
            <h1>Your journey<br>starts <em>here.</em></h1>
            <p>Join hundreds of Class 9 &amp; 10 students already learning smarter with edtech.</p>
        </div>

        <div class="steps">
            <div class="step">
                <div class="step-num">1</div>
                <div class="step-text">
                    <strong>Create your account</strong>
                    Fill in your details and choose your class.
                </div>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <div class="step-text">
                    <strong>Access materials</strong>
                    Browse notes and study resources for your class.
                </div>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <div class="step-text">
                    <strong>Take quizzes</strong>
                    Test your knowledge and track your progress.
                </div>
            </div>
        </div>
    </div>

    <!-- Right Panel -->
    <div class="right">
        <div class="card">
            <div class="card-header">
                <h2>Create account</h2>
                <p>Sign up as a student — free &amp; instant</p>
            </div>

            <?php if (!empty($error)): ?>
            <div class="alert alert-error">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="12"/>
                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"/>
                </svg>
                <?php echo htmlspecialchars($success); ?>
                <a href="login.php" style="margin-left:6px; color: inherit; font-weight:500;">Sign in →</a>
            </div>
            <?php endif; ?>

            <?php if (empty($success)): ?>
            <form method="POST" action="register.php" novalidate>

                <!-- Full Name -->
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <div class="input-wrap">
                        <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        <input type="text" id="name" name="name"
                            placeholder="Your full name"
                            value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                            autocomplete="name" required>
                    </div>
                </div>

                <!-- Username -->
                <div class="form-group">
                    <label for="email">Email</label>
                    <div class="input-wrap">
                        <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        <input type="text" id="email" name="email"
                            placeholder="Choose an Email "
                            value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                            autocomplete="email" required>
                    </div>
                </div>

                <!-- Password + Confirm -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-wrap">
                            <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input type="password" id="password" name="password"
                                placeholder="Min 6 characters"
                                oninput="checkStrength(this.value)"
                                autocomplete="new-password" required>
                            <button type="button" class="eye-btn" onclick="togglePwd('password','eye1')" aria-label="Toggle">
                                <svg id="eye1" width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                            </button>
                        </div>
                        <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
                        <div class="strength-label" id="strength-label"></div>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm</label>
                        <div class="input-wrap">
                            <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input type="password" id="confirm_password" name="confirm_password"
                                placeholder="Repeat password"
                                autocomplete="new-password" required>
                            <button type="button" class="eye-btn" onclick="togglePwd('confirm_password','eye2')" aria-label="Toggle">
                                <svg id="eye2" width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Class -->
                <div class="form-group">
                    <label>Your Class</label>
                    <div class="class-select">
                        <div class="class-option">
                            <input type="radio" id="class9" name="class" value="9"
                                <?php echo (($_POST['class'] ?? '') === '9') ? 'checked' : ''; ?>>
                            <label class="class-label" for="class9">
                                <span class="class-icon">🎒</span>
                                Class 9
                            </label>
                        </div>
                        <div class="class-option">
                            <input type="radio" id="class10" name="class" value="10"
                                <?php echo (($_POST['class'] ?? '') === '10') ? 'checked' : ''; ?>>
                            <label class="class-label" for="class10">
                                <span class="class-icon">🎓</span>
                                Class 10
                            </label>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Create Account →</button>

                <div class="divider">already have an account?</div>
                <a href="login.php" class="btn-login">Sign in instead</a>

                <div class="gold-line"></div>
            </form>
            <?php endif; ?>
        </div>
    </div>

</div>

<script>
function togglePwd(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.innerHTML = `
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
            <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
            <line x1="1" y1="1" x2="23" y2="23"/>`;
    } else {
        input.type = 'password';
        icon.innerHTML = `
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <circle cx="12" cy="12" r="3"/>`;
    }
}

function checkStrength(val) {
    const fill  = document.getElementById('strength-fill');
    const label = document.getElementById('strength-label');
    let score = 0;
    if (val.length >= 6)  score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    const levels = [
        { pct: '0%',   color: 'transparent', text: '' },
        { pct: '25%',  color: '#c0392b',      text: 'Weak' },
        { pct: '50%',  color: '#e67e22',      text: 'Fair' },
        { pct: '75%',  color: '#f1c40f',      text: 'Good' },
        { pct: '100%', color: '#1e7e4a',      text: 'Strong' },
    ];
    const lvl = levels[Math.min(score, 4)];
    fill.style.width     = lvl.pct;
    fill.style.background = lvl.color;
    label.textContent    = lvl.text;
    label.style.color    = lvl.color;
}
</script>
</body>
</html>