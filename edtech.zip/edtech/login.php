<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/session.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: student/dashboard.php");
    }
    exit();
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, name, password, role, class FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Prevent session fixation
                session_regenerate_id(true);

                $_SESSION['user_id'] = $row['id'];
                $_SESSION['name']    = $row['name'];
                $_SESSION['email']   = $user['email'];
                $_SESSION['role']    = $row['role'];
                $_SESSION['class']   = $row['class'];

                if ($row['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: student/dashboard.php");
                }
                exit();
            } else {
                $error = "Incorrect email or password.";
            }
        } else {
            $error = "Incorrect email or password.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Sign In</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #1a1a2e;
            --ink2:   #2e2e4a;
            --cream:  #f5f0e8;
            --paper:  #faf7f2;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --red:    #c0392b;
            --border: rgba(26,26,46,0.12);
        }

        html, body {
            height: 100%;
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
        }

        .page {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 1fr 1fr;
        }

        /* ── Left Panel ── */
        .left {
            background: var(--ink);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 56px 60px;
            position: relative;
            overflow: hidden;
        }

        .left::before, .left::after {
            content: '';
            position: absolute;
            border-radius: 50%;
            border: 1px solid rgba(201,168,76,0.18);
        }
        .left::before { width: 420px; height: 420px; top: -120px; right: -140px; }
        .left::after  { width: 260px; height: 260px; bottom: -60px; left: -80px; border-color: rgba(201,168,76,0.10); }

        .brand { display: flex; align-items: center; gap: 12px; z-index: 1; }
        .brand-icon {
            width: 40px; height: 40px;
            background: var(--gold);
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
        }
        .brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 22px;
            color: var(--cream);
            letter-spacing: 0.02em;
        }

        .left-body { z-index: 1; }
        .left-body h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(32px, 4vw, 48px);
            font-weight: 700;
            color: var(--cream);
            line-height: 1.2;
            margin-bottom: 20px;
        }
        .left-body h1 em { font-style: italic; color: var(--gold2); }
        .left-body p {
            font-size: 15px;
            color: rgba(245,240,232,0.6);
            line-height: 1.7;
            max-width: 340px;
        }

        .left-footer { z-index: 1; display: flex; gap: 32px; }
        .stat { display: flex; flex-direction: column; gap: 4px; }
        .stat-num { font-family: 'Playfair Display', serif; font-size: 26px; color: var(--gold2); }
        .stat-label { font-size: 12px; color: rgba(245,240,232,0.45); letter-spacing: 0.08em; text-transform: uppercase; }

        /* ── Right Panel ── */
        .right {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 32px;
            background: var(--paper);
        }

        .card { width: 100%; max-width: 400px; animation: fadeUp 0.4s ease both; }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(16px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .card-header { margin-bottom: 32px; }
        .card-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 28px; font-weight: 700;
            color: var(--ink); margin-bottom: 6px;
        }
        .card-header p { font-size: 14px; color: var(--muted); }

        /* ── Error box ── */
        .error-box {
            background: #fdf0ef;
            border: 1px solid rgba(192,57,43,0.25);
            border-left: 3px solid var(--red);
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 24px;
            font-size: 13.5px;
            color: var(--red);
            display: flex; align-items: center; gap: 8px;
            animation: slideIn 0.25s ease;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-6px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ── Form ── */
        .form-group { margin-bottom: 20px; }

        label {
            display: block;
            font-size: 12px; font-weight: 500;
            letter-spacing: 0.07em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 8px;
        }

        .input-wrap { position: relative; }
        .input-wrap svg {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%);
            opacity: 0.35; pointer-events: none;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 13px 14px 13px 42px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 15px; color: var(--ink);
            transition: border-color 0.2s, box-shadow 0.2s;
            outline: none;
        }
        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(201,168,76,0.12);
        }

        .eye-btn {
            position: absolute; right: 14px; top: 50%;
            transform: translateY(-50%);
            background: none; border: none; cursor: pointer;
            padding: 2px; color: var(--muted);
            display: flex; align-items: center;
        }
        .eye-btn:hover { color: var(--ink); }

        /* ── Submit ── */
        .btn-login {
            width: 100%; padding: 14px;
            background: var(--ink); color: var(--cream);
            border: none; border-radius: 10px;
            font-family: 'DM Sans', sans-serif;
            font-size: 15px; font-weight: 500;
            cursor: pointer; letter-spacing: 0.03em;
            transition: background 0.2s, transform 0.1s;
            position: relative; overflow: hidden;
        }
        .btn-login::after {
            content: '';
            position: absolute; inset: 0;
            background: linear-gradient(135deg, transparent 40%, rgba(201,168,76,0.18));
            pointer-events: none;
        }
        .btn-login:hover  { background: var(--ink2); }
        .btn-login:active { transform: scale(0.99); }

        .divider {
            display: flex; align-items: center; gap: 12px;
            margin: 24px 0; color: var(--muted); font-size: 12px;
        }
        .divider::before, .divider::after {
            content: ''; flex: 1;
            height: 1px; background: var(--border);
        }

        .btn-register {
            width: 100%; padding: 13px;
            background: transparent;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-family: 'DM Sans', sans-serif;
            font-size: 14px; color: var(--ink);
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
            text-align: center;
            text-decoration: none;
            display: block;
        }
        .btn-register:hover {
            border-color: var(--gold);
            background: rgba(201,168,76,0.05);
        }

        .gold-line {
            width: 40px; height: 2px;
            background: var(--gold);
            margin: 24px auto 0;
            border-radius: 2px; opacity: 0.5;
        }
        .form-footer {
            margin-top: 16px; text-align: center;
            font-size: 12.5px; color: var(--muted);
        }

        @media (max-width: 720px) {
            .page { grid-template-columns: 1fr; }
            .left  { display: none; }
            .right { padding: 40px 24px; min-height: 100vh; }
        }
    </style>
</head>
<body>
<div class="page">

    <!-- Left Panel -->
    <div class="left">
        <div class="brand">
            <div class="brand-icon">📚</div>
            <span class="brand-name">edtech</span>
        </div>
        <div class="left-body">
            <h1>Learn without<br><em>limits.</em></h1>
            <p>Access your study materials, take quizzes, and track your progress — all in one place for Class 9 &amp; 10 students.</p>
        </div>
        <div class="left-footer">
            <div class="stat"><span class="stat-num">2</span><span class="stat-label">Classes</span></div>
            <div class="stat"><span class="stat-num">6+</span><span class="stat-label">Subjects</span></div>
            <div class="stat"><span class="stat-num">∞</span><span class="stat-label">Quizzes</span></div>
        </div>
    </div>

    <!-- Right Panel -->
    <div class="right">
        <div class="card">
            <div class="card-header">
                <h2>Welcome back</h2>
                <p>Sign in to continue to your portal</p>
            </div>

            <?php if (!empty($error)): ?>
            <div class="error-box">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="12"/>
                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="login.php" novalidate>

                <div class="form-group">
                    <label for="Email">Email</label>
                    <div class="input-wrap">
                        <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        <input type="text" id="Email" name="Email"
                            placeholder="Enter your Email"
                            value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                            autocomplete="Email" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrap">
                        <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                        </svg>
                        <input type="password" id="password" name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password" required>
                        <button type="button" class="eye-btn" onclick="togglePassword()" aria-label="Toggle password">
                            <svg id="eye-icon" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-login">Sign in →</button>

                <div class="divider">or</div>

                <a href="register.php" class="btn-register">Create a new account</a>

                <div class="gold-line"></div>
                <p class="form-footer">Contact your administrator if you've lost access.</p>
            </form>
        </div>
    </div>

</div>
<script>
function togglePassword() {
    const input = document.getElementById('password');
    const icon  = document.getElementById('eye-icon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.innerHTML = `
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
            <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
            <line x1="1" y1="1" x2="23" y2="23"/>`;
    } else {
        input.type = 'password';
        icon.innerHTML = `
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <circle cx="12" cy="12" r="3"/>`;
    }
}
</script>
</body>
</html>