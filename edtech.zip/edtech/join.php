<?php
// join.php (root level — public, no login required)
require_once 'includes/session.php';
require_once 'includes/db.php';

$error     = "";
$comp      = null;
$pre_code  = trim($_GET['code'] ?? '');

// If code came via URL, validate immediately
if ($pre_code !== '') {
    $s = $conn->prepare("
        SELECT c.id, c.join_code, c.status, qz.title, qz.subject, qz.`class`, qz.duration,
               (SELECT COUNT(*) FROM questions WHERE quiz_id = qz.id) AS q_count,
               (SELECT COUNT(*) FROM competition_participants WHERE competition_id = c.id) AS participants
        FROM competitions c JOIN quizzes qz ON c.quiz_id = qz.id
        WHERE c.join_code = ?
    ");
    $s->bind_param("s", $pre_code);
    $s->execute();
    $comp = $s->get_result()->fetch_assoc();
    $s->close();

    if (!$comp) $error = "Invalid code. Please check and try again.";
    elseif ($comp['status'] === 'ended') { $error = "This competition has already ended."; $comp = null; }
}

// Handle join form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code      = trim($_POST['join_code'] ?? '');
    $join_name = trim($_POST['join_name'] ?? '');

    if (empty($code) || strlen($code) !== 6) {
        $error = "Please enter a valid 6-digit code.";
    } elseif (empty($join_name)) {
        $error = "Please enter your name.";
    } else {
        // Fetch competition
        $s = $conn->prepare("
            SELECT c.id, c.join_code, c.status, qz.id AS quiz_id, qz.title, qz.subject, qz.`class`
            FROM competitions c JOIN quizzes qz ON c.quiz_id = qz.id
            WHERE c.join_code = ?
        ");
        $s->bind_param("s", $code);
        $s->execute();
        $comp_row = $s->get_result()->fetch_assoc();
        $s->close();

        if (!$comp_row) {
            $error = "Invalid code. Check and try again.";
        } elseif ($comp_row['status'] === 'ended') {
            $error = "This competition has already ended.";
        } elseif ($comp_row['status'] === 'waiting') {
            $error = "This competition hasn't started yet. Please wait for the teacher to start it.";
        } else {
            // Check if already joined (by session participant_id)
            $user_id = is_logged_in() ? get_user_id() : null;

            // If logged in, check by user_id
            if ($user_id) {
                $s = $conn->prepare("SELECT id FROM competition_participants WHERE competition_id = ? AND user_id = ?");
                $s->bind_param("ii", $comp_row['id'], $user_id);
                $s->execute();
                $s->store_result();
                if ($s->num_rows > 0) {
                    $s->bind_result($existing_id);
                    $s->fetch();
                    $s->close();
                    $_SESSION['participant_id'] = $existing_id;
                    header("Location: play_competition.php?id={$comp_row['id']}");
                    exit();
                }
                $s->close();
            }

            // Insert participant
            $s = $conn->prepare("INSERT INTO competition_participants (competition_id, user_id, guest_name) VALUES (?,?,?)");
            $s->bind_param("iis", $comp_row['id'], $user_id, $join_name);
            if ($s->execute()) {
                $_SESSION['participant_id'] = $conn->insert_id;
                $_SESSION['join_name']      = $join_name;
                $s->close();
                header("Location: play_competition.php?id={$comp_row['id']}");
                exit();
            } else {
                $error = "Could not join. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Join Quiz</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--ink2:#2e2e4a;--cream:#f5f0e8;--paper:#faf7f2;--gold:#c9a84c;--gold2:#e8c96a;--muted:#7a7a8a;--red:#c0392b;--green:#1e7e4a;--border:rgba(26,26,46,0.12)}
        html,body{height:100%;font-family:'DM Sans',sans-serif;background:var(--ink);color:var(--ink)}
        .page{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 20px;background:var(--ink);position:relative;overflow:hidden}
        .page::before{content:'';position:absolute;width:600px;height:600px;border-radius:50%;border:1px solid rgba(201,168,76,.08);top:-200px;right:-200px}
        .page::after{content:'';position:absolute;width:400px;height:400px;border-radius:50%;border:1px solid rgba(201,168,76,.06);bottom:-100px;left:-150px}
        .logo{display:flex;align-items:center;gap:10px;margin-bottom:40px;z-index:1}
        .logo-icon{width:36px;height:36px;background:var(--gold);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px}
        .logo-text{font-family:'Playfair Display',serif;font-size:20px;color:var(--cream)}
        .card{background:var(--paper);border-radius:18px;padding:36px;width:100%;max-width:420px;z-index:1;animation:fadeUp .4s ease both}
        @keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
        .card-header{margin-bottom:28px;text-align:center}
        .card-icon{font-size:36px;margin-bottom:10px}
        .card-header h1{font-family:'Playfair Display',serif;font-size:26px;color:var(--ink);margin-bottom:6px}
        .card-header p{font-size:14px;color:var(--muted)}
        .alert{border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13.5px;display:flex;align-items:center;gap:8px}
        .alert-error{background:#fdf0ef;border:1px solid rgba(192,57,43,.25);border-left:3px solid var(--red);color:var(--red)}
        .alert-info{background:rgba(201,168,76,.1);border:1px solid rgba(201,168,76,.3);border-left:3px solid var(--gold);color:var(--ink)}
        /* Competition info card */
        .comp-info{background:var(--ink);border-radius:12px;padding:18px;margin-bottom:22px;text-align:center}
        .comp-status{font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:var(--gold2);margin-bottom:6px;font-weight:600}
        .comp-title{font-family:'Playfair Display',serif;font-size:18px;color:var(--cream);margin-bottom:4px}
        .comp-meta{font-size:12px;color:rgba(245,240,232,.5)}
        .form-group{margin-bottom:18px}
        label{display:block;font-size:11.5px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin-bottom:7px}
        .code-input{width:100%;padding:16px;border:1.5px solid var(--border);border-radius:12px;background:#fff;font-family:'Playfair Display',serif;font-size:28px;color:var(--ink);outline:none;text-align:center;letter-spacing:.2em;transition:border-color .2s,box-shadow .2s}
        .code-input:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.12)}
        input[type=text]{width:100%;padding:12px 14px;border:1.5px solid var(--border);border-radius:10px;background:#fff;font-family:'DM Sans',sans-serif;font-size:15px;color:var(--ink);outline:none;transition:border-color .2s,box-shadow .2s}
        input[type=text]:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.12)}
        .btn-join{width:100%;padding:15px;background:var(--gold);color:var(--ink);border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;transition:background .2s,transform .1s;letter-spacing:.02em}
        .btn-join:hover{background:var(--gold2)}
        .btn-join:active{transform:scale(.99)}
        .footer-links{margin-top:28px;text-align:center;z-index:1}
        .footer-links a{color:rgba(245,240,232,.45);font-size:13px;text-decoration:none;margin:0 12px}
        .footer-links a:hover{color:var(--gold2)}
        .divider{display:flex;align-items:center;gap:12px;margin:20px 0;color:var(--muted);font-size:12px}
        .divider::before,.divider::after{content:'';flex:1;height:1px;background:var(--border)}
    </style>
</head>
<body>
<div class="page">
    <div class="logo">
        <div class="logo-icon">📚</div>
        <span class="logo-text">edtech</span>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-icon">🎮</div>
            <h1>Join Competition</h1>
            <p>Enter the 6-digit code from your teacher</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($comp && $comp['status'] === 'waiting'): ?>
        <div class="alert alert-info">⏳ This competition hasn't started yet. Enter your name and wait — the page will refresh when it starts.</div>
        <?php endif; ?>

        <?php if ($comp): ?>
        <div class="comp-info">
            <div class="comp-status"><?php echo $comp['status'] === 'live' ? '● Live Now' : '⏳ Waiting to Start'; ?></div>
            <div class="comp-title"><?php echo htmlspecialchars($comp['title']); ?></div>
            <div class="comp-meta"><?php echo htmlspecialchars($comp['subject']); ?> · Class <?php echo htmlspecialchars($comp['class']); ?> · <?php echo $comp['q_count']; ?> questions · <?php echo $comp['participants']; ?> joined</div>
        </div>
        <?php endif; ?>

        <form method="POST" action="join.php">
            <div class="form-group">
                <label>Game Code</label>
                <input type="text" class="code-input" name="join_code"
                    value="<?php echo htmlspecialchars($pre_code ?: ($_POST['join_code'] ?? '')); ?>"
                    placeholder="000000"
                    maxlength="6"
                    oninput="this.value=this.value.replace(/\D/g,'')"
                    required>
            </div>

            <div class="form-group">
                <label>Your Name</label>
                <input type="text" name="join_name"
                    placeholder="Enter your name"
                    value="<?php echo htmlspecialchars(is_logged_in() ? get_name() : ($_POST['join_name'] ?? '')); ?>"
                    required>
            </div>

            <button type="submit" class="btn-join">Join Game →</button>
        </form>

        <div class="divider">or</div>
        <div style="text-align:center">
            <a href="index.php" style="color:var(--muted);font-size:13.5px;text-decoration:none">← Sign in to your account</a>
        </div>
    </div>

    <div class="footer-links">
        <a href="index.php">Student Login</a>
        <a href="index.php?tab=teacher">Host a Quiz</a>
    </div>
</div>
</body>
</html>