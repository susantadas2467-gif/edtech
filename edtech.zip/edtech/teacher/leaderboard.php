<?php
// teacher/leaderboard.php
require_once '../includes/session.php';
require_once '../includes/db.php';

if (!is_logged_in() || (get_role() !== 'teacher' && get_role() !== 'admin')) {
    header("Location: ../index.php"); exit();
}

$teacher_id = get_user_id();
$comp_id    = (int)($_GET['id'] ?? 0);
if (!$comp_id) { header("Location: dashboard.php"); exit(); }

// Fetch competition
$s = $conn->prepare("
    SELECT c.*, qz.title AS quiz_title, qz.subject, qz.`class`,
           (SELECT COUNT(*) FROM questions WHERE quiz_id = qz.id) AS total_questions
    FROM competitions c JOIN quizzes qz ON c.quiz_id = qz.id
    WHERE c.id = ? AND c.host_id = ?
");
$s->bind_param("ii", $comp_id, $teacher_id);
$s->execute();
$comp = $s->get_result()->fetch_assoc();
$s->close();

if (!$comp) { header("Location: dashboard.php"); exit(); }

// Leaderboard — ranked by score desc, finished_at asc (faster wins tiebreak)
$s = $conn->prepare("
    SELECT cp.id, cp.guest_name, cp.score, cp.total_marks, cp.joined_at, cp.finished_at,
           u.name AS user_name, u.email,
           (SELECT COUNT(*) FROM competition_answers WHERE participant_id = cp.id AND is_correct = 1) AS correct_count,
           (SELECT COUNT(*) FROM competition_answers WHERE participant_id = cp.id) AS answered
    FROM competition_participants cp
    LEFT JOIN users u ON cp.user_id = u.id
    WHERE cp.competition_id = ?
    ORDER BY cp.score DESC, cp.finished_at ASC
");
$s->bind_param("i", $comp_id);
$s->execute();
$participants = $s->get_result()->fetch_all(MYSQLI_ASSOC);
$s->close();

// Stats
$total      = count($participants);
$finished   = count(array_filter($participants, fn($p) => $p['finished_at']));
$scores     = array_column($participants, 'score');
$avg_score  = $total ? round(array_sum($scores) / $total, 1) : 0;
$top_score  = $total ? max($scores) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Leaderboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <?php if ($comp['status'] === 'live'): ?>
    <meta http-equiv="refresh" content="8">
    <?php endif; ?>
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--ink2:#2e2e4a;--cream:#f5f0e8;--paper:#faf7f2;--gold:#c9a84c;--gold2:#e8c96a;--muted:#7a7a8a;--red:#c0392b;--green:#1e7e4a;--border:rgba(26,26,46,.12)}
        body{font-family:'DM Sans',sans-serif;background:var(--cream);min-height:100vh}
        .topbar{background:var(--ink);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
        .brand{display:flex;align-items:center;gap:10px}
        .brand-icon{width:32px;height:32px;background:var(--gold);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px}
        .brand-name{font-family:'Playfair Display',serif;font-size:18px;color:var(--cream)}
        .topbar-right{display:flex;gap:12px;align-items:center}
        .topbar a{color:rgba(245,240,232,.7);text-decoration:none;font-size:13.5px}
        .topbar a:hover{color:var(--gold2)}
        /* Hero */
        .hero{background:linear-gradient(135deg,var(--ink) 0%,#2e2e4a 100%);padding:36px 32px;text-align:center;position:relative;overflow:hidden}
        .hero::before{content:'🏆';position:absolute;font-size:200px;opacity:.04;top:-30px;left:50%;transform:translateX(-50%)}
        .status-pill{display:inline-flex;align-items:center;gap:6px;padding:4px 14px;border-radius:20px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px}
        .status-pill.live{background:rgba(34,197,94,.2);color:#4ade80;animation:pulse 1.5s infinite}
        .status-pill.ended{background:rgba(255,255,255,.08);color:rgba(245,240,232,.6)}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
        h1{font-family:'Playfair Display',serif;font-size:28px;color:var(--cream);margin-bottom:6px}
        .hero-sub{font-size:13.5px;color:rgba(245,240,232,.5)}
        /* Stats */
        .stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:0;background:rgba(255,255,255,.05);border-top:1px solid rgba(255,255,255,.08);margin-top:24px}
        .stat-item{padding:18px;text-align:center;border-right:1px solid rgba(255,255,255,.08)}
        .stat-item:last-child{border-right:none}
        .stat-n{font-family:'Playfair Display',serif;font-size:24px;color:var(--gold2)}
        .stat-l{font-size:11px;color:rgba(245,240,232,.4);text-transform:uppercase;letter-spacing:.06em;margin-top:2px}
        /* Podium */
        .container{max-width:800px;margin:0 auto;padding:32px 20px 60px}
        .podium{display:flex;align-items:flex-end;justify-content:center;gap:12px;margin-bottom:36px}
        .podium-item{display:flex;flex-direction:column;align-items:center;gap:8px}
        .podium-name{font-size:12.5px;font-weight:500;color:var(--ink);max-width:90px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .podium-score{font-size:11px;color:var(--muted)}
        .podium-block{display:flex;align-items:center;justify-content:center;border-radius:8px 8px 0 0;width:90px;font-size:20px;font-weight:700;color:#fff}
        .podium-block.p1{height:100px;background:linear-gradient(135deg,#c9a84c,#e8c96a);color:var(--ink)}
        .podium-block.p2{height:75px;background:#94a3b8}
        .podium-block.p3{height:56px;background:#b45309}
        /* Table */
        .section-card{background:var(--paper);border:1px solid var(--border);border-radius:14px;overflow:hidden}
        .section-header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
        .section-header h2{font-family:'Playfair Display',serif;font-size:16px}
        .live-tag{font-size:11px;color:#22c55e;animation:pulse 1.5s infinite}
        table{width:100%;border-collapse:collapse}
        thead th{background:var(--ink);color:var(--cream);font-size:11px;text-transform:uppercase;letter-spacing:.06em;text-align:left;padding:12px 16px;font-weight:500}
        tbody tr{border-bottom:1px solid var(--border);transition:background .15s}
        tbody tr:last-child{border-bottom:none}
        tbody tr:hover{background:rgba(201,168,76,.03)}
        tbody td{padding:13px 16px;font-size:13.5px;color:var(--ink)}
        .rank-medal{font-size:16px}
        .participant-name{font-weight:500}
        .participant-sub{font-size:11.5px;color:var(--muted);margin-top:1px}
        .score-cell{font-family:'Playfair Display',serif;font-size:16px;color:var(--gold)}
        .accuracy{font-size:12px;color:var(--muted)}
        .badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px}
        .badge-done{background:rgba(30,126,74,.1);color:var(--green)}
        .badge-playing{background:rgba(37,99,235,.1);color:#2563eb;animation:pulse 1.5s infinite}
        .time-cell{font-size:12px;color:var(--muted)}
        .empty-state{padding:48px;text-align:center;color:var(--muted)}
        @media(max-width:640px){.stats-row{grid-template-columns:1fr 1fr}.podium{gap:8px}.podium-block{width:72px}.container{padding:24px 14px 40px}}
    </style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech</span>
    </div>
    <div class="topbar-right">
        <?php if ($comp['status'] === 'live'): ?>
        <a href="manage_competition.php?id=<?php echo $comp_id; ?>&action=end"
           style="color:var(--red)" onclick="return confirm('End competition?')">■ End Competition</a>
        <?php endif; ?>
        <a href="manage_competition.php?id=<?php echo $comp_id; ?>">← Manage</a>
        <a href="dashboard.php">Dashboard</a>
    </div>
</div>

<!-- Hero -->
<div class="hero">
    <div class="status-pill <?php echo $comp['status']; ?>">
        <?php echo $comp['status'] === 'live' ? '● Live Leaderboard' : '✓ Final Results'; ?>
    </div>
    <h1><?php echo htmlspecialchars($comp['quiz_title']); ?></h1>
    <div class="hero-sub"><?php echo htmlspecialchars($comp['subject']); ?> · Class <?php echo htmlspecialchars($comp['class']); ?> · Join code: <strong style="color:var(--gold2)"><?php echo htmlspecialchars($comp['join_code']); ?></strong></div>
    <div class="stats-row">
        <div class="stat-item"><div class="stat-n"><?php echo $total; ?></div><div class="stat-l">Players</div></div>
        <div class="stat-item"><div class="stat-n"><?php echo $finished; ?></div><div class="stat-l">Finished</div></div>
        <div class="stat-item"><div class="stat-n"><?php echo $avg_score; ?></div><div class="stat-l">Avg Score</div></div>
        <div class="stat-item"><div class="stat-n"><?php echo $top_score; ?></div><div class="stat-l">Top Score</div></div>
    </div>
</div>

<div class="container">

    <!-- Podium (top 3) -->
    <?php if (count($participants) >= 3): ?>
    <div class="podium">
        <!-- 2nd -->
        <div class="podium-item">
            <div class="podium-name"><?php echo htmlspecialchars(mb_substr($participants[1]['user_name'] ?? $participants[1]['guest_name'] ?? 'Guest', 0, 12)); ?></div>
            <div class="podium-score"><?php echo $participants[1]['score']; ?> pts</div>
            <div class="podium-block p2">2</div>
        </div>
        <!-- 1st -->
        <div class="podium-item">
            <div style="font-size:20px;margin-bottom:2px">🏆</div>
            <div class="podium-name" style="font-weight:700"><?php echo htmlspecialchars(mb_substr($participants[0]['user_name'] ?? $participants[0]['guest_name'] ?? 'Guest', 0, 12)); ?></div>
            <div class="podium-score"><?php echo $participants[0]['score']; ?> pts</div>
            <div class="podium-block p1">1</div>
        </div>
        <!-- 3rd -->
        <div class="podium-item">
            <div class="podium-name"><?php echo htmlspecialchars(mb_substr($participants[2]['user_name'] ?? $participants[2]['guest_name'] ?? 'Guest', 0, 12)); ?></div>
            <div class="podium-score"><?php echo $participants[2]['score']; ?> pts</div>
            <div class="podium-block p3">3</div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Full leaderboard table -->
    <div class="section-card">
        <div class="section-header">
            <h2>Full Rankings</h2>
            <?php if ($comp['status'] === 'live'): ?>
            <span class="live-tag">● Auto-refreshing every 8s</span>
            <?php endif; ?>
        </div>

        <?php if (empty($participants)): ?>
        <div class="empty-state">No participants yet — share the code!</div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Score</th>
                    <th>Correct</th>
                    <th>Status</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($participants as $i => $p):
                    $name      = $p['user_name'] ?? $p['guest_name'] ?? 'Guest';
                    $accuracy  = $p['answered'] ? round(($p['correct_count'] / $p['answered']) * 100) : 0;
                    $duration  = $p['finished_at'] && $p['joined_at']
                        ? gmdate('i:s', strtotime($p['finished_at']) - strtotime($p['joined_at']))
                        : '—';
                ?>
                <tr>
                    <td class="rank-medal">
                        <?php echo $i === 0 ? '🥇' : ($i === 1 ? '🥈' : ($i === 2 ? '🥉' : '<span style="color:var(--muted);font-size:12px">'.($i+1).'</span>')); ?>
                    </td>
                    <td>
                        <div class="participant-name"><?php echo htmlspecialchars($name); ?></div>
                        <?php if ($p['email']): ?>
                        <div class="participant-sub"><?php echo htmlspecialchars($p['email']); ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="score-cell"><?php echo $p['score']; ?></span>
                        <?php echo $p['total_marks'] ? '<span class="accuracy"> / '.$p['total_marks'].'</span>' : ''; ?>
                    </td>
                    <td><span class="accuracy"><?php echo $p['correct_count']; ?>/<?php echo $p['answered']; ?> (<?php echo $accuracy; ?>%)</span></td>
                    <td><?php echo $p['finished_at'] ? '<span class="badge badge-done">Done</span>' : '<span class="badge badge-playing">Playing</span>'; ?></td>
                    <td class="time-cell"><?php echo $duration; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>