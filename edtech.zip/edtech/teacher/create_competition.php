<?php
// teacher/create_competition.php
require_once '../includes/session.php';
require_once '../includes/db.php';

if (!is_logged_in() || (get_role() !== 'teacher' && get_role() !== 'admin')) {
    header("Location: ../index.php"); exit();
}

$teacher_id = get_user_id();
$error = "";

// Generate unique 6-digit code
function generate_code($conn) {
    do {
        $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $r = $conn->prepare("SELECT id FROM competitions WHERE join_code = ?");
        $r->bind_param("s", $code);
        $r->execute();
        $r->store_result();
        $exists = $r->num_rows > 0;
        $r->close();
    } while ($exists);
    return $code;
}

// Fetch existing quizzes for "pick existing" option
$quizzes = [];
$r = $conn->query("SELECT id, title, subject, `class`, duration,
    (SELECT COUNT(*) FROM questions WHERE quiz_id = quizzes.id) AS q_count
    FROM quizzes ORDER BY created_at DESC");
while ($row = $r->fetch_assoc()) $quizzes[] = $row;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode    = $_POST['mode'] ?? 'existing'; // 'existing' or 'new'
    $quiz_id = 0;

    if ($mode === 'existing') {
        $quiz_id = (int)($_POST['quiz_id'] ?? 0);
        if (!$quiz_id) { $error = "Please select a quiz."; }

    } else {
        // Create new quiz on the fly
        $title    = trim($_POST['new_title'] ?? '');
        $subject  = trim($_POST['new_subject'] ?? '');
        $class    = $_POST['new_class'] ?? '';
        $duration = (int)($_POST['new_duration'] ?? 10);
        $q_texts  = $_POST['question_text']   ?? [];
        $q_types  = $_POST['question_type']   ?? [];
        $opt_a    = $_POST['option_a']        ?? [];
        $opt_b    = $_POST['option_b']        ?? [];
        $opt_c    = $_POST['option_c']        ?? [];
        $opt_d    = $_POST['option_d']        ?? [];
        $cor_opt  = $_POST['correct_option']  ?? [];
        $cor_txt  = $_POST['correct_answer_text'] ?? [];
        $marks    = $_POST['marks']           ?? [];

        if (empty($title) || empty($subject) || empty($class)) {
            $error = "Please fill quiz title, subject and class.";
        } elseif (count(array_filter($q_texts)) === 0) {
            $error = "Add at least one question.";
        } else {
            $conn->begin_transaction();
            try {
                $s = $conn->prepare("INSERT INTO quizzes (title, subject, `class`, duration, created_by) VALUES (?,?,?,?,?)");
                $s->bind_param("sssii", $title, $subject, $class, $duration, $teacher_id);
                $s->execute();
                $quiz_id = $conn->insert_id;
                $s->close();

                $qs = $conn->prepare("INSERT INTO questions
                    (quiz_id, question_text, question_type, option_a, option_b, option_c, option_d, correct_option, correct_answer_text, marks)
                    VALUES (?,?,?,?,?,?,?,?,?,?)");
                foreach ($q_texts as $i => $text) {
                    if (empty(trim($text))) continue;
                    $type = $q_types[$i] === 'mcq' ? 'mcq' : 'short_answer';
                    $a = $type === 'mcq' ? $opt_a[$i] : null;
                    $b = $type === 'mcq' ? $opt_b[$i] : null;
                    $c = $type === 'mcq' ? $opt_c[$i] : null;
                    $d = $type === 'mcq' ? $opt_d[$i] : null;
                    $co = $type === 'mcq' ? $cor_opt[$i] : null;
                    $ct = $type === 'short_answer' ? trim($cor_txt[$i] ?? '') : null;
                    $mk = max(1, (int)($marks[$i] ?? 1));
                    $qs->bind_param("ississsssi", $quiz_id, $text, $type, $a, $b, $c, $d, $co, $ct, $mk);
                    $qs->execute();
                }
                $qs->close();
                $conn->commit();
            } catch (Exception $e) {
                $conn->rollback();
                $error = "Failed to save quiz. Please try again.";
                $quiz_id = 0;
            }
        }
    }

    // Create the competition
    if (!$error && $quiz_id) {
        $code = generate_code($conn);
        $s = $conn->prepare("INSERT INTO competitions (quiz_id, host_id, join_code, status) VALUES (?,?,?,'waiting')");
        $s->bind_param("iis", $quiz_id, $teacher_id, $code);
        if ($s->execute()) {
            $comp_id = $conn->insert_id;
            $s->close();
            set_flash('success', "Competition created! Code: $code");
            header("Location: manage_competition.php?id=$comp_id");
            exit();
        } else {
            $error = "Failed to create competition.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Create Competition</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--ink2:#2e2e4a;--cream:#f5f0e8;--paper:#faf7f2;--gold:#c9a84c;--gold2:#e8c96a;--muted:#7a7a8a;--red:#c0392b;--green:#1e7e4a;--border:rgba(26,26,46,0.12)}
        body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);min-height:100vh}
        .topbar{background:var(--ink);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
        .brand{display:flex;align-items:center;gap:10px}
        .brand-icon{width:32px;height:32px;background:var(--gold);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px}
        .brand-name{font-family:'Playfair Display',serif;font-size:18px;color:var(--cream)}
        .topbar a{color:rgba(245,240,232,0.7);text-decoration:none;font-size:13.5px}
        .topbar a:hover{color:var(--gold2)}
        .container{max-width:760px;margin:0 auto;padding:40px 24px 80px}
        .page-header{margin-bottom:28px}
        .page-header h1{font-family:'Playfair Display',serif;font-size:28px;margin-bottom:6px}
        .page-header p{color:var(--muted);font-size:14px}
        .alert{border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13.5px;display:flex;align-items:center;gap:8px}
        .alert-error{background:#fdf0ef;border:1px solid rgba(192,57,43,.25);border-left:3px solid var(--red);color:var(--red)}
        /* Mode toggle */
        .mode-toggle{display:grid;grid-template-columns:1fr 1fr;gap:0;border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-bottom:24px}
        .mode-btn{padding:12px;text-align:center;font-size:13.5px;cursor:pointer;border:none;background:var(--paper);color:var(--muted);font-family:'DM Sans',sans-serif;transition:all .15s}
        .mode-btn.active{background:var(--ink);color:var(--cream)}
        .card{background:var(--paper);border:1px solid var(--border);border-radius:14px;padding:26px;margin-bottom:20px}
        .card h2{font-family:'Playfair Display',serif;font-size:17px;margin-bottom:18px}
        .form-group{margin-bottom:16px}
        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        label{display:block;font-size:11.5px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin-bottom:7px}
        input[type=text],input[type=number],select,textarea{width:100%;padding:11px 13px;border:1px solid var(--border);border-radius:9px;background:#fff;font-family:'DM Sans',sans-serif;font-size:14.5px;color:var(--ink);outline:none;transition:border-color .2s,box-shadow .2s}
        input:focus,select:focus,textarea:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.12)}
        textarea{resize:vertical;min-height:56px}
        /* Quiz picker */
        .quiz-picker{display:flex;flex-direction:column;gap:10px}
        .quiz-option{display:flex;align-items:center;gap:12px;padding:14px;border:1px solid var(--border);border-radius:10px;cursor:pointer;transition:border-color .15s,background .15s}
        .quiz-option:hover{border-color:var(--gold);background:rgba(201,168,76,.04)}
        .quiz-option input[type=radio]{accent-color:var(--gold)}
        .quiz-option-info{flex:1}
        .quiz-option-title{font-size:13.5px;font-weight:500}
        .quiz-option-meta{font-size:11.5px;color:var(--muted);margin-top:2px}
        .quiz-option-class{font-size:11px;font-weight:600;padding:2px 8px;border-radius:6px;background:rgba(201,168,76,.1);color:var(--gold)}
        /* Question blocks */
        .question-block{border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:14px;background:#fff}
        .q-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
        .q-num{font-family:'Playfair Display',serif;font-size:14px;color:var(--gold)}
        .remove-btn{background:none;border:none;color:var(--red);cursor:pointer;font-size:12px}
        .type-toggle{display:flex;gap:8px;margin-bottom:14px}
        .type-btn{flex:1;text-align:center;padding:8px;border:1px solid var(--border);border-radius:8px;font-size:12.5px;color:var(--muted);cursor:pointer;background:var(--paper);transition:all .15s}
        .type-btn.active{border-color:var(--gold);background:rgba(201,168,76,.08);color:var(--ink);font-weight:500}
        .opts-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}
        .opt-wrap{position:relative}
        .opt-letter{position:absolute;left:11px;top:50%;transform:translateY(-50%);font-size:11px;font-weight:700;color:var(--gold)}
        .opt-wrap input{padding-left:28px}
        .short-section{display:none}
        .mcq-section{display:block}
        /* Buttons */
        .btn-add{width:100%;padding:12px;background:transparent;border:1.5px dashed var(--gold);border-radius:10px;color:var(--ink);font-size:13.5px;cursor:pointer;transition:background .2s}
        .btn-add:hover{background:rgba(201,168,76,.05)}
        .btn-submit{width:100%;padding:14px;background:var(--ink);color:var(--cream);border:none;border-radius:10px;font-size:15px;font-weight:500;cursor:pointer;margin-top:8px;transition:background .2s}
        .btn-submit:hover{background:var(--ink2)}
        @media(max-width:600px){.form-row{grid-template-columns:1fr}.opts-grid{grid-template-columns:1fr}}
    </style>
</head>
<body>
<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech</span>
    </div>
    <a href="dashboard.php">← Back to Dashboard</a>
</div>

<div class="container">
    <div class="page-header">
        <h1>Create Competition</h1>
        <p>Pick an existing quiz or write new questions — a 6-digit code will be generated.</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="create_competition.php" id="mainForm">
        <input type="hidden" name="mode" id="modeInput" value="existing">

        <!-- Mode toggle -->
        <div class="mode-toggle">
            <button type="button" class="mode-btn active" id="btnExisting" onclick="setMode('existing')">📋 Use Existing Quiz</button>
            <button type="button" class="mode-btn" id="btnNew" onclick="setMode('new')">✏️ Write New Questions</button>
        </div>

        <!-- EXISTING QUIZ PICKER -->
        <div id="existingSection" class="card">
            <h2>Select a Quiz</h2>
            <?php if (empty($quizzes)): ?>
            <p style="color:var(--muted);font-size:13.5px">No quizzes yet — use "Write New Questions" instead, or <a href="../admin/add_quiz.php" style="color:var(--gold)">create a quiz first</a>.</p>
            <?php else: ?>
            <div class="quiz-picker">
                <?php foreach ($quizzes as $q): ?>
                <label class="quiz-option">
                    <input type="radio" name="quiz_id" value="<?php echo $q['id']; ?>">
                    <div class="quiz-option-info">
                        <div class="quiz-option-title"><?php echo htmlspecialchars($q['title']); ?></div>
                        <div class="quiz-option-meta"><?php echo htmlspecialchars($q['subject']); ?> · <?php echo $q['q_count']; ?> questions · <?php echo $q['duration']; ?> mins</div>
                    </div>
                    <span class="quiz-option-class">Class <?php echo htmlspecialchars($q['class']); ?></span>
                </label>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- NEW QUIZ FORM -->
        <div id="newSection" style="display:none">
            <div class="card">
                <h2>Quiz Details</h2>
                <div class="form-group">
                    <label>Quiz Title</label>
                    <input type="text" name="new_title" placeholder="e.g. Science Chapter 5">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Subject</label>
                        <input type="text" name="new_subject" placeholder="e.g. Physics">
                    </div>
                    <div class="form-group">
                        <label>Class</label>
                        <select name="new_class">
                            <option value="">Select</option>
                            <option value="9">Class 9</option>
                            <option value="10">Class 10</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Duration (minutes)</label>
                    <input type="number" name="new_duration" value="10" min="1" max="120" style="max-width:120px">
                </div>
            </div>

            <div id="questionsContainer"></div>
            <button type="button" class="btn-add" onclick="addQuestion()">+ Add Question</button>
        </div>

        <button type="submit" class="btn-submit" style="margin-top:20px">🚀 Create Competition →</button>
    </form>
</div>

<template id="qTemplate">
    <div class="question-block">
        <div class="q-header">
            <span class="q-num">Question __N__</span>
            <button type="button" class="remove-btn" onclick="removeQ(this)">✕ Remove</button>
        </div>
        <div class="type-toggle">
            <div class="type-btn active" onclick="setType(this,'mcq')">Multiple Choice</div>
            <div class="type-btn" onclick="setType(this,'short_answer')">Short Answer</div>
        </div>
        <input type="hidden" name="question_type[]" class="type-input" value="mcq">
        <div class="form-group">
            <label>Question</label>
            <textarea name="question_text[]" placeholder="Enter the question..."></textarea>
        </div>
        <div class="mcq-section">
            <div class="opts-grid">
                <div class="opt-wrap"><span class="opt-letter">A</span><input type="text" name="option_a[]" placeholder="Option A"></div>
                <div class="opt-wrap"><span class="opt-letter">B</span><input type="text" name="option_b[]" placeholder="Option B"></div>
                <div class="opt-wrap"><span class="opt-letter">C</span><input type="text" name="option_c[]" placeholder="Option C"></div>
                <div class="opt-wrap"><span class="opt-letter">D</span><input type="text" name="option_d[]" placeholder="Option D"></div>
            </div>
            <div class="form-group">
                <label>Correct Option</label>
                <select name="correct_option[]">
                    <option value="">Select</option>
                    <option value="a">A</option><option value="b">B</option>
                    <option value="c">C</option><option value="d">D</option>
                </select>
            </div>
        </div>
        <div class="short-section">
            <div class="form-group">
                <label>Correct Answer</label>
                <input type="text" name="correct_answer_text[]" placeholder="Expected answer">
            </div>
        </div>
        <div class="form-group" style="max-width:120px">
            <label>Marks</label>
            <input type="number" name="marks[]" value="1" min="1" max="20">
        </div>
    </div>
</template>

<script>
let qCount = 0;
function setMode(mode) {
    document.getElementById('modeInput').value = mode;
    document.getElementById('existingSection').style.display = mode === 'existing' ? 'block' : 'none';
    document.getElementById('newSection').style.display = mode === 'new' ? 'block' : 'none';
    document.getElementById('btnExisting').classList.toggle('active', mode === 'existing');
    document.getElementById('btnNew').classList.toggle('active', mode === 'new');
    if (mode === 'new' && qCount === 0) addQuestion();
}
function addQuestion() {
    qCount++;
    const t = document.getElementById('qTemplate').content.cloneNode(true);
    t.querySelector('.q-num').textContent = 'Question ' + qCount;
    document.getElementById('questionsContainer').appendChild(t);
}
function removeQ(btn) {
    btn.closest('.question-block').remove();
    document.querySelectorAll('.question-block .q-num').forEach((el,i) => el.textContent = 'Question '+(i+1));
    qCount = document.querySelectorAll('.question-block').length;
}
function setType(btn, type) {
    const block = btn.closest('.question-block');
    block.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    block.querySelector('.type-input').value = type;
    block.querySelector('.mcq-section').style.display = type === 'mcq' ? 'block' : 'none';
    block.querySelector('.short-section').style.display = type === 'short_answer' ? 'block' : 'none';
}
</script>
</body>
</html>