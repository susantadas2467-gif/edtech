<?php
// teacher/manage_competition.php
require_once '../includes/session.php';
require_once '../includes/db.php';

if (!is_logged_in() || (get_role() !== 'teacher' && get_role() !== 'admin')) {
    header("Location: ../index.php"); exit();
}

$teacher_id = get_user_id();
$comp_id    = (int)($_GET['id'] ?? 0);
if (!$comp_id) { header("Location: dashboard.php"); exit(); }

// Fetch competition (must belong to this teacher)
$s = $conn->prepare("
    SELECT c.*, qz.title AS quiz_title, qz.subject, qz.`class`, qz.duration,
           (SELECT COUNT(*) FROM questions WHERE quiz_id = qz.id) AS total_questions
    FROM competitions c
    JOIN quizzes qz ON c.quiz_id = qz.id
    WHERE c.id = ? AND c.host_id = ?
");
$s->bind_param("ii", $comp_id, $teacher_id);
$s->execute();
$comp = $s->get_result()->fetch_assoc();
$s->close();

if (!$comp) { header("Location: dashboard.php"); exit(); }

// Handle actions
$action = $_GET['action'] ?? '';

if ($action === 'start' && $comp['status'] === 'waiting') {
    $conn->prepare("UPDATE competitions SET status='live', started_at=NOW() WHERE id=?")->execute() ?: null;
    $s = $conn->prepare("UPDATE competitions SET status='live', started_at=NOW() WHERE id=?");
    $s->bind_param("i", $comp_id);
    $s->execute(); $s->close();
    set_flash('success', 'Competition started! Students can now join.');
    header("Location: manage_competition.php?id=$comp_id"); exit();
}

if ($action === 'end' && $comp['status'] === 'live') {
    $s = $conn->prepare("UPDATE competitions SET status='ended', ended_at=NOW() WHERE id=?");
    $s->bind_param("i", $comp_id);
    $s->execute(); $s->close();
    set_flash('success', 'Competition ended. View the final leaderboard below.');
    header("Location: manage_competition.php?id=$comp_id"); exit();
}

// Re-fetch after possible status change
$s = $conn->prepare("
    SELECT c.*, qz.title AS quiz_title, qz.subject, qz.`class`, qz.duration,
           (SELECT COUNT(*) FROM questions WHERE quiz_id = qz.id) AS total_questions
    FROM competitions c JOIN quizzes qz ON c.quiz_id = qz.id
    WHERE c.id = ?
");
$s->bind_param("i", $comp_id);
$s->execute();
$comp = $s->get_result()->fetch_assoc();
$s->close();

// Participants + scores
$participants = [];
$s = $conn->prepare("
    SELECT cp.id, cp.guest_name, cp.score, cp.total_marks, cp.joined_at, cp.finished_at,
           u.name AS user_name, u.email,
           (SELECT COUNT(*) FROM competition_answers WHERE participant_id = cp.id) AS answers_given
    FROM competition_participants cp
    LEFT JOIN users u ON cp.user_id = u.id
    WHERE cp.competition_id = ?
    ORDER BY cp.score DESC, cp.finished_at ASC
");
$s->bind_param("i", $comp_id);
$s->execute();
$result = $s->get_result();
while ($row = $result->fetch_assoc()) $participants[] = $row;
$s->close();

$join_link = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . "://$_SERVER[HTTP_HOST]" . dirname(dirname($_SERVER['PHP_SELF'])) . "/join.php?code=" . $comp['join_code'];

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Manage Competition</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <?php if ($comp['status'] === 'live'): ?>
    <meta http-equiv="refresh" content="10"> <!-- Auto-refresh every 10s when live -->
    <?php endif; ?>
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--ink2:#2e2e4a;--cream:#f5f0e8;--paper:#faf7f2;--gold:#c9a84c;--gold2:#e8c96a;--muted:#7a7a8a;--red:#c0392b;--green:#1e7e4a;--border:rgba(26,26,46,0.12)}
        body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--ink);min-height:100vh}
        .topbar{background:var(--ink);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
        .brand{display:flex;align-items:center;gap:10px}
        .brand-icon{width:32px;height:32px;background:var(--gold);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px}
        .brand-name{font-family:'Playfair Display',serif;font-size:18px;color:var(--cream)}
        .topbar a{color:rgba(245,240,232,0.7);text-decoration:none;font-size:13.5px}
        .topbar a:hover{color:var(--gold2)}
        .container{max-width:860px;margin:0 auto;padding:36px 24px 80px}
        .alert{border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13.5px;display:flex;align-items:center;gap:8px}
        .alert-success{background:#edfbf3;border:1px solid rgba(30,126,74,.25);border-left:3px solid var(--green);color:var(--green)}
        .alert-error{background:#fdf0ef;border:1px solid rgba(192,57,43,.25);border-left:3px solid var(--red);color:var(--red)}
        /* Hero */
        .hero{background:var(--ink);border-radius:16px;padding:28px 32px;margin-bottom:24px;position:relative;overflow:hidden}
        .hero::before{content:'';position:absolute;width:300px;height:300px;border-radius:50%;border:1px solid rgba(201,168,76,.15);top:-100px;right:-80px}
        .status-badge{display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:20px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px}
        .status-badge.waiting{background:rgba(201,168,76,.2);color:var(--gold2)}
        .status-badge.live{background:rgba(34,197,94,.2);color:#4ade80;animation:pulse 1.5s infinite}
        .status-badge.ended{background:rgba(255,255,255,.1);color:rgba(245,240,232,.6)}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
        .hero h1{font-family:'Playfair Display',serif;font-size:26px;color:var(--cream);margin-bottom:6px}
        .hero-meta{font-size:13px;color:rgba(245,240,232,.55)}
        .hero-bottom{display:flex;align-items:flex-end;justify-content:space-between;margin-top:22px;flex-wrap:wrap;gap:16px}
        .code-block{background:rgba(255,255,255,.07);border:1px solid rgba(201,168,76,.3);border-radius:12px;padding:14px 20px}
        .code-label{font-size:10px;text-transform:uppercase;letter-spacing:.1em;color:rgba(245,240,232,.4);margin-bottom:4px}
        .code-value{font-family:'Playfair Display',serif;font-size:36px;color:var(--gold2);letter-spacing:.2em}
        .link-box{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px;max-width:400px}
        .link-url{font-size:12px;color:rgba(245,240,232,.5);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .copy-btn{background:var(--gold);color:var(--ink);border:none;padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;flex-shrink:0}
        .hero-actions{display:flex;gap:10px}
        .btn{padding:10px 20px;border-radius:8px;font-size:13.5px;font-weight:500;cursor:pointer;border:none;text-decoration:none;display:inline-flex;align-items:center;gap:6px;transition:all .15s}
        .btn-start{background:#22c55e;color:#fff}.btn-start:hover{background:#16a34a}
        .btn-end{background:var(--red);color:#fff}.btn-end:hover{opacity:.85}
        .btn-outline{background:transparent;border:1px solid rgba(255,255,255,.2);color:var(--cream)}.btn-outline:hover{background:rgba(255,255,255,.08)}
        /* Stats row */
        .stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px}
        .stat-card{background:var(--paper);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center}
        .stat-num{font-family:'Playfair Display',serif;font-size:28px;color:var(--ink)}
        .stat-label{font-size:11.5px;color:var(--muted);margin-top:2px}
        /* Leaderboard */
        .section-card{background:var(--paper);border:1px solid var(--border);border-radius:14px;overflow:hidden}
        .section-header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
        .section-header h2{font-family:'Playfair Display',serif;font-size:16px}
        table{width:100%;border-collapse:collapse}
        thead th{background:var(--ink);color:var(--cream);font-size:11px;text-transform:uppercase;letter-spacing:.06em;text-align:left;padding:12px 16px;font-weight:500}
        tbody tr{border-bottom:1px solid var(--border);transition:background .15s}
        tbody tr:last-child{border-bottom:none}
        tbody tr:hover{background:rgba(201,168,76,.03)}
        tbody td{padding:13px 16px;font-size:13.5px}
        .rank-1{color:var(--gold);font-weight:700}
        .rank-2{color:#94a3b8}
        .rank-3{color:#b45309}
        .badge-done{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:rgba(30,126,74,.1);color:var(--green)}
        .badge-playing{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:rgba(37,99,235,.1);color:#2563eb;animation:pulse 1.5s infinite}
        .empty-state{padding:40px;text-align:center;color:var(--muted);font-size:13.5px}
        @media(max-width:700px){.stats-row{grid-template-columns:1fr 1fr}.hero-bottom{flex-direction:column}}
    </style>
</head>
<body>
<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech</span>
    </div>
    <a href="dashboard.php">← Dashboard</a>
</div>

<div class="container">
    <?php if ($flash): ?>
    <div class="alert alert-<?php echo $flash['type'] === 'success' ? 'success' : 'error'; ?>">
        <?php echo $flash['type'] === 'success' ? '✓' : '⚠️'; ?> <?php echo htmlspecialchars($flash['message']); ?>
    </div>
    <?php endif; ?>

    <!-- Hero -->
    <div class="hero">
        <div class="status-badge <?php echo $comp['status']; ?>">
            <?php echo $comp['status'] === 'live' ? '● Live' : ($comp['status'] === 'waiting' ? '⏳ Waiting' : '✓ Ended'); ?>
        </div>
        <h1><?php echo htmlspecialchars($comp['quiz_title']); ?></h1>
        <div class="hero-meta"><?php echo htmlspecialchars($comp['subject']); ?> · Class <?php echo htmlspecialchars($comp['class']); ?> · <?php echo $comp['total_questions']; ?> questions · <?php echo $comp['duration']; ?> mins</div>

        <div class="hero-bottom">
            <div>
                <div class="code-block">
                    <div class="code-label">Join Code</div>
                    <div class="code-value"><?php echo htmlspecialchars($comp['join_code']); ?></div>
                </div>
                <div class="link-box" style="margin-top:10px">
                    <div class="link-url" id="joinLink"><?php echo htmlspecialchars($join_link); ?></div>
                    <button class="copy-btn" onclick="copyLink()">Copy</button>
                </div>
            </div>
            <div class="hero-actions">
                <?php if ($comp['status'] === 'waiting'): ?>
                <a href="manage_competition.php?id=<?php echo $comp_id; ?>&action=start" class="btn btn-start"
                   onclick="return confirm('Start the competition now?')">▶ Start</a>
                <?php elseif ($comp['status'] === 'live'): ?>
                <a href="manage_competition.php?id=<?php echo $comp_id; ?>&action=end" class="btn btn-end"
                   onclick="return confirm('End this competition?')">■ End Competition</a>
                <a href="leaderboard.php?id=<?php echo $comp_id; ?>" class="btn btn-outline">🏆 Leaderboard</a>
                <?php else: ?>
                <a href="leaderboard.php?id=<?php echo $comp_id; ?>" class="btn btn-outline" style="border-color:var(--gold);color:var(--gold2)">🏆 Final Leaderboard</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-num"><?php echo count($participants); ?></div>
            <div class="stat-label">Joined</div>
        </div>
        <div class="stat-card">
            <div class="stat-num"><?php echo count(array_filter($participants, fn($p) => $p['finished_at'])); ?></div>
            <div class="stat-label">Finished</div>
        </div>
        <div class="stat-card">
            <div class="stat-num">
                <?php
                $scores = array_column($participants, 'score');
                echo count($scores) ? round(array_sum($scores)/count($scores), 1) : 0;
                ?>
            </div>
            <div class="stat-label">Avg Score</div>
        </div>
        <div class="stat-card">
            <div class="stat-num"><?php echo $comp['total_questions']; ?></div>
            <div class="stat-label">Questions</div>
        </div>
    </div>

    <!-- Participants table -->
    <div class="section-card">
        <div class="section-header">
            <h2>Participants <?php if ($comp['status'] === 'live'): ?><span style="font-size:11px;color:#22c55e;font-family:'DM Sans',sans-serif;font-weight:400;margin-left:8px">● Auto-refreshing</span><?php endif; ?></h2>
        </div>
        <?php if (empty($participants)): ?>
        <div class="empty-state">
            No participants yet — share the code <strong><?php echo htmlspecialchars($comp['join_code']); ?></strong> or the link above.
        </div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Score</th>
                    <th>Progress</th>
                    <th>Status</th>
                    <th>Joined</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($participants as $i => $p): ?>
                <tr>
                    <td class="rank-<?php echo $i+1 <= 3 ? $i+1 : ''; ?>"><?php echo $i === 0 ? '🥇' : ($i === 1 ? '🥈' : ($i === 2 ? '🥉' : $i+1)); ?></td>
                    <td><?php echo htmlspecialchars($p['user_name'] ?? $p['guest_name'] ?? 'Guest'); ?></td>
                    <td><strong><?php echo $p['score']; ?></strong><?php echo $p['total_marks'] ? '/'.$p['total_marks'] : ''; ?></td>
                    <td><?php echo $p['answers_given']; ?>/<?php echo $comp['total_questions']; ?></td>
                    <td><?php echo $p['finished_at'] ? '<span class="badge-done">Done</span>' : '<span class="badge-playing">Playing...</span>'; ?></td>
                    <td><?php echo date('H:i', strtotime($p['joined_at'])); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<script>
function copyLink() {
    const link = document.getElementById('joinLink').textContent;
    navigator.clipboard.writeText(link).then(() => {
        const btn = document.querySelector('.copy-btn');
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = 'Copy', 2000);
    });
}
</script>
</body>
</html>