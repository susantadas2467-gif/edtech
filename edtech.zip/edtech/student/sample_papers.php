
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

require_student();

$class = get_user_class();

if (!in_array($class, ['9', '10', 'Class 9', 'Class 10'], true)) {
    exit('Your class is not configured correctly. Please contact the administrator.');
}

$normalClass = in_array($class, ['9', 'Class 9'], true) ? '9' : '10';

$stmt = $conn->prepare(
    "SELECT id, title, subject, class, uploaded_at
     FROM materials
     WHERE material_type = 'sample_paper'
       AND class = ?
     ORDER BY uploaded_at DESC"
);

$stmt->bind_param('s', $normalClass);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sample Papers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f3ee;
            color: #17233d;
            margin: 0;
            padding: 24px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        .topbar, .paper {
            background: white;
            padding: 18px;
            border-radius: 12px;
            margin-bottom: 14px;
            box-shadow: 0 3px 12px #0000000a;
        }
        .paper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }
        h1 { margin-top: 0; }
        .muted { color: #687386; }
        .download {
            display: inline-block;
            background: #17233d;
            color: white;
            padding: 10px 14px;
            border-radius: 8px;
            text-decoration: none;
        }
        .back {
            color: #17233d;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="topbar">
        <a class="back" href="dashboard.php">← Student Dashboard</a>
        <h1>📄 Sample Papers</h1>
        <p class="muted">Showing sample papers for your class only.</p>
    </div>

    <?php if ($result->num_rows === 0): ?>
        <div class="paper">
            No sample papers are available for your class yet.
        </div>
    <?php else: ?>
        <?php while ($paper = $result->fetch_assoc()): ?>
            <div class="paper">
                <div>
                    <strong>
                        <?= htmlspecialchars($paper['title']) ?>
                    </strong>
                    <p class="muted">
                        Subject: <?= htmlspecialchars($paper['subject']) ?>
                        · Class <?= htmlspecialchars($paper['class']) ?>
                    </p>
                    <small class="muted">
                        Uploaded:
                        <?= htmlspecialchars($paper['uploaded_at']) ?>
                    </small>
                </div>

                       
<div style="display:flex; gap:10px; flex-wrap:wrap;">
    <a class="download"
       href="view_sample_paper.php?id=<?= (int)$paper['id'] ?>"
       target="_blank"
       rel="noopener">
        👁 View
    </a>

    <a class="download"
       href="download_sample_paper.php?id=<?= (int)$paper['id'] ?>">
        📥 Download
    </a>
</div>

            
            
        <?php endwhile; ?>
    <?php endif; ?>

    <?php $stmt->close(); ?>
</div>
</body>
</html>
