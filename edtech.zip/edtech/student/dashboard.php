<?php
session_start();

// Auth guard — students only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit();
}

require_once '../includes/db.php';
require_once '../includes/session.php';

$student_id    = $_SESSION['user_id'];
$student_name  = htmlspecialchars($_SESSION['name']);
$student_class = $_SESSION['class'];

// ── Stats for this student ─────────────────────────────────

// Total quizzes available for their class
$r = $conn->prepare("SELECT COUNT(*) AS c FROM quizzes WHERE class = ?");
$r->bind_param("s", $student_class);
$r->execute();
$total_quizzes = $r->get_result()->fetch_assoc()['c'];

// Quizzes this student has attempted
$r = $conn->prepare("SELECT COUNT(*) AS c FROM results WHERE user_id = ?");
$r->bind_param("i", $student_id);
$r->execute();
$attempted = $r->get_result()->fetch_assoc()['c'];

// Average score
$r = $conn->prepare("SELECT ROUND(AVG(score), 1) AS avg FROM results WHERE user_id = ?");
$r->bind_param("i", $student_id);
$r->execute();
$avg_score = $r->get_result()->fetch_assoc()['avg'] ?? 0;

// Best score
$r = $conn->prepare("SELECT MAX(score) AS best FROM results WHERE user_id = ?");
$r->bind_param("i", $student_id);
$r->execute();
$best_score = $r->get_result()->fetch_assoc()['best'] ?? 0;

// Total materials available for their class
$r = $conn->prepare("SELECT COUNT(*) AS c FROM materials WHERE class = ?");
$r->bind_param("s", $student_class);
$r->execute();
$total_materials = $r->get_result()->fetch_assoc()['c'];

// Recent quiz results (last 5)
$recent_results = [];
$r = $conn->prepare("
    SELECT res.score, res.taken_at, q.title, q.subject, q.duration
    FROM results res
    JOIN quizzes q ON res.quiz_id = q.id
    WHERE res.user_id = ?
    ORDER BY res.taken_at DESC
    LIMIT 5
");
$r->bind_param("i", $student_id);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $recent_results[] = $row;

// Available quizzes not yet attempted
$pending_quizzes = [];
$r = $conn->prepare("
    SELECT q.id, q.title, q.subject, q.duration
    FROM quizzes q
    WHERE q.class = ?
      AND q.id NOT IN (
          SELECT quiz_id FROM results WHERE user_id = ?
      )
    ORDER BY q.created_at DESC
    LIMIT 5
");
$r->bind_param("si", $student_class, $student_id);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $pending_quizzes[] = $row;

// Materials by subject
$materials_by_subject = [];
$r = $conn->prepare("SELECT subject, COUNT(*) AS cnt FROM materials WHERE class = ? GROUP BY subject");
$r->bind_param("s", $student_class);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $materials_by_subject[$row['subject']] = $row['cnt'];

// Score trend (last 6 results for mini chart)
$score_trend = [];
$r = $conn->prepare("
    SELECT res.score, q.subject
    FROM results res
    JOIN quizzes q ON res.quiz_id = q.id
    WHERE res.user_id = ?
    ORDER BY res.taken_at ASC
    LIMIT 6
");
$r->bind_param("i", $student_id);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $score_trend[] = $row;

// Rank in class
$r = $conn->prepare("
    SELECT COUNT(*) + 1 AS rank_posds
    FROM (
        SELECT user_id, AVG(score) AS avg_s
        FROM results
        JOIN users ON results.user_id = users.id
        WHERE users.class = ?
        GROUP BY user_id
    ) AS t
    WHERE t.avg_s > (
        SELECT COALESCE(AVG(score), 0) FROM results WHERE user_id = ?
    )
");
$r->bind_param("si", $student_class, $student_id);
$r->execute();
$rank = $r->get_result()->fetch_assoc()['rank_pos'] ?? '—';

$conn->close();

$pending_count  = count($pending_quizzes);
$quizzes_left   = $total_quizzes - $attempted;
$progress_pct   = $total_quizzes > 0 ? round(($attempted / $total_quizzes) * 100) : 0;
$greeting_hour  = (int)date('H');
$greeting       = $greeting_hour < 12 ? 'Good morning' : ($greeting_hour < 17 ? 'Good afternoon' : 'Good evening');
$first_name     = explode(' ', $_SESSION['name'])[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard — EduPortal</title>
    <link rel="stylesheet" href="../assets/ed.css">
    <style>
        /* ── Page-specific styles ── */

        /* Welcome banner */
        .welcome-banner {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 28px 32px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            position: relative;
            overflow: hidden;
            animation: fadeUp 0.4s ease both;
        }

        .welcome-banner::before {
            content: '';
            position: absolute;
            top: -40px; right: -40px;
            width: 200px; height: 200px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(79,142,247,0.12), transparent 70%);
            pointer-events: none;
        }

        .welcome-banner::after {
            content: '';
            position: absolute;
            bottom: -60px; left: 30%;
            width: 160px; height: 160px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(167,139,250,0.08), transparent 70%);
            pointer-events: none;
        }

        .welcome-left { z-index: 1; }

        .welcome-greeting {
            font-size: 13px;
            color: var(--muted2);
            font-weight: 500;
            margin-bottom: 4px;
        }

        .welcome-name {
            font-family: var(--font-display);
            font-size: clamp(22px, 3vw, 30px);
            font-weight: 800;
            color: var(--text);
            margin-bottom: 10px;
            line-height: 1.2;
        }

        .welcome-name span { color: var(--accent2); }

        .welcome-meta {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        .welcome-tag {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12.5px;
            color: var(--muted2);
            font-weight: 500;
        }

        .welcome-tag .dot {
            width: 6px; height: 6px;
            border-radius: 50%;
            background: var(--green);
            box-shadow: 0 0 6px var(--green);
        }

        .welcome-right {
            z-index: 1;
            text-align: right;
            flex-shrink: 0;
        }

        .class-badge-lg {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            background: rgba(79,142,247,0.1);
            border: 1px solid rgba(79,142,247,0.2);
            border-radius: var(--radius-lg);
            padding: 14px 24px;
        }

        .class-badge-lg .class-num {
            font-family: var(--font-display);
            font-size: 32px;
            font-weight: 800;
            color: var(--accent2);
            line-height: 1;
        }

        .class-badge-lg .class-label {
            font-size: 11px;
            color: var(--muted);
            font-weight: 600;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-top: 4px;
        }

        /* Stats row */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin-bottom: 24px;
        }

        /* Progress card */
        .progress-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px 22px;
            animation: fadeUp 0.4s ease both;
            animation-delay: 0.25s;
            margin-bottom: 24px;
        }

        .progress-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 14px;
        }

        .progress-title {
            font-family: var(--font-display);
            font-size: 13px;
            font-weight: 700;
            color: var(--text);
        }

        .progress-pct {
            font-family: var(--font-display);
            font-size: 20px;
            font-weight: 800;
            color: var(--accent2);
        }

        .progress-bar-bg {
            height: 8px;
            background: var(--surface2);
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 10px;
        }

        .progress-bar-fill {
            height: 100%;
            border-radius: 6px;
            background: linear-gradient(90deg, var(--accent), var(--accent2));
            transition: width 1.2s cubic-bezier(.25,.8,.25,1);
        }

        .progress-sub {
            font-size: 12px;
            color: var(--muted);
        }

        /* Two col layout */
        .two-col { display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 20px; margin-bottom: 20px; }
        .three-col { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin-bottom: 24px; }

        /* Subject cards */
        .subject-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            transition: border-color 0.2s, transform 0.2s;
            animation: fadeUp 0.4s ease both;
            cursor: pointer;
            text-decoration: none;
        }

        .subject-card:hover {
            border-color: var(--border2);
            transform: translateY(-3px);
        }

        .subject-card.math:hover    { border-color: var(--accent); }
        .subject-card.science:hover { border-color: var(--green); }
        .subject-card.english:hover { border-color: var(--amber); }

        .subject-icon {
            width: 44px; height: 44px;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
        }

        .subject-card.math    .subject-icon { background: var(--math-bg); }
        .subject-card.science .subject-icon { background: var(--science-bg); }
        .subject-card.english .subject-icon { background: var(--english-bg); }

        .subject-name {
            font-family: var(--font-display);
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
        }

        .subject-count {
            font-size: 12px;
            color: var(--muted2);
        }

        .subject-arrow {
            margin-top: auto;
            font-size: 18px;
            color: var(--muted);
            transition: color 0.15s, transform 0.15s;
        }

        .subject-card:hover .subject-arrow { color: var(--accent2); transform: translateX(4px); }

        /* Quiz items */
        .quiz-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 0;
            border-bottom: 1px solid var(--border);
        }

        .quiz-item:last-child { border-bottom: none; }

        .quiz-item-icon {
            width: 36px; height: 36px;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .quiz-item-icon.math    { background: var(--math-bg); }
        .quiz-item-icon.science { background: var(--science-bg); }
        .quiz-item-icon.english { background: var(--english-bg); }
        .quiz-item-icon.general { background: var(--general-bg); }

        .quiz-item-info { flex: 1; min-width: 0; }

        .quiz-item-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--text);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 3px;
        }

        .quiz-item-meta {
            font-size: 11.5px;
            color: var(--muted);
        }

        /* Mini score chart */
        .mini-chart {
            display: flex;
            align-items: flex-end;
            gap: 6px;
            height: 60px;
            padding: 8px 0 0;
        }

        .mini-bar-wrap {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            height: 100%;
            justify-content: flex-end;
        }

        .mini-bar {
            width: 100%;
            border-radius: 4px 4px 0 0;
            min-height: 4px;
            transition: height 0.8s cubic-bezier(.25,.8,.25,1);
        }

        .mini-bar-label {
            font-size: 9px;
            color: var(--muted);
            text-align: center;
            white-space: nowrap;
        }

        /* Result row */
        .result-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
        }

        .result-row:last-child { border-bottom: none; }

        .result-info { flex: 1; min-width: 0; }

        .result-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--text);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 3px;
        }

        .result-meta { font-size: 11.5px; color: var(--muted); }

        /* Rank card */
        .rank-card {
            background: linear-gradient(135deg, rgba(79,142,247,0.1), rgba(167,139,250,0.08));
            border: 1px solid rgba(79,142,247,0.2);
            border-radius: var(--radius-lg);
            padding: 20px 22px;
            display: flex;
            align-items: center;
            gap: 16px;
            animation: fadeUp 0.4s ease both;
            animation-delay: 0.3s;
            margin-bottom: 20px;
        }

        .rank-icon {
            font-size: 36px;
            flex-shrink: 0;
        }

        .rank-info { flex: 1; }

        .rank-num {
            font-family: var(--font-display);
            font-size: 28px;
            font-weight: 800;
            color: var(--accent2);
            line-height: 1;
        }

        .rank-label { font-size: 12px; color: var(--muted2); margin-top: 3px; }

        /* Animations */
        .anim-delay-1 { animation-delay: 0.05s; }
        .anim-delay-2 { animation-delay: 0.10s; }
        .anim-delay-3 { animation-delay: 0.15s; }
        .anim-delay-4 { animation-delay: 0.20s; }

        /* Responsive */
        @media (max-width: 1100px) {
            .stats-grid  { grid-template-columns: repeat(2, 1fr); }
            .two-col     { grid-template-columns: 1fr; }
            .three-col   { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 860px) {
            .welcome-banner { flex-direction: column; align-items: flex-start; }
            .welcome-right  { align-self: flex-start; }
        }
        @media (max-width: 600px) {
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .three-col  { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="layout">

    <!-- ══════════ SIDEBAR ══════════ -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-logo">
            <div class="logo-mark">📚</div>
            <span class="logo-text">Edu<span>Portal</span></span>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Menu</div>

            <a href="dashboard.php" class="nav-item active">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                    <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
                </svg>
                Dashboard
            </a>

            <a href="materials.php" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                </svg>
                Study Materials
                <?php if($total_materials > 0): ?>
                <span class="nav-badge"><?php echo $total_materials; ?></span>
                <?php endif; ?>
            </a>

            <a href="quiz.php" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                Quizzes
                <?php if($pending_count > 0): ?>
                <span class="nav-badge"><?php echo $pending_count; ?></span>
                <?php endif; ?>
            </a>

            <a href="result.php" class="nav-item">
                <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
                </svg>
                My Results
            </a>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Subjects</div>
            <a href="materials.php?subject=math" class="nav-item">
                <span style="font-size:15px;">📐</span> Math
            </a>
            <a href="materials.php?subject=science" class="nav-item">
                <span style="font-size:15px;">🔬</span> Science
            </a>
            <a href="materials.php?subject=english" class="nav-item">
                <span style="font-size:15px;">📖</span> English
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?></div>
                <div class="user-info">
                    <div class="u-name"><?php echo $student_name; ?></div>
                    <div class="u-role student">Class <?php echo $student_class; ?> Student</div>
                </div>
                <a href="../logout.php" class="icon-btn" title="Logout">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                        <polyline points="16 17 21 12 16 7"/>
                        <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                </a>
            </div>
        </div>
    </aside>

    <!-- Overlay for mobile -->
    <div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>

    <!-- ══════════ MAIN ══════════ -->
    <div class="main">

        <!-- Topbar -->
        <div class="topbar">
            <button class="hamburger" id="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu">
                <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <line x1="3" y1="6"  x2="21" y2="6"/>
                    <line x1="3" y1="12" x2="21" y2="12"/>
                    <line x1="3" y1="18" x2="21" y2="18"/>
                </svg>
            </button>
            <div class="topbar-title">My Dashboard</div>
            <div style="display:flex;align-items:center;gap:10px;">
                <?php if($pending_count > 0): ?>
                <a href="quiz.php" class="btn btn-primary btn-sm">
                    <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12 6 12 12 16 14"/>
                    </svg>
                    <?php echo $pending_count; ?> Quiz<?php echo $pending_count > 1 ? 'zes' : ''; ?> Pending
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Content -->
        <div class="content">

            <!-- Welcome Banner -->
            <div class="welcome-banner">
                <div class="welcome-left">
                    <div class="welcome-greeting"><?php echo $greeting; ?> 👋</div>
                    <div class="welcome-name">Welcome back, <span><?php echo htmlspecialchars($first_name); ?></span></div>
                    <div class="welcome-meta">
                        <div class="welcome-tag">
                            <span class="dot"></span>
                            Active Student
                        </div>
                        <div class="welcome-tag" style="color:var(--muted);">·</div>
                        <div class="welcome-tag">
                            <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="color:var(--amber)">
                                <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                            </svg>
                            <?php echo $quizzes_left; ?> quiz<?php echo $quizzes_left != 1 ? 'zes' : ''; ?> remaining
                        </div>
                        <div class="welcome-tag" style="color:var(--muted);">·</div>
                        <div class="welcome-tag">
                            <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="color:var(--accent2)">
                                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
                                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
                            </svg>
                            <?php echo $total_materials; ?> materials
                        </div>
                    </div>
                </div>
                <div class="welcome-right">
                    <div class="class-badge-lg">
                        <span class="class-num"><?php echo $student_class; ?></span>
                        <span class="class-label">Class</span>
                    </div>
                </div>
            </div>

            <!-- Stat Cards -->
            <div class="stats-grid">
                <div class="stat-card c-blue anim-fade-up anim-delay-1">
                    <div class="stat-icon">📝</div>
                    <div class="stat-value"><?php echo $attempted; ?><span style="font-size:14px;color:var(--muted2);font-weight:400;">/<?php echo $total_quizzes; ?></span></div>
                    <div class="stat-label">Quizzes Attempted</div>
                </div>
                <div class="stat-card c-green anim-fade-up anim-delay-2">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value"><?php echo $avg_score; ?>%</div>
                    <div class="stat-label">Average Score</div>
                </div>
                <div class="stat-card c-amber anim-fade-up anim-delay-3">
                    <div class="stat-icon">🏆</div>
                    <div class="stat-value"><?php echo $best_score; ?>%</div>
                    <div class="stat-label">Best Score</div>
                </div>
                <div class="stat-card c-violet anim-fade-up anim-delay-4">
                    <div class="stat-icon">🥇</div>
                    <div class="stat-value">#<?php echo $rank; ?></div>
                    <div class="stat-label">Class Rank</div>
                </div>
            </div>

            <!-- Quiz Progress Bar -->
            <div class="progress-card">
                <div class="progress-head">
                    <div class="progress-title">Overall Quiz Progress</div>
                    <div class="progress-pct" id="pct-display">0%</div>
                </div>
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" id="main-progress" style="width:0%"></div>
                </div>
                <div class="progress-sub"><?php echo $attempted; ?> of <?php echo $total_quizzes; ?> quizzes completed for Class <?php echo $student_class; ?></div>
            </div>

            <!-- Class rank card -->
            <?php if($attempted > 0): ?>
            <div class="rank-card">
                <div class="rank-icon">🏅</div>
                <div class="rank-info">
                    <div class="rank-num">#<?php echo $rank; ?> in Class <?php echo $student_class; ?></div>
                    <div class="rank-label">Based on your average score of <?php echo $avg_score; ?>% across <?php echo $attempted; ?> quiz<?php echo $attempted != 1 ? 'zes' : ''; ?></div>
                </div>
                <a href="result.php" class="btn btn-ghost btn-sm">View all results →</a>
            </div>
            <?php endif; ?>

            <!-- Subject Cards -->
            <div class="three-col">
                <?php
                $subjects = [
                    'math'    => ['icon' => '📐', 'label' => 'Mathematics'],
                    'science' => ['icon' => '🔬', 'label' => 'Science'],
                    'english' => ['icon' => '📖', 'label' => 'English'],
                ];
                $delay = 1;
                foreach ($subjects as $key => $sub):
                    $cnt = $materials_by_subject[$key] ?? 0;
                ?>
                <a href="materials.php?subject=<?php echo $key; ?>" class="subject-card <?php echo $key; ?> anim-fade-up anim-delay-<?php echo $delay++; ?>">
                    <div class="subject-icon"><?php echo $sub['icon']; ?></div>
                    <div>
                        <div class="subject-name"><?php echo $sub['label']; ?></div>
                        <div class="subject-count"><?php echo $cnt; ?> material<?php echo $cnt != 1 ? 's' : ''; ?> available</div>
                    </div>
                    <div class="subject-arrow">→</div>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Two col: Pending Quizzes + Recent Results -->
            <div class="two-col">

                <!-- Pending Quizzes -->
                <div class="panel anim-fade-up">
                    <div class="panel-head">
                        <div class="panel-title">
                            <span class="dot" style="background:var(--amber)"></span>
                            Pending Quizzes
                        </div>
                        <a href="quiz.php" class="panel-link">All quizzes →</a>
                    </div>
                    <div class="panel-body" style="padding-top:8px;padding-bottom:8px;">
                        <?php if (empty($pending_quizzes)): ?>
                        <div class="empty-state" style="padding:32px 0;">
                            <div class="empty-icon">🎉</div>
                            <div class="empty-title">All caught up!</div>
                            <div class="empty-sub">You've attempted all available quizzes. Check back later.</div>
                        </div>
                        <?php else: ?>
                        <?php
                        $sub_icons = ['math'=>'📐','science'=>'🔬','english'=>'📖','general'=>'📋'];
                        foreach ($pending_quizzes as $qz):
                            $ico = $sub_icons[$qz['subject']] ?? '📋';
                        ?>
                        <div class="quiz-item">
                            <div class="quiz-item-icon <?php echo htmlspecialchars($qz['subject']); ?>"><?php echo $ico; ?></div>
                            <div class="quiz-item-info">
                                <div class="quiz-item-title"><?php echo htmlspecialchars($qz['title']); ?></div>
                                <div class="quiz-item-meta">
                                    <span class="chip chip-<?php echo htmlspecialchars($qz['subject']); ?>"><?php echo ucfirst(htmlspecialchars($qz['subject'])); ?></span>
                                    &nbsp;·&nbsp; ⏱ <?php echo $qz['duration']; ?> min
                                </div>
                            </div>
                            <a href="quiz.php?id=<?php echo $qz['id']; ?>" class="btn btn-primary btn-sm">Start</a>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Results + Mini Chart -->
                <div style="display:flex;flex-direction:column;gap:16px;">

                    <!-- Mini bar chart -->
                    <?php if (!empty($score_trend)): ?>
                    <div class="panel anim-fade-up" style="animation-delay:.1s;">
                        <div class="panel-head">
                            <div class="panel-title">
                                <span class="dot" style="background:var(--accent)"></span>
                                Score Trend
                            </div>
                            <span style="font-size:11px;color:var(--muted);">Last <?php echo count($score_trend); ?> quizzes</span>
                        </div>
                        <div class="panel-body">
                            <div class="mini-chart" id="mini-chart">
                                <?php foreach ($score_trend as $i => $s):
                                    $bar_color = $s['score'] >= 75 ? 'var(--green)' : ($s['score'] >= 50 ? 'var(--amber)' : 'var(--red)');
                                ?>
                                <div class="mini-bar-wrap">
                                    <div class="mini-bar" id="mbar-<?php echo $i; ?>"
                                         style="background:<?php echo $bar_color; ?>;height:0%;width:100%;"
                                         data-pct="<?php echo $s['score']; ?>"
                                         title="<?php echo $s['score']; ?>%">
                                    </div>
                                    <div class="mini-bar-label"><?php echo $s['score']; ?>%</div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Recent results list -->
                    <div class="panel anim-fade-up" style="animation-delay:.15s;">
                        <div class="panel-head">
                            <div class="panel-title">
                                <span class="dot" style="background:var(--green)"></span>
                                Recent Results
                            </div>
                            <a href="result.php" class="panel-link">All →</a>
                        </div>
                        <div class="panel-body" style="padding-top:6px;padding-bottom:6px;">
                            <?php if (empty($recent_results)): ?>
                            <div class="empty-state" style="padding:24px 0;">
                                <div class="empty-icon">📝</div>
                                <div class="empty-title">No results yet</div>
                                <div class="empty-sub">Take a quiz to see your results here.</div>
                            </div>
                            <?php else: ?>
                            <?php foreach ($recent_results as $res):
                                $score = (int)$res['score'];
                                $pill  = $score >= 75 ? 'high' : ($score >= 50 ? 'mid' : 'low');
                                $date  = date('d M', strtotime($res['taken_at']));
                            ?>
                            <div class="result-row">
                                <div class="result-info">
                                    <div class="result-title"><?php echo htmlspecialchars($res['title']); ?></div>
                                    <div class="result-meta"><?php echo $date; ?> &nbsp;·&nbsp; <?php echo $res['duration']; ?> min</div>
                                </div>
                                <span class="score-pill <?php echo $pill; ?>"><?php echo $score; ?>%</span>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>

        </div><!-- /content -->
    </div><!-- /main -->
</div><!-- /layout -->

<script>
// ── Progress bar animate ──────────────────────────────────
window.addEventListener('load', () => {
    const pct = <?php echo $progress_pct; ?>;
    setTimeout(() => {
        document.getElementById('main-progress').style.width = pct + '%';
        document.getElementById('pct-display').textContent  = pct + '%';
    }, 300);

    // Mini chart bars
    document.querySelectorAll('.mini-bar').forEach((bar, i) => {
        const p = parseFloat(bar.dataset.pct) || 0;
        setTimeout(() => {
            bar.style.height = Math.max(p, 4) + '%';
        }, 400 + i * 80);
    });
});

// ── Sidebar toggle (mobile) ───────────────────────────────
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('active');
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebar-overlay').classList.remove('active');
}
</script>

</body>
</html>