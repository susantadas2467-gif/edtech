
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

// If your database connection is named differently, use the same
// connection variable as in student/materials.php.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$class = (string)($_SESSION['class'] ?? '');
if (!in_array($class, ['9', '10'], true)) {
    exit('Your class is not set correctly. Please contact the administrator.');
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// Find out whether the optional quiz_file column exists.
$hasFileColumn = false;
$columnCheck = $conn->query("SHOW COLUMNS FROM quizzes LIKE 'quiz_file'");
if ($columnCheck && $columnCheck->num_rows > 0) {
    $hasFileColumn = true;
}

$sql = "SELECT id, title, subject, `class`";
if ($hasFileColumn) {
    $sql .= ", quiz_file";
}
$sql .= " FROM quizzes WHERE `class` = ? ORDER BY id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $class);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Quizzes</title>
<style>
* { box-sizing: border-box; }
body {
    margin: 0; padding: 24px;
    font-family: Arial, sans-serif;
    background: #f4f6fb; color: #202840;
}
.container { max-width: 1000px; margin: auto; }
header { margin-bottom: 24px; }
header a { color: #4169e1; text-decoration: none; }
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 18px;
}
.card {
    background: white; padding: 22px;
    border-radius: 14px; border: 1px solid #e2e7f0;
    box-shadow: 0 4px 14px #1725540a;
}
.card h2 { margin-top: 0; font-size: 20px; }
.meta { color: #68738a; font-size: 14px; margin: 8px 0; }
.actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 18px; }
.btn {
    display: inline-block; padding: 10px 14px;
    border-radius: 8px; text-decoration: none;
    background: #4169e1; color: white;
}
.btn.secondary { background: #e9eefc; color: #2548a5; }
.empty {
    background: white; padding: 24px;
    border-radius: 12px; color: #68738a;
}
</style>
</head>
<body>
<div class="container">
<header>
    <a href="dashboard.php">← Student Dashboard</a>
    <h1>My Quizzes</h1>
    <p>Quizzes available for Class <?= h($class) ?></p>
</header>

<?php if ($result->num_rows === 0): ?>
    <div class="empty">No quizzes are available for your class yet.</div>
<?php else: ?>
<div class="grid">
<?php while ($quiz = $result->fetch_assoc()): ?>
    <article class="card">
        <h2><?= h($quiz['title']) ?></h2>
        <div class="meta">Subject: <?= h($quiz['subject']) ?></div>
        <div class="meta">Class: <?= h($quiz['class']) ?></div>

        <div class="actions">
            <a class="btn"
               href="take_quiz.php?id=<?= (int)$quiz['id'] ?>">
                Start Quiz
            </a>

            <?php if ($hasFileColumn && !empty($quiz['quiz_file'])): ?>
                <a class="btn secondary"
                   href="view_quiz.php?id=<?= (int)$quiz['id'] ?>">
                    View / Download File
                </a>
            <?php endif; ?>
        </div>
    </article>
<?php endwhile; ?>
</div>
<?php endif; ?>
</div>
</body>
</html>
<?php
$stmt->close();
?>
