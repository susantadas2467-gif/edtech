<?php
require_once "../includes/auth.php";
require_once "../includes/db.php";

require_student();

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT
        r.score,
        r.attempted_at,
        q.title,
        q.subject,
        q.total_marks
    FROM results r
    JOIN quizzes q
        ON r.quiz_id = q.id
    WHERE r.user_id = ?
    ORDER BY r.attempted_at DESC
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Results</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

body{
    background:#0f172a;
    color:white;
    padding:30px;
}

.header{
    margin-bottom:30px;
}

.header h1{
    font-size:32px;
}

.header p{
    color:#94a3b8;
    margin-top:8px;
}

.table-box{
    background:#111827;
    border-radius:15px;
    overflow:hidden;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#1e293b;
    padding:18px;
    text-align:left;
}

td{
    padding:18px;
    border-bottom:1px solid #1e293b;
}

tr:hover{
    background:#172033;
}

.pass{
    color:#22c55e;
    font-weight:bold;
}

.fail{
    color:#ef4444;
    font-weight:bold;
}

.empty{
    background:#111827;
    padding:40px;
    border-radius:15px;
    text-align:center;
}

</style>

</head>
<body>

<div class="header">
    <h1>🏆 My Results</h1>
    <p>View all your quiz performances.</p>
</div>

<?php if($result->num_rows > 0): ?>

<div class="table-box">

<table>

<thead>
<tr>
    <th>Quiz</th>
    <th>Subject</th>
    <th>Score</th>
    <th>Percentage</th>
    <th>Status</th>
    <th>Date</th>
</tr>
</thead>

<tbody>

<?php while($row = $result->fetch_assoc()): ?>

<?php
$percentage =
    ($row['score'] / $row['total_marks']) * 100;

$status =
    $percentage >= 40 ? 'Pass' : 'Fail';
?>

<tr>

<td>
    <?php echo htmlspecialchars($row['title']); ?>
</td>

<td>
    <?php echo htmlspecialchars($row['subject']); ?>
</td>

<td>
    <?php
    echo $row['score']
        . " / "
        . $row['total_marks'];
    ?>
</td>

<td>
    <?php echo round($percentage,2); ?>%
</td>

<td>
    <span class="<?php echo strtolower($status); ?>">
        <?php echo $status; ?>
    </span>
</td>

<td>
    <?php
    echo date(
        "d M Y",
        strtotime($row['attempted_at'])
    );
    ?>
</td>

</tr>

<?php endwhile; ?>

</tbody>

</table>

</div>

<?php else: ?>

<div class="empty">
    <h2>No quiz results available.</h2>
    <p>You haven't attempted any quizzes yet.</p>
</div>

<?php endif; ?>

</body>
</html>