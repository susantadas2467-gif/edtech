<?php
require_once "../includes/auth.php";
require_once "../includes/db.php";

require_student();

$class   = $_SESSION['class'];
$subject = $_GET['subject'] ?? '';

// Get unique subjects for filter tabs
$sub_result = $conn->prepare("SELECT DISTINCT subject FROM materials WHERE class = ? ORDER BY subject");
$sub_result->bind_param("i", $class);
$sub_result->execute();
$subjects_res = $sub_result->get_result();
$subjects = [];
while ($s = $subjects_res->fetch_assoc()) $subjects[] = $s['subject'];
$sub_result->close();

// Get materials
if (!empty($subject)) {
    $stmt = $conn->prepare("SELECT * FROM materials WHERE class = ? AND subject = ? ORDER BY uploaded_at DESC");
    $stmt->bind_param("is", $class, $subject);
} else {
    $stmt = $conn->prepare("SELECT * FROM materials WHERE class = ? ORDER BY uploaded_at DESC");
    $stmt->bind_param("i", $class);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Materials — Class <?php echo htmlspecialchars($class); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --ink:    #1a1a2e;
            --ink2:   #2e2e4a;
            --cream:  #f5f0e8;
            --paper:  #faf7f2;
            --gold:   #c9a84c;
            --gold2:  #e8c96a;
            --muted:  #7a7a8a;
            --green:  #16a34a;
            --blue:   #2563eb;
            --border: rgba(26,26,46,0.12);
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--ink);
            min-height: 100vh;
        }

        /* ── Topbar ── */
        .topbar {
            background: var(--ink);
            padding: 16px 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .brand { display: flex; align-items: center; gap: 10px; }
        .brand-icon {
            width: 32px; height: 32px;
            background: var(--gold);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
        }
        .brand-name {
            font-family: 'Playfair Display', serif;
            font-size: 18px; color: var(--cream);
        }
        .topbar a {
            color: rgba(245,240,232,0.7);
            text-decoration: none; font-size: 13.5px;
        }
        .topbar a:hover { color: var(--gold2); }

        /* ── Container ── */
        .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 40px 24px 80px;
        }

        /* ── Page header ── */
        .page-header { margin-bottom: 28px; }
        .page-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 32px; margin-bottom: 6px;
        }
        .page-header p { color: var(--muted); font-size: 14px; }

        /* ── Subject filter tabs ── */
        .subject-tabs {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 28px;
        }
        .tab {
            padding: 8px 18px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 13.5px;
            font-weight: 500;
            background: #fff;
            color: var(--muted);
            border: 1px solid var(--border);
            transition: all 0.15s;
        }
        .tab:hover {
            border-color: var(--gold);
            color: var(--ink);
        }
        .tab.active {
            background: var(--ink);
            color: var(--cream);
            border-color: var(--ink);
        }

        /* ── Materials grid ── */
        .materials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        /* ── Material card ── */
        .card {
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 22px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            transition: box-shadow 0.2s, transform 0.2s;
        }
        .card:hover {
            box-shadow: 0 6px 24px rgba(26,26,46,0.09);
            transform: translateY(-2px);
        }

        .card-icon {
            width: 42px; height: 42px;
            border-radius: 10px;
            background: rgba(201,168,76,0.12);
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
            margin-bottom: 4px;
        }

        .card-title {
            font-family: 'Playfair Display', serif;
            font-size: 16px;
            font-weight: 600;
            color: var(--ink);
            line-height: 1.3;
        }

        .card-subject {
            display: inline-block;
            font-size: 11.5px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--blue);
            background: rgba(37,99,235,0.08);
            padding: 3px 10px;
            border-radius: 20px;
        }

        .card-date {
            font-size: 12px;
            color: var(--muted);
        }

        /* ── Button group ── */
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 6px;
        }
        .btn {
            flex: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 14px;
            border-radius: 9px;
            font-family: 'DM Sans', sans-serif;
            font-size: 13.5px;
            font-weight: 500;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all 0.15s;
        }
        .btn-view {
            background: var(--ink);
            color: var(--cream);
        }
        .btn-view:hover { background: var(--ink2); }

        .btn-download {
            background: rgba(22,163,74,0.1);
            color: var(--green);
            border: 1px solid rgba(22,163,74,0.25);
        }
        .btn-download:hover {
            background: var(--green);
            color: #fff;
            border-color: var(--green);
        }

        /* ── Empty state ── */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            background: var(--paper);
            border: 1px solid var(--border);
            border-radius: 14px;
            color: var(--muted);
        }
        .empty-state .empty-icon { font-size: 36px; margin-bottom: 12px; }
        .empty-state p { font-size: 14px; }

        @media (max-width: 600px) {
            .container { padding: 28px 16px 60px; }
            .topbar { padding: 14px 16px; }
            .materials-grid { grid-template-columns: 1fr; }
            .btn-group { flex-direction: column; }
        }
    </style>
</head>
<body>

<div class="topbar">
    <div class="brand">
        <div class="brand-icon">📚</div>
        <span class="brand-name">edtech</span>
    </div>
    <a href="dashboard.php">← Dashboard</a>
</div>

<div class="container">

    <div class="page-header">
        <h1>📚 Study Materials</h1>
        <p>Class <?php echo htmlspecialchars($class); ?> — <?php echo $subject ? htmlspecialchars($subject) : 'All Subjects'; ?></p>
    </div>

    <!-- Subject filter tabs -->
    <div class="subject-tabs">
        <a href="materials.php" class="tab <?php echo empty($subject) ? 'active' : ''; ?>">All</a>
        <?php foreach ($subjects as $sub): ?>
        <a href="materials.php?subject=<?php echo urlencode($sub); ?>"
           class="tab <?php echo $subject === $sub ? 'active' : ''; ?>">
            <?php echo htmlspecialchars($sub); ?>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Materials grid -->
    <div class="materials-grid">

        <?php if ($result->num_rows > 0): ?>

            <?php while ($row = $result->fetch_assoc()):
                // Determine file icon based on extension
                $ext = strtolower(pathinfo($row['file_path'], PATHINFO_EXTENSION));
                $icon = match($ext) {
                    'pdf'  => '📄',
                    'doc', 'docx' => '📝',
                    'ppt', 'pptx' => '📊',
                    default => '📁'
                };
                // Build correct file path
                $file_url = '../' . ltrim($row['file_path'], '/');
            ?>

            <div class="card">
                <div class="card-icon"><?php echo $icon; ?></div>

                <div class="card-title">
                    <?php echo htmlspecialchars($row['title']); ?>
                </div>

                <span class="card-subject">
                    <?php echo htmlspecialchars($row['subject']); ?>
                </span>

                <div class="card-date">
                    Uploaded: <?php echo date("d M Y", strtotime($row['uploaded_at'])); ?>
                </div>

                <div class="btn-group">
                
                   <a class="btn btn-view"
   href="view_material.php?file=<?php echo urlencode($row['file_path']); ?>"
   target="_blank">
    👁 View
</a>
                    
                    
                    <a class="btn btn-download"
                       href="<?php echo htmlspecialchars($file_url); ?>"
                       download="<?php echo htmlspecialchars(basename($row['file_path'])); ?>">
                        ⬇ Download
                    </a>
                </div>
            </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-state">
                <div class="empty-icon">📭</div>
                <p>No materials available<?php echo $subject ? " for $subject" : ''; ?>.</p>
            </div>

        <?php endif; ?>

    </div><!-- end grid -->

</div><!-- end container -->

</body>
</html>