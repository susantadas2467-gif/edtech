
<?php
require_once "../includes/auth.php";
require_once "../includes/db.php";

require_student();

$user_id = (int)($_SESSION["user_id"] ?? 0);
$quiz_id = (int)($_POST["quiz_id"] ?? $_GET["id"] ?? 0);

if ($quiz_id < 1) {
    header("Location: quizzes.php");
    exit;
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// Get quiz information
$stmt = $conn->prepare(
    "SELECT id, title, subject, `class`, duration
     FROM quizzes WHERE id = ?"
);
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$quiz = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$quiz) {
    exit("Quiz not found.");
}

// Get the student's class from the database.
$stmt = $conn->prepare("SELECT `class` FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$student || (string)$student["class"] !== (string)$quiz["class"]) {
    http_response_code(403);
    exit("This quiz is not available for your class.");
}

// Load questions
$stmt = $conn->prepare(
    "SELECT id, question_text, question_type,
            option_a, option_b, option_c, option_d,
            correct_option, correct_answer_text, marks
     FROM questions WHERE quiz_id = ? ORDER BY id"
);
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}
$stmt->close();

if (!$questions) {
    exit("This quiz does not contain any questions yet.");
}

$error = "";
$submitted = false;
$score = 0;
$total = 0;
$review = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $answers = $_POST["answers"] ?? [];

    foreach ($questions as $q) {
        $id = (int)$q["id"];
        $marks = max(1, (int)$q["marks"]);
        $total += $marks;
        $given = trim((string)($answers[$id] ?? ""));
        $correct = false;

        if ($q["question_type"] === "mcq") {
            $correct = $given !== ""
                && strtolower($given) === strtolower((string)$q["correct_option"]);
        } else {
            $expected = trim((string)$q["correct_answer_text"]);
            $correct = $given !== "" && $expected !== ""
                && function_exists("mb_strtolower")
                && mb_strtolower($given, "UTF-8") === mb_strtolower($expected, "UTF-8");
        }

        if ($correct) {
            $score += $marks;
        }

        $review[] = [
            "given" => $given,
            "correct" => $correct,
            "expected" => $q["question_type"] === "mcq"
                ? strtoupper((string)$q["correct_option"])
                : (string)$q["correct_answer_text"]
        ];
    }

    $stmt = $conn->prepare(
        "INSERT INTO results (user_id, quiz_id, score, total_marks)
         VALUES (?, ?, ?, ?)"
    );

    if ($stmt) {
        $stmt->bind_param("iiii", $user_id, $quiz_id, $score, $total);

        if ($stmt->execute()) {
            $submitted = true;
        } else {
            $error = "Unable to save your result. Please try again.";
        }

        $stmt->close();
    } else {
        $error = "Unable to save your result. Please contact the administrator.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo e($quiz["title"]); ?> | EdTech Quiz</title>
<style>
*{box-sizing:border-box}
body{margin:0;padding:24px;background:#f5f0e8;color:#1a1a2e;
font-family:Arial,sans-serif}
.container{max-width:850px;margin:0 auto}
.header{background:#1a1a2e;color:#f5f0e8;padding:26px;
border-radius:14px;margin-bottom:20px}
.header h1{margin:0 0 12px}
.meta{color:#e8c96a}
.question,.result{background:#fff;border:1px solid #ddd6c8;
border-radius:12px;padding:22px;margin-bottom:16px}
.question-title{font-weight:bold;margin-bottom:16px;line-height:1.6}
.option{display:flex;gap:10px;padding:12px;border:1px solid #eee;
border-radius:8px;margin:8px 0;cursor:pointer}
.option:hover{background:#faf7f2;border-color:#c9a84c}
textarea{width:100%;min-height:90px;padding:12px;
border:1px solid #ccc;border-radius:8px;font:inherit}
button,.btn{display:inline-block;background:#1a1a2e;color:white;
padding:13px 20px;border:0;border-radius:8px;text-decoration:none;
cursor:pointer;font-size:14px}
.secondary{background:transparent;color:#1a1a2e;
border:1px solid #c9a84c}
.error{color:#b42318;margin-bottom:16px}
.score{font-size:32px;color:#1e7e4a;font-weight:bold}
.good{color:#1e7e4a}.bad{color:#b42318}
</style>
</head>
<body>
<div class="container">

<p><a href="quizzes.php">← Back to quizzes</a></p>

<?php if ($error): ?>
<p class="error"><?php echo e($error); ?></p>
<?php endif; ?>

<?php if ($submitted): ?>

<div class="result">
    <h1>Quiz completed!</h1>
    <h2><?php echo e($quiz["title"]); ?></h2>
    <p class="score">
        <?php echo $score; ?> / <?php echo $total; ?>
    </p>
    <p>
        Percentage:
        <?php echo $total ? round($score / $total * 100, 1) : 0; ?>%
    </p>

    <h2>Answer review</h2>
    <?php foreach ($questions as $i => $q): ?>
        <?php $r = $review[$i]; ?>
        <div class="question">
            <p><?php echo ($i + 1) . ". " . e($q["question_text"]); ?></p>
            <p>Your answer:
                <?php echo e($r["given"] ?: "Not answered"); ?>
            </p>
            <strong class="<?php echo $r["correct"] ? "good" : "bad"; ?>">
                <?php echo $r["correct"] ? "Correct" : "Incorrect"; ?>
            </strong>
            <?php if (!$r["correct"]): ?>
                <p>Correct answer: <?php echo e($r["expected"] ?: "Not set"); ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <a class="btn" href="result.php">My results</a>
    <a class="btn secondary" href="quizzes.php">All quizzes</a>
</div>

<?php else: ?>

<div class="header">
    <h1><?php echo e($quiz["title"]); ?></h1>
    <p class="meta">
        <?php echo e($quiz["subject"]); ?> ·
        Class <?php echo e($quiz["class"]); ?> ·
        <?php echo count($questions); ?> questions
    </p>
    <p>Read each question carefully before submitting.</p>
</div>

<form method="post" action="take_quiz.php"
      onsubmit="return confirm('Submit your answers now?');">
    <input type="hidden" name="quiz_id"
           value="<?php echo $quiz_id; ?>">

    <?php foreach ($questions as $i => $q): ?>
    <div class="question">
        <div class="question-title">
            Question <?php echo $i + 1; ?>:
            <?php echo nl2br(e($q["question_text"])); ?>
            <small>(<?php echo max(1, (int)$q["marks"]); ?> marks)</small>
        </div>

        <?php if ($q["question_type"] === "mcq"): ?>
            <?php foreach (["a"=>"option_a","b"=>"option_b",
                            "c"=>"option_c","d"=>"option_d"] as $letter=>$column): ?>
                <?php if (trim((string)$q[$column]) !== ""): ?>
                <label class="option">
                    <input type="radio"
                           name="answers[<?php echo (int)$q["id"]; ?>]"
                           value="<?php echo $letter; ?>">
                    <span>
                        <strong><?php echo strtoupper($letter); ?>.</strong>
                        <?php echo e($q[$column]); ?>
                    </span>
                </label>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <textarea
                name="answers[<?php echo (int)$q["id"]; ?>]"
                placeholder="Type your answer"></textarea>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>

    <button type="submit">Submit quiz</button>
    <a class="btn secondary" href="quizzes.php">Cancel</a>
</form>

<?php endif; ?>
</div>
</body>
</html>
