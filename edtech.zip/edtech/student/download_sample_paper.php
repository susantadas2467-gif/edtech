<?php
require_once __DIR__ . '/../includes/auth.php';

require_student();

$studentClass = get_user_class();

if (!in_array($studentClass, ['9', '10'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit('Invalid sample paper.');
}

$stmt = $conn->prepare(
    "SELECT title, file_path
     FROM materials
     WHERE id = ?
       AND material_type = 'sample_paper'
       AND `class` = ?
     LIMIT 1"
);
$stmt->bind_param('is', $id, $studentClass);
$stmt->execute();
$paper = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$paper) {
    http_response_code(404);
    exit('Sample paper not found for your class.');
}

// Resolve the saved path and verify that it is inside the protected
// uploads/sample_papers directory.
$projectRoot = realpath(__DIR__ . '/..');
$protectedBase = realpath(__DIR__ . '/../uploads/sample_papers');

if ($projectRoot === false || $protectedBase === false) {
    http_response_code(500);
    exit('The sample papers folder is not configured correctly.');
}

$relativePath = str_replace('\\', '/', $paper['file_path']);
$expectedPrefix = 'uploads/sample_papers/';

if (strpos($relativePath, $expectedPrefix) !== 0) {
    http_response_code(403);
    exit('Invalid file path.');
}

$filePath = realpath($projectRoot . DIRECTORY_SEPARATOR .
    str_replace('/', DIRECTORY_SEPARATOR, $relativePath));

$basePrefix = rtrim($protectedBase, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

if (
    $filePath === false ||
    !is_file($filePath) ||
    strpos($filePath, $basePrefix) !== 0 ||
    strtolower(pathinfo($filePath, PATHINFO_EXTENSION)) !== 'pdf'
) {
    http_response_code(404);
    exit('The sample paper file is unavailable.');
}

$safeTitle = preg_replace('/[^a-zA-Z0-9_-]/', '_', $paper['title']);
if ($safeTitle === '') {
    $safeTitle = 'sample-paper';
}

header('Content-Type: application/pdf');
header('Content-Length: ' . filesize($filePath));
header('Content-Disposition: attachment; filename="' . $safeTitle . '.pdf"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

readfile($filePath);
exit;