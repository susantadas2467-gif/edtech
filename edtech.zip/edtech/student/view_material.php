<?php
// student/view_material.php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_student();

$material_id = (int)($_GET['id'] ?? 0);
if (!$material_id) { header("Location: materials.php"); exit(); }

// Fetch material from DB — must match student's class
$s = $conn->prepare("
    SELECT id, title, subject, `class`, file_path, pdf_path
    FROM materials
    WHERE id = ? 
");
$s->bind_param("i", $material_id);
$s->execute();
$material = $s->get_result()->fetch_assoc();
$s->close();

if (!$material) { header("Location: materials.php"); exit(); }

$ext         = strtolower(pathinfo($material['file_path'], PATHINFO_EXTENSION));
$orig_url    = '../' . ltrim($material['file_path'], '/');
$has_pdf     = !empty($material['pdf_path']) && file_exists('../' . $material['pdf_path']);
$view_url    = $has_pdf
    ? '../' . ltrim($material['pdf_path'], '/')
    : ($ext === 'pdf' ? $orig_url : null);
$can_preview = ($view_url !== null);
$filename    = basename($material['file_path']);

$icon_emoji = match($ext) {
    'pdf'        => '📄',
    'doc','docx' => '📝',
    'ppt','pptx' => '📊',
    default      => '📁'
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View — <?php echo htmlspecialchars($material['title']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--ink:#1a1a2e;--ink2:#2e2e4a;--cream:#f5f0e8;--gold:#c9a84c;--gold2:#e8c96a;--muted:#7a7a8a;--green:#16a34a;--red:#c0392b;--border:rgba(26,26,46,.12)}
        html,body{height:100%;font-family:'DM Sans',sans-serif;background:var(--ink)}

        /* ── Topbar ── */
        .bar{
            background:var(--ink2);
            padding:12px 24px;
            display:flex;align-items:center;justify-content:space-between;
            border-bottom:1px solid rgba(255,255,255,.08);
            position:sticky;top:0;z-index:10;
        }
        .bar-left{display:flex;align-items:center;gap:12px}
        .file-icon{
            width:36px;height:36px;border-radius:9px;
            display:flex;align-items:center;justify-content:center;
            font-size:17px;flex-shrink:0;
        }
        .file-icon.pdf {background:rgba(220,38,38,.15)}
        .file-icon.docx{background:rgba(37,99,235,.15)}
        .file-icon.pptx{background:rgba(234,88,12,.15)}
        .file-icon.other{background:rgba(255,255,255,.08)}
        .file-info{}
        .file-title{font-size:14px;font-weight:500;color:var(--gold2);max-width:480px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .file-meta{font-size:11px;color:rgba(255,255,255,.35);margin-top:2px;text-transform:uppercase;letter-spacing:.05em}
        .bar-right{display:flex;gap:10px;align-items:center}
        .btn{
            display:inline-flex;align-items:center;gap:6px;
            padding:8px 16px;border-radius:8px;
            font-size:13px;font-weight:500;
            text-decoration:none;border:none;cursor:pointer;
            transition:all .15s;
        }
        .btn-dl{background:rgba(22,163,74,.15);color:#4ade80;border:1px solid rgba(22,163,74,.25)}
        .btn-dl:hover{background:var(--green);color:#fff;border-color:var(--green)}
        .btn-back{background:rgba(255,255,255,.06);color:rgba(255,255,255,.6);border:1px solid rgba(255,255,255,.1)}
        .btn-back:hover{background:rgba(255,255,255,.1);color:#fff}

        /* ── Viewer ── */
        .viewer{height:calc(100vh - 58px);display:flex;align-items:center;justify-content:center}
        iframe{width:100%;height:100%;border:none;display:block;background:#fff}

        /* ── No preview ── */
        .no-preview{text-align:center;padding:40px 20px}
        .no-preview-icon{font-size:72px;margin-bottom:16px}
        .no-preview h2{font-family:'Playfair Display',serif;font-size:26px;color:#f5f0e8;margin-bottom:10px}
        .no-preview p{color:rgba(255,255,255,.45);font-size:14px;max-width:380px;margin:0 auto 28px;line-height:1.7}
        .ext-badge{display:inline-block;padding:4px 14px;border-radius:20px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:20px}
        .ext-badge.docx{background:rgba(37,99,235,.2);color:#93c5fd}
        .ext-badge.pptx{background:rgba(234,88,12,.2);color:#fdba74}
        .ext-badge.other{background:rgba(255,255,255,.1);color:rgba(255,255,255,.6)}
        .btn-dl-big{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:12px;background:var(--green);color:#fff;font-size:15px;font-weight:600;text-decoration:none;transition:opacity .15s}
        .btn-dl-big:hover{opacity:.85}
        .tip{margin-top:16px;font-size:12px;color:rgba(255,255,255,.2)}
    </style>
</head>
<body>

<!-- Topbar -->
<div class="bar">
    <div class="bar-left">
        <?php
        $icon_cls = match($ext) {
            'pdf'        => 'pdf',
            'doc','docx' => 'docx',
            'ppt','pptx' => 'pptx',
            default      => 'other'
        };
        ?>
        <div class="file-icon <?php echo $icon_cls; ?>"><?php echo $icon_emoji; ?></div>
        <div class="file-info">
            <div class="file-title"><?php echo htmlspecialchars($material['title']); ?></div>
            <div class="file-meta">
                <?php echo htmlspecialchars($material['subject']); ?> ·
                Class <?php echo htmlspecialchars($material['class']); ?> ·
                <?php echo strtoupper($ext); ?>
                <?php if ($has_pdf && $ext !== 'pdf'): ?>
                · <span style="color:#4ade80">PDF Preview ✓</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="bar-right">
        <a class="btn btn-dl"
           href="<?php echo htmlspecialchars($orig_url); ?>"
           download="<?php echo htmlspecialchars($filename); ?>">
            ⬇ Download <?php echo strtoupper($ext); ?>
        </a>
        <a class="btn btn-back" href="materials.php">← Back</a>
    </div>
</div>

<!-- Viewer -->
<div class="viewer">
    <?php if ($can_preview): ?>
        <iframe src="<?php echo htmlspecialchars($view_url); ?>" type="application/pdf"></iframe>

    <?php else: ?>
        <div class="no-preview">
            <div class="no-preview-icon"><?php echo $icon_emoji; ?></div>
            <div class="ext-badge <?php echo $icon_cls; ?>"><?php echo strtoupper($ext); ?></div>
            <h2>Preview not available</h2>
            <p>
                This file hasn't been converted to PDF yet.
                Download it to open in Microsoft Word or a compatible app.
            </p>
            <a class="btn-dl-big"
               href="<?php echo htmlspecialchars($orig_url); ?>"
               download="<?php echo htmlspecialchars($filename); ?>">
                ⬇ Download to View
            </a>
            <div class="tip">Ask your admin to re-upload this file to enable preview.</div>
        </div>
    <?php endif; ?>
</div>

</body>
</html>