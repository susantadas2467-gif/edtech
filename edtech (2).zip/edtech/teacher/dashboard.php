<?php
// teacher/dashboard.php
require_once '../includes/session.php';
require_once '../includes/db.php';
require_once '../includes/flash.php';

// Auth check
if (!is_logged_in() || (get_role() !== 'teacher' && get_role() !== 'admin')) {
    header("Location: ../index.php");
    exit();
}

$teacher_id   = get_user_id();
$teacher_name = get_name();
$today        = date('l, d M Y');

// ── Stats ──
$total_competitions = 0;
$total_participants = 0;
$total_questions    = 0;
$active_competition = null;

$r = $conn->prepare("SELECT COUNT(*) AS c FROM competitions WHERE host_id = ?");
$r->bind_param("i", $teacher_id);
$r->execute();
$total_competitions = $r->get_result()->fetch_assoc()['c'];
$r->close();

$r = $conn->prepare("
    SELECT COUNT(*) AS c FROM competition_participants cp
    JOIN competitions c ON cp.competition_id = c.id
    WHERE c.host_id = ?
");
$r->bind_param("i", $teacher_id);
$r->execute();
$total_participants = $r->get_result()->fetch_assoc()['c'];
$r->close();

$r = $conn->prepare("
    SELECT COUNT(*) AS c FROM questions q
    JOIN quizzes qz ON q.quiz_id = qz.id
    WHERE qz.created_by = ?
");
$r->bind_param("i", $teacher_id);
$r->execute();
$total_questions = $r->get_result()->fetch_assoc()['c'];
$r->close();

// Active live competition
$r = $conn->prepare("
    SELECT c.id, c.join_code, c.status, c.started_at,
           qz.title AS quiz_title,
           (SELECT COUNT(*) FROM competition_participants WHERE competition_id = c.id) AS participant_count
    FROM competitions c
    JOIN quizzes qz ON c.quiz_id = qz.id
    WHERE c.host_id = ? AND c.status = 'live'
    LIMIT 1
");
$r->bind_param("i", $teacher_id);
$r->execute();
$active_competition = $r->get_result()->fetch_assoc();
$r->close();

// Recent competitions
$recent_comps = [];
$r = $conn->prepare("
    SELECT c.id, c.join_code, c.status, c.created_at,
           qz.title AS quiz_title, qz.subject,
           (SELECT COUNT(*) FROM competition_participants WHERE competition_id = c.id) AS participant_count,
           (SELECT ROUND(AVG(score),1) FROM competition_participants WHERE competition_id = c.id) AS avg_score
    FROM competitions c
    JOIN quizzes qz ON c.quiz_id = qz.id
    WHERE c.host_id = ?
    ORDER BY c.created_at DESC
    LIMIT 6
");
$r->bind_param("i", $teacher_id);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $recent_comps[] = $row;
$r->close();

// My quizzes
$my_quizzes = [];
$r = $conn->prepare("
    SELECT id, title, subject, `class`, duration,
           (SELECT COUNT(*) FROM questions WHERE quiz_id = quizzes.id) AS q_count,
           created_at
    FROM quizzes
    WHERE created_by = ?
    ORDER BY created_at DESC
    LIMIT 5
");
$r->bind_param("i", $teacher_id);
$r->execute();
$res = $r->get_result();
while ($row = $res->fetch_assoc()) $my_quizzes[] = $row;
$r->close();

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edtech — Teacher Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --ink:#1a1a2e; --ink2:#2e2e4a; --cream:#f5f0e8; --paper:#faf7f2;
            --gold:#c9a84c; --gold2:#e8c96a; --muted:#7a7a8a;
            --red:#c0392b; --green:#16a34a; --blue:#2563eb; --purple:#7c3aed;
            --border:rgba(26,26,46,0.10); --sidebar-w:240px;
        }
        html, body { font-family:'DM Sans',sans-serif; background:var(--cream); color:var(--ink); min-height:100vh; }

        /* ── Layout ── */
        .layout { display:flex; min-height:100vh; }

        /* ── Sidebar ── */
        .sidebar {
            width:var(--sidebar-w); background:var(--ink);
            display:flex; flex-direction:column;
            position:fixed; top:0; left:0; bottom:0;
            z-index:50; overflow-y:auto;
        }
        .sidebar-logo { padding:22px 20px 18px; border-bottom:1px solid rgba(255,255,255,0.07); }
        .logo-mark { width:34px; height:34px; background:var(--gold); border-radius:9px; display:flex; align-items:center; justify-content:center; font-size:16px; margin-bottom:8px; }
        .logo-text { font-family:'Playfair Display',serif; font-size:16px; color:var(--cream); }
        .logo-role { font-size:10px; color:var(--gold2); letter-spacing:.1em; text-transform:uppercase; margin-top:2px; }

        .sidebar-section { padding:18px 12px 6px; }
        .sidebar-label { font-size:10px; text-transform:uppercase; letter-spacing:.1em; color:rgba(245,240,232,0.3); padding:0 8px; margin-bottom:6px; }

        .nav-item {
            display:flex; align-items:center; gap:10px;
            padding:9px 10px; border-radius:8px;
            text-decoration:none; font-size:13.5px;
            color:rgba(245,240,232,0.6);
            transition:background .15s, color .15s;
            margin-bottom:2px;
        }
        .nav-item:hover { background:rgba(255,255,255,0.06); color:var(--cream); }
        .nav-item.active { background:rgba(201,168,76,0.15); color:var(--gold2); }
        .nav-badge {
            margin-left:auto; background:var(--gold); color:var(--ink);
            font-size:10px; font-weight:600; padding:2px 7px; border-radius:10px;
        }
        .nav-badge.live { background:#22c55e; color:#fff; animation:pulse 1.5s infinite; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.6} }

        .sidebar-footer { margin-top:auto; padding:14px 12px; border-top:1px solid rgba(255,255,255,0.07); }
        .user-card { display:flex; align-items:center; gap:10px; }
        .user-avatar { width:32px; height:32px; background:var(--gold); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:600; color:var(--ink); flex-shrink:0; }
        .user-name { font-size:13px; color:var(--cream); font-weight:500; }
        .user-role { font-size:11px; color:rgba(245,240,232,0.4); }
        .logout-btn { margin-left:auto; background:none; border:none; color:rgba(245,240,232,0.35); cursor:pointer; padding:4px; border-radius:5px; text-decoration:none; display:flex; align-items:center; transition:color .15s; }
        .logout-btn:hover { color:var(--red); }

        /* ── Main ── */
        .main { margin-left:var(--sidebar-w); flex:1; display:flex; flex-direction:column; }

        .topbar {
            background:var(--paper); border-bottom:1px solid var(--border);
            padding:14px 28px; display:flex; align-items:center;
            justify-content:space-between; position:sticky; top:0; z-index:40;
        }
        .topbar h1 { font-family:'Playfair Display',serif; font-size:20px; }
        .topbar p { font-size:12px; color:var(--muted); margin-top:1px; }
        .topbar-actions { display:flex; gap:10px; }

        .btn { padding:9px 18px; border-radius:8px; font-size:13.5px; font-weight:500; cursor:pointer; border:none; text-decoration:none; display:inline-flex; align-items:center; gap:6px; transition:all .15s; }
        .btn-gold { background:var(--gold); color:var(--ink); }
        .btn-gold:hover { background:var(--gold2); }
        .btn-outline { background:transparent; border:1px solid var(--border); color:var(--ink); }
        .btn-outline:hover { border-color:var(--gold); background:rgba(201,168,76,0.05); }

        .content { padding:26px 28px 60px; }

        /* ── Alerts ── */
        .alert { border-radius:8px; padding:12px 16px; margin-bottom:20px; font-size:13.5px; display:flex; align-items:center; gap:8px; }
        .alert-success { background:#edfbf3; border:1px solid rgba(22,163,74,.2); border-left:3px solid var(--green); color:var(--green); }
        .alert-error { background:#fdf0ef; border:1px solid rgba(192,57,43,.2); border-left:3px solid var(--red); color:var(--red); }

        /* ── Live banner ── */
        .live-banner {
            background:linear-gradient(135deg,var(--ink) 0%,var(--ink2) 100%);
            border:1px solid var(--gold); border-radius:14px;
            padding:20px 24px; margin-bottom:22px;
            display:flex; align-items:center; justify-content:space-between; gap:16px;
        }
        .live-badge { display:inline-flex; align-items:center; gap:6px; background:#22c55e; color:#fff; font-size:10px; font-weight:700; padding:3px 10px; border-radius:20px; text-transform:uppercase; letter-spacing:.06em; animation:pulse 1.5s infinite; margin-bottom:6px; }
        .live-title { font-family:'Playfair Display',serif; font-size:18px; color:var(--cream); }
        .live-meta { font-size:13px; color:rgba(245,240,232,.55); margin-top:4px; }
        .live-code strong { color:var(--gold2); font-size:20px; letter-spacing:.15em; font-family:'Playfair Display',serif; }
        .live-actions { display:flex; gap:10px; flex-shrink:0; }
        .btn-danger { background:var(--red); color:#fff; padding:9px 18px; border-radius:8px; font-size:13.5px; font-weight:500; border:none; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:6px; transition:opacity .15s; }
        .btn-danger:hover { opacity:.85; }

        /* ── Stats ── */
        .stats-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:22px; }
        .stat-card { background:var(--paper); border:1px solid var(--border); border-radius:12px; padding:20px; position:relative; overflow:hidden; }
        .stat-card::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; }
        .stat-card.gold::before { background:var(--gold); }
        .stat-card.green::before { background:#22c55e; }
        .stat-card.blue::before { background:var(--blue); }
        .stat-icon { width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center; font-size:16px; margin-bottom:14px; }
        .stat-icon.gold  { background:rgba(201,168,76,.12); }
        .stat-icon.green { background:rgba(34,197,94,.12); }
        .stat-icon.blue  { background:rgba(37,99,235,.12); }
        .stat-num { font-family:'Playfair Display',serif; font-size:32px; color:var(--ink); line-height:1; }
        .stat-label { font-size:12.5px; color:var(--muted); margin-top:4px; }

        /* ── Two col ── */
        .two-col { display:grid; grid-template-columns:1.6fr 1fr; gap:20px; }

        /* ── Section cards ── */
        .section-card { background:var(--paper); border:1px solid var(--border); border-radius:14px; overflow:hidden; }
        .section-header { padding:16px 20px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
        .section-header h2 { font-family:'Playfair Display',serif; font-size:16px; }
        .section-link { font-size:12.5px; color:var(--gold); text-decoration:none; font-weight:500; }
        .section-link:hover { text-decoration:underline; }

        /* Competition rows */
        .comp-row { padding:13px 20px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:12px; }
        .comp-row:last-child { border-bottom:none; }
        .comp-dot { width:8px; height:8px; border-radius:50%; flex-shrink:0; }
        .comp-dot.live { background:#22c55e; box-shadow:0 0 0 3px rgba(34,197,94,.2); }
        .comp-dot.waiting { background:var(--gold); }
        .comp-dot.ended { background:var(--muted); }
        .comp-info { flex:1; min-width:0; }
        .comp-title { font-size:13.5px; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .comp-meta { font-size:11.5px; color:var(--muted); margin-top:2px; }
        .comp-code { font-size:12px; color:var(--muted); font-family:monospace; letter-spacing:.1em; background:rgba(26,26,46,.05); padding:3px 8px; border-radius:5px; flex-shrink:0; }
        .mini-btn { padding:5px 10px; border-radius:6px; font-size:11.5px; text-decoration:none; border:1px solid var(--border); color:var(--ink); background:#fff; transition:all .15s; cursor:pointer; }
        .mini-btn:hover { border-color:var(--gold); }
        .mini-btn.start { background:var(--ink); color:var(--cream); border-color:var(--ink); }

        /* Quiz rows */
        .quiz-row { padding:13px 20px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:12px; }
        .quiz-row:last-child { border-bottom:none; }
        .quiz-icon { width:34px; height:34px; background:rgba(201,168,76,.1); border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:15px; flex-shrink:0; }
        .quiz-title { font-size:13.5px; font-weight:500; }
        .quiz-meta { font-size:11.5px; color:var(--muted); margin-top:2px; }
        .quiz-class { margin-left:auto; font-size:11px; font-weight:600; padding:3px 8px; border-radius:6px; background:rgba(201,168,76,.1); color:var(--gold); flex-shrink:0; }

        /* Quick actions */
        .quick-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; padding:16px; }
        .quick-tile { display:flex; align-items:center; gap:10px; padding:12px 14px; border:1px solid var(--border); border-radius:10px; text-decoration:none; color:var(--ink); font-size:13px; font-weight:500; background:#fff; transition:all .15s; }
        .quick-tile:hover { border-color:var(--gold); background:rgba(201,168,76,.04); transform:translateY(-1px); }
        .quick-icon { width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:15px; flex-shrink:0; }

        /* Empty state */
        .empty-state { padding:36px 20px; text-align:center; color:var(--muted); font-size:13.5px; }
        .empty-icon { font-size:28px; margin-bottom:8px; }

        @media(max-width:900px) {
            .sidebar { display:none; }
            .main { margin-left:0; }
            .stats-grid { grid-template-columns:1fr 1fr; }
            .two-col { grid-template-columns:1fr; }
        }
        @media(max-width:560px) {
            .stats-grid { grid-template-columns:1fr; }
            .content { padding:20px 16px 40px; }
            .topbar { padding:14px 16px; }
        }
    </style>
</head>
<body>
<div class="layout">

    <!-- ── SIDEBAR ── -->
    <aside class="sidebar">
        <div class="sidebar-logo">
            <div class="logo-mark">📚</div>
            <div class="logo-text">edtech</div>
            <div class="logo-role">Teacher Portal</div>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Main</div>
            <a href="dashboard.php" class="nav-item active">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                    <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
                </svg>
                Dashboard
                <?php if ($active_competition): ?>
                <span class="nav-badge live">LIVE</span>
                <?php endif; ?>
            </a>
            <a href="create_competition.php" class="nav-item">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="16"/>
                    <line x1="8" y1="12" x2="16" y2="12"/>
                </svg>
                New Competition
            </a>
            <a href="../admin/add_quiz.php" class="nav-item">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path d="M9 11l3 3L22 4"/>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                </svg>
                Create Quiz
            </a>
            <a href="leaderboard.php" class="nav-item">
                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="20" x2="18" y2="10"/>
                    <line x1="12" y1="20" x2="12" y2="4"/>
                    <line x1="6" y1="20" x2="6" y2="14"/>
                </svg>
                Leaderboards
            </a>
        </div>

        <div class="sidebar-section">
            <div class="sidebar-label">Recent Competitions</div>
            <?php foreach (array_slice($recent_comps, 0, 4) as $comp): ?>
            <a href="manage_competition.php?id=<?php echo $comp['id']; ?>" class="nav-item">
                <span style="width:7px;height:7px;border-radius:50%;flex-shrink:0;background:<?php
                    echo $comp['status']==='live' ? '#22c55e' : ($comp['status']==='waiting' ? '#c9a84c' : '#7a7a8a');
                ?>"></span>
                <?php echo htmlspecialchars(mb_substr($comp['quiz_title'],0,20)); ?>
                <?php if ($comp['status']==='live'): ?>
                <span class="nav-badge live">LIVE</span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
            <?php if (empty($recent_comps)): ?>
            <div style="padding:8px 10px;font-size:12px;color:rgba(245,240,232,.3)">No competitions yet</div>
            <?php endif; ?>
        </div>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar"><?php echo strtoupper(substr($teacher_name,0,1)); ?></div>
                <div>
                    <div class="user-name"><?php echo htmlspecialchars($teacher_name); ?></div>
                    <div class="user-role">Teacher</div>
                </div>
                <a href="../logout.php" class="logout-btn" title="Logout">
                    <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                        <polyline points="16 17 21 12 16 7"/>
                        <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                </a>
            </div>
        </div>
    </aside>

    <!-- ── MAIN ── -->
    <div class="main">
        <div class="topbar">
            <div>
                <h1>Dashboard</h1>
                <p><?php echo $today; ?></p>
            </div>
            <div class="topbar-actions">
                <a href="create_competition.php" class="btn btn-gold">
                    <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                        <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                    New Competition
                </a>
                <a href="../admin/add_quiz.php" class="btn btn-outline">+ New Quiz</a>
            </div>
        </div>

        <div class="content">

            <?php if ($flash): ?>
            <div class="alert alert-<?php echo $flash['type']==='success' ? 'success' : 'error'; ?>">
                <?php echo $flash['type']==='success' ? '✓' : '⚠️'; ?>
                <?php echo htmlspecialchars($flash['message']); ?>
            </div>
            <?php endif; ?>

            <!-- Live banner -->
            <?php if ($active_competition): ?>
            <div class="live-banner">
                <div>
                    <div class="live-badge">● Live Now</div>
                    <div class="live-title"><?php echo htmlspecialchars($active_competition['quiz_title']); ?></div>
                    <div class="live-meta live-code">
                        Code: <strong><?php echo htmlspecialchars($active_competition['join_code']); ?></strong>
                        &nbsp;·&nbsp; <?php echo $active_competition['participant_count']; ?> joined
                    </div>
                </div>
                <div class="live-actions">
                    <a href="manage_competition.php?id=<?php echo $active_competition['id']; ?>" class="btn btn-gold">View Live →</a>
                    <a href="manage_competition.php?id=<?php echo $active_competition['id']; ?>&action=end"
                       class="btn-danger" onclick="return confirm('End this competition?')">■ End</a>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card gold">
                    <div class="stat-icon gold">🏆</div>
                    <div class="stat-num"><?php echo $total_competitions; ?></div>
                    <div class="stat-label">Competitions Hosted</div>
                </div>
                <div class="stat-card green">
                    <div class="stat-icon green">👥</div>
                    <div class="stat-num"><?php echo $total_participants; ?></div>
                    <div class="stat-label">Total Participants</div>
                </div>
                <div class="stat-card blue">
                    <div class="stat-icon blue">❓</div>
                    <div class="stat-num"><?php echo $total_questions; ?></div>
                    <div class="stat-label">Questions Created</div>
                </div>
            </div>

            <!-- Two column -->
            <div class="two-col">

                <!-- Recent competitions -->
                <div class="section-card">
                    <div class="section-header">
                        <h2>Recent Competitions</h2>
                        <a href="create_competition.php" class="section-link">+ New →</a>
                    </div>
                    <?php if (empty($recent_comps)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">🎮</div>
                        No competitions yet — create your first one!
                    </div>
                    <?php else: ?>
                    <?php foreach ($recent_comps as $comp): ?>
                    <div class="comp-row">
                        <div class="comp-dot <?php echo $comp['status']; ?>"></div>
                        <div class="comp-info">
                            <div class="comp-title"><?php echo htmlspecialchars($comp['quiz_title']); ?></div>
                            <div class="comp-meta">
                                <?php echo htmlspecialchars($comp['subject']); ?> ·
                                <?php echo $comp['participant_count']; ?> players ·
                                <?php echo $comp['avg_score'] ? $comp['avg_score'].' avg' : 'No results'; ?> ·
                                <?php echo date('d M', strtotime($comp['created_at'])); ?>
                            </div>
                        </div>
                        <div class="comp-code"><?php echo htmlspecialchars($comp['join_code']); ?></div>
                        <div>
                            <?php if ($comp['status']==='waiting'): ?>
                            <a href="manage_competition.php?id=<?php echo $comp['id']; ?>&action=start"
                               class="mini-btn start" onclick="return confirm('Start competition?')">Start</a>
                            <?php elseif ($comp['status']==='live'): ?>
                            <a href="manage_competition.php?id=<?php echo $comp['id']; ?>" class="mini-btn start">View</a>
                            <?php else: ?>
                            <a href="leaderboard.php?id=<?php echo $comp['id']; ?>" class="mini-btn">Results</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Right column -->
                <div style="display:flex;flex-direction:column;gap:20px;">

                    <!-- Quick Actions -->
                    <div class="section-card">
                        <div class="section-header"><h2>Quick Actions</h2></div>
                        <div class="quick-grid">
                            <a href="create_competition.php" class="quick-tile">
                                <div class="quick-icon" style="background:rgba(201,168,76,.12);">🎮</div>
                                Host Competition
                            </a>
                            <a href="../admin/add_quiz.php" class="quick-tile">
                                <div class="quick-icon" style="background:rgba(37,99,235,.1);">📝</div>
                                Create Quiz
                            </a>
                            <a href="leaderboard.php" class="quick-tile">
                                <div class="quick-icon" style="background:rgba(34,197,94,.1);">🏅</div>
                                Leaderboards
                            </a>
                            <a href="../index.php?tab=join" class="quick-tile">
                                <div class="quick-icon" style="background:rgba(124,58,237,.1);">🔗</div>
                                Join Page
                            </a>
                        </div>
                    </div>

                    <!-- My Quizzes -->
                    <div class="section-card">
                        <div class="section-header">
                            <h2>My Quizzes</h2>
                            <a href="../admin/add_quiz.php" class="section-link">+ New →</a>
                        </div>
                        <?php if (empty($my_quizzes)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📋</div>
                            No quizzes yet.
                        </div>
                        <?php else: ?>
                        <?php foreach ($my_quizzes as $quiz): ?>
                        <div class="quiz-row">
                            <div class="quiz-icon">📄</div>
                            <div style="flex:1;min-width:0;">
                                <div class="quiz-title"><?php echo htmlspecialchars($quiz['title']); ?></div>
                                <div class="quiz-meta">
                                    <?php echo htmlspecialchars($quiz['subject']); ?> ·
                                    <?php echo $quiz['q_count']; ?> questions ·
                                    <?php echo $quiz['duration']; ?> mins
                                </div>
                            </div>
                            <div class="quiz-class">Class <?php echo htmlspecialchars($quiz['class']); ?></div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $conn->close(); ?>
</body>
</html>